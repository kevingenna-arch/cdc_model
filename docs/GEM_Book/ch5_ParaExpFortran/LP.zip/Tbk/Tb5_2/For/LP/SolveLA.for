C SolveLA.for
C
C SolveLA: implements the computation of policy functions as described
C          in Section 2.3.2 of Heer/Maussner (2004)
C
C Usage: Call SolveLA(nu,nx,nl,nz,Cu,Cxl,Cz,Dxl,Fxl,Du,Fu,Dz,Fz,Rho,Lxx,Lxz,Llx,Llz,Lux,Luz)
C
C Input: nu : Integer(4), number of control variables u
C        nx : Integer(4), number of endogenous states x
C        nl : Integer(4), number of costates l
C        nz : Integer(4), number of exogenous shocks
C        Cu(nu,nu)       : Real(8) matrix
C       Cxl(nu,nx+nl)    : Real(8) matrix
C        Cz(nu,nz)       : Real(8) matrix
C       Dxl(nx+nl,nx+nl) : Real(8) matrix
C       Fxl(nx+nl,nx+nl) : Real(8) matrix
C        Du(nx+nl,nu)    : Real(8) matrix
C        Fu(nx+nl,nu)    : Real(8) matrix
C        Dz(nx+nl,nz)    : Real(8) matrix
C        Fz(nx+nl,nz)    : Real(8) matrix
C       Rho(nz,nz)       : Real(8) matrix
C
C Output: Lxx(nx,nx)    : Real(8) matrix
C         Lxz(nx,nz)    : Real(8) matrix
C         Llx(nl,nx)    : Real(8) matrix
C         Llz(nl,nz)    : Real(8) matrix
C         Lux(nu,nx)    : Real(8) matrix
C         Luz(nu,nz)    : Real(8) matrix
C
C The Subroutine uses the Module Errors to report any error that occurs during 
C execution in the Integer(4) variable FError. This module must be defined.
C At least the following code must be specified:
C
C Module Errors
C Integer(4) FError
C End Module Errors

      Subroutine SolveLA(nu,nx,nl,nz,Cu,Cxl,Cz,Dxl,Fxl,Du,Fu,Dz,Fz,Rho,
     +                   Lxx,Lxz,Llx,Llz,Lux,Luz)
      
	use IMSLF90 
      use DFLIB
	use Errors

	Integer(4) nu, nx, nz, nl

	Real(8) Cu(nu,nu),Cxl(nu,nx+nl),Cz(nu,nz),Dxl(nx+nl,nx+nl),
     +        Fxl(nx+nl,nx+nl),Du(nx+nl,nu),Fu(nx+nl,nu),Dz(nx+nl,nz),
     +        Fz(nx+nl,nz), Rho(nz,nz), Lxx(nx,nx), Lxz(nx,nz),
     +        Llx(nl,nx), Llz(nl,nz), Lux(nu,nx), Luz(nu,nz)


      Character*1 Jobvs, Sort, Sense
	Integer(4) Info, Lwork, fh, nxl, sdim, i, j, k
	Logical Bwork(nx+nl), Select	
      Real(8) Rwork(nx+nl), Cui(nu,nu), Temp1(nx+nl,nx+nl), 
     +        Temp2(nx+nl,nx+nl),R(nx+nl,nz), Tol, rconde, rcondv 
      Complex*16 W(nx+nl,nx+nl), S(nx+nl,nx+nl), T(nx+nl,nx+nl), 
     +           Lambda(nx+nl), 
     +           Ti(nx+nl,nx+nl), Txxi(nx,nx),
     +           Tlxi(nl,nx), Tlli(nl,nl),
     +           Tllii(nl,nl), Q1(nx,nz), Q2(nl,nz),     
     +           Phi(nl,nz), Sll(nl,nl), Llxc(nl,nx), Llzc(nl,nz),
     +           Lxxc(nx,nx), Lxzc(nx,nz), Luxc(nu,nx), 
     +           Luzc(nu,nz),
     +           Temp3(nx+nl,nz), Temp4(1,1:nz), Temp5(nz,nz), 
     +           Temp6(nx+nl,nx)
      Complex*16, allocatable :: work(:)

	TYPE (rccoord) curpos

      External Select

C Tolerance for imaginay parts in the policy functions
      Tol=1.0E-10

C Get Handle of active window to write messages
      fh=GetActiveQQ()

C First Step: Compute the W matrix
      nxl=nx+nl

      Cui=.i.Cu ! This computes the inverse of the matrix Cu, see the ILSM reference on operators

	Temp1=Dxl-MatMul(Du,MatMul(Cui,Cxl))
	Temp1=.i.Temp1
      
	Temp2=Fxl-MatMul(Fu,MatMul(Cui,Cxl))
       
	W=-MatMul(Temp1,Temp2)
      	
      R=Temp1.x.(((Dz+((Du.x.Cui).x.Cz)).x.Rho)+Fz+((Fu.x.Cui).x.Cz))


C Second Step: Get the Schur factorization of W, Note: the Schur
C              matrix is returned in S and the transformation matrix in T,
C              the eigenvalues are in Lambda

C Settings for ZGEES

      Jobvs="V" ! compute transformation matrix
	Sort="S"  ! sort eigenvalues
	LWork=-1  ! compute optimal size of workspace
	Sense="N" ! do not compute condition numbers

	S=W
C Call ZGEESX once to get optimal size of workspace (not, this program was modified by
C AM to provide this functionality.
	allocate(work(1))

	Call ZGEESX( JOBVS, SORT, SELECT, SENSE,nxl, S, nxl, sdim, Lambda,
     $                   T, nxl, RCONDE, RCONDV, WORK, LWORK, RWORK,
     $                   BWORK, INFO )
	Lwork=INT4(Work(1))
	deallocate(work)
      allocate(work(Lwork))
	S=W
c	Lwork=50
	Call ZGEESX( JOBVS, SORT, SELECT, SENSE,nxl, S, nxl, sdim, Lambda,
     $                   T, nxl, RCONDE, RCONDV, WORK, LWORK, RWORK,
     $                   BWORK, INFO )

	deallocate(work)

C Check for uniqueness 
      if (Count(cdabs(lambda(1:nx)).lt.1.0) .lt. nx) then
	   CALL SetTextPosition(2,2,curpos)
	   WRITE(fh,"('Not all of the ',I3,
     +  ' Eigenvalues are within the unit circle')") nx
         FError=1
	   Return
	endif

      if (Count(cdabs(lambda(nx+1:nxl)).gt. 1.0) .lt. nl) then
	   CALL SetTextPosition(3,2,curpos)
         WRITE(fh,"('Not all of the ',I3,
     +  ' Eigenvalues are outside the unit circle')") nl
	   FError=1
	   Return
	endif

C Third Step: Computation of the policy functions
C Partion the Transformation matrix and get the Q1 and Q2 matrices
      Ti=.h.T ! this gives the conjugate transpose of T
      Tlxi=Ti(nx+1:nxl,1:nx)
      Tlli=Ti(nx+1:nxl,nx+1:nxl)
      Tllii=.i.Tlli

	Txxi=T(1:nx,1:nx)
	Txxi=.i.Txxi
	

      Temp3=MatMul(Ti,R)
      Q1=Temp3(1:nx,1:nz)
      Q2=Temp3(nx+1:nxl,1:nz)

C Compute the solution for the lambda_t
      phi=0
	
      Sll=S(nx+1:nxl,nx+1:nxl)
	do i=nl,1,-1

        Temp4(1,1:nz)=0

        Do j=i+1,nl
	     Do k=1,nz
             Temp4(1,k)=Temp4(1,k)+Sll(i,j)*Phi(j,k)          
	     End Do
        End Do
 	  Temp5=Rho-Sll(i,i)*Eye(nz)
	  Temp5=.i.Temp5
	  Phi(i,1:nz)=(Q2(i,1:nz)+Temp4(1,1:nz)).x.Temp5
        
      End Do

       Llxc=-MatMul(Tllii,Tlxi)
       Llzc= MatMul(Tllii,Phi)
	 Lxxc=(T(1:nx,1:nx).x.S(1:nx,1:nx)).x.Txxi
	 Lxzc=(W(1:nx,nx+1:nxl).x.Llzc) + R(1:nx,1:nz)
	 Temp6(1:nx,1:nx)=Eye(nx)
	 Temp6(nx+1:nxl,1:nx)=Llxc(1:nl,1:nx)
       Luxc=(Cui.x.Cxl).x.Temp6
       Temp3=0
	 Temp3(nx+1:nxl,1:nz)=Llzc(1:nl,1:nz)
	 Luzc=((Cui.x.Cxl).x.Temp3) + (Cui.x.Cz)

C Check for complex coefficients
      If (Count(Dabs(Imag(Llxc)).gt.Tol).gt.0) then
	   Call SetTextPosition(4,2,curpos)
	   Write(fh,"('Complex Coefficients in Llx')")
	   FError=1
	   Return
	else
	   Llx=DBLE(Llxc)
	Endif

      If (Count(Dabs(Imag(Llzc)).gt.Tol).gt.0) then
	   Call SetTextPosition(4,2,curpos)
	   Write(fh,"('Complex Coefficients in Llz')")
	   FError=1
	   Return
	else
	   Llz=DBLE(Llzc)	   
	Endif
      
	If (Count(Dabs(Imag(Lxxc)).gt.Tol).gt.0) then
	   Call SetTextPosition(4,2,curpos)
	   Write(fh,"('Complex Coefficients in Lxx')")
	   FError=1
	   Return
	else
	   Lxx=DBLE(Lxxc)	
	Endif

	If (Count(Dabs(Imag(Lxzc)).gt.Tol).gt.0) then
	   Call SetTextPosition(4,2,curpos)
	   Write(fh,"('Complex Coefficients in Lxz')")
	   FError=1
	   Return
	else
	   Lxz=DBLE(Lxzc)	   
	Endif

	If (Count(Dabs(Imag(Luxc)).gt.Tol).gt.0) then
	   Call SetTextPosition(4,2,curpos)
	   Write(fh,"('Complex Coefficients in Lux')")
	   FError=1
	   Return
	else
	   Lux=DBLE(Luxc)	   
	Endif

	If (Count(Dabs(Imag(Luzc)).gt.Tol).gt.0) then
	   Call SetTextPosition(4,2,curpos)
	   Write(fh,"('Complex Coefficients in Luz')")
	   FError=1
	   Return
	else
	   Luz=DBLE(Luzc)	
	Endif

      End Subroutine


	Logical Function SELECT(X)
	
	Complex(8) X
		
      If (CDABS(X).le.1.0) then
        SELECT=.TRUE.
	else
	  SELECT=.FALSE.
	endif

	RETURN

	END FUNCTION


C*************************************************************************************************

      SUBROUTINE ZGEESX( JOBVS, SORT, SELECT, SENSE, N, A, LDA, SDIM, W,
     $                   VS, LDVS, RCONDE, RCONDV, WORK, LWORK, RWORK,
     $                   BWORK, INFO )
*
*  -- LAPACK driver routine (version 3.0) --
*     Univ. of Tennessee, Univ. of California Berkeley, NAG Ltd.,
*     Courant Institute, Argonne National Lab, and Rice University
*     June 30, 1999
*     8-15-00:  Do WS calculations if LWORK = -1 (eca)
*
*     .. Scalar Arguments ..
      CHARACTER          JOBVS, SENSE, SORT
      INTEGER            INFO, LDA, LDVS, LWORK, N, SDIM
      DOUBLE PRECISION   RCONDE, RCONDV
*     ..
*     .. Array Arguments ..
      LOGICAL            BWORK( * )
      DOUBLE PRECISION   RWORK( * )
      COMPLEX*16         A( LDA, * ), VS( LDVS, * ), W( * ), WORK( * )
*     ..
*     .. Function Arguments ..
      LOGICAL            SELECT
      EXTERNAL           SELECT
*     ..
*
*  Purpose
*  =======
*
*  ZGEESX computes for an N-by-N complex nonsymmetric matrix A, the
*  eigenvalues, the Schur form T, and, optionally, the matrix of Schur
*  vectors Z.  This gives the Schur factorization A = Z*T*(Z**H).
*
*  Optionally, it also orders the eigenvalues on the diagonal of the
*  Schur form so that selected eigenvalues are at the top left;
*  computes a reciprocal condition number for the average of the
*  selected eigenvalues (RCONDE); and computes a reciprocal condition
*  number for the right invariant subspace corresponding to the
*  selected eigenvalues (RCONDV).  The leading columns of Z form an
*  orthonormal basis for this invariant subspace.
*
*  For further explanation of the reciprocal condition numbers RCONDE
*  and RCONDV, see Section 4.10 of the LAPACK Users' Guide (where
*  these quantities are called s and sep respectively).
*
*  A complex matrix is in Schur form if it is upper triangular.
*
*  Arguments
*  =========
*
*  JOBVS   (input) CHARACTER*1
*          = 'N': Schur vectors are not computed;
*          = 'V': Schur vectors are computed.
*
*  SORT    (input) CHARACTER*1
*          Specifies whether or not to order the eigenvalues on the
*          diagonal of the Schur form.
*          = 'N': Eigenvalues are not ordered;
*          = 'S': Eigenvalues are ordered (see SELECT).
*
*  SELECT  (input) LOGICAL FUNCTION of one COMPLEX*16 argument
*          SELECT must be declared EXTERNAL in the calling subroutine.
*          If SORT = 'S', SELECT is used to select eigenvalues to order
*          to the top left of the Schur form.
*          If SORT = 'N', SELECT is not referenced.
*          An eigenvalue W(j) is selected if SELECT(W(j)) is true.
*
*  SENSE   (input) CHARACTER*1
*          Determines which reciprocal condition numbers are computed.
*          = 'N': None are computed;
*          = 'E': Computed for average of selected eigenvalues only;
*          = 'V': Computed for selected right invariant subspace only;
*          = 'B': Computed for both.
*          If SENSE = 'E', 'V' or 'B', SORT must equal 'S'.
*
*  N       (input) INTEGER
*          The order of the matrix A. N &gt;= 0.
*
*  A       (input/output) COMPLEX*16 array, dimension (LDA, N)
*          On entry, the N-by-N matrix A.
*          On exit, A is overwritten by its Schur form T.
*
*  LDA     (input) INTEGER
*          The leading dimension of the array A.  LDA &gt;= max(1,N).
*
*  SDIM    (output) INTEGER
*          If SORT = 'N', SDIM = 0.
*          If SORT = 'S', SDIM = number of eigenvalues for which
*                         SELECT is true.
*
*  W       (output) COMPLEX*16 array, dimension (N)
*          W contains the computed eigenvalues, in the same order
*          that they appear on the diagonal of the output Schur form T.
*
*  VS      (output) COMPLEX*16 array, dimension (LDVS,N)
*          If JOBVS = 'V', VS contains the unitary matrix Z of Schur
*          vectors.
*          If JOBVS = 'N', VS is not referenced.
*
*  LDVS    (input) INTEGER
*          The leading dimension of the array VS.  LDVS &gt;= 1, and if
*          JOBVS = 'V', LDVS &gt;= N.
*
*  RCONDE  (output) DOUBLE PRECISION
*          If SENSE = 'E' or 'B', RCONDE contains the reciprocal
*          condition number for the average of the selected eigenvalues.
*          Not referenced if SENSE = 'N' or 'V'.
*
*  RCONDV  (output) DOUBLE PRECISION
*          If SENSE = 'V' or 'B', RCONDV contains the reciprocal
*          condition number for the selected right invariant subspace.
*          Not referenced if SENSE = 'N' or 'E'.
*
*  WORK    (workspace/output) COMPLEX*16 array, dimension (LWORK)
*          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
*
*  LWORK   (input) INTEGER
*          The dimension of the array WORK.  LWORK &gt;= max(1,2*N).
*          Also, if SENSE = 'E' or 'V' or 'B', LWORK &gt;= 2*SDIM*(N-SDIM),
*          where SDIM is the number of selected eigenvalues computed by
*          this routine.  Note that 2*SDIM*(N-SDIM) &lt;= N*N/2.
*          For good performance, LWORK must generally be larger.
*
*          If LWORK = -1, a workspace query is assumed.  The optimal
*          size for the WORK array is calculated and stored in WORK(1),
*          and no other work except argument checking is performed.
*
*  RWORK   (workspace) DOUBLE PRECISION array, dimension (N)
*
*  BWORK   (workspace) LOGICAL array, dimension (N)
*          Not referenced if SORT = 'N'.
*
*  INFO    (output) INTEGER
*          = 0: successful exit
*          &lt; 0: if INFO = -i, the i-th argument had an illegal value.
*          &gt; 0: if INFO = i, and i is
*             &lt;= N: the QR algorithm failed to compute all the
*                   eigenvalues; elements 1:ILO-1 and i+1:N of W
*                   contain those eigenvalues which have converged; if
*                   JOBVS = 'V', VS contains the transformation which
*                   reduces A to its partially converged Schur form.
*             = N+1: the eigenvalues could not be reordered because some
*                   eigenvalues were too close to separate (the problem
*                   is very ill-conditioned);
*             = N+2: after reordering, roundoff changed values of some
*                   complex eigenvalues so that leading eigenvalues in
*                   the Schur form no longer satisfy SELECT=.TRUE.  This
*                   could also be caused by underflow due to scaling.
*
*  =====================================================================
*
*     .. Parameters ..
      INTEGER            LQUERV
      PARAMETER          ( LQUERV = -1 )
      DOUBLE PRECISION   ZERO, ONE
      PARAMETER          ( ZERO = 0.0D0, ONE = 1.0D0 )
*     ..
*     .. Local Scalars ..
      LOGICAL            SCALEA, WANTSB, WANTSE, WANTSN, WANTST, WANTSV,
     $                   WANTVS
      INTEGER            HSWORK, I, IBAL, ICOND, IERR, IEVAL, IHI, ILO,
     $                   ITAU, IWRK, K, MAXB, MAXWRK, MINWRK
      DOUBLE PRECISION   ANRM, BIGNUM, CSCALE, EPS, SMLNUM
*     ..
*     .. Local Arrays ..
      DOUBLE PRECISION   DUM( 1 )
*     ..
*     .. External Subroutines ..
      EXTERNAL           DLABAD, DLASCL, XERBLA, ZCOPY, ZGEBAK, ZGEBAL,
     $                   ZGEHRD, ZHSEQR, ZLACPY, ZLASCL, ZTRSEN, ZUNGHR
*     ..
*     .. External Functions ..
      LOGICAL            LSAME
      INTEGER            ILAENV
      DOUBLE PRECISION   DLAMCH, ZLANGE
      EXTERNAL           LSAME, ILAENV, DLAMCH, ZLANGE
*     ..
*     .. Intrinsic Functions ..
      INTRINSIC          MAX, MIN, SQRT
*     ..
*     .. Executable Statements ..
*
*     Test the input arguments
*
      INFO = 0
      WANTVS = LSAME( JOBVS, 'V' )
      WANTST = LSAME( SORT, 'S' )
      WANTSN = LSAME( SENSE, 'N' )
      WANTSE = LSAME( SENSE, 'E' )
      WANTSV = LSAME( SENSE, 'V' )
      WANTSB = LSAME( SENSE, 'B' )
      IF( ( .NOT.WANTVS ) .AND. ( .NOT.LSAME( JOBVS, 'N' ) ) ) THEN
         INFO = -1
      ELSE IF( ( .NOT.WANTST ) .AND. ( .NOT.LSAME( SORT, 'N' ) ) ) THEN
         INFO = -2
      ELSE IF( .NOT.( WANTSN .OR. WANTSE .OR. WANTSV .OR. WANTSB ) .OR.
     $         ( .NOT.WANTST .AND. .NOT.WANTSN ) ) THEN
         INFO = -4
      ELSE IF( N.LT.0 ) THEN
         INFO = -5
      ELSE IF( LDA.LT.MAX( 1, N ) ) THEN
         INFO = -7
      ELSE IF( LDVS.LT.1 .OR. ( WANTVS .AND. LDVS.LT.N ) ) THEN
         INFO = -11
      END IF
*
*     Compute workspace
*      (Note: Comments in the code beginning "Workspace:" describe the
*       minimal amount of real workspace needed at that point in the
*       code, as well as the preferred amount for good performance.
*       CWorkspace refers to complex workspace, and RWorkspace to real
*       workspace. NB refers to the optimal block size for the
*       immediately following subroutine, as returned by ILAENV.
*       HSWORK refers to the workspace preferred by ZHSEQR, as
*       calculated below. HSWORK is computed assuming ILO=1 and IHI=N,
*       the worst case.
*       If SENSE = 'E', 'V' or 'B', then the amount of workspace needed
*       depends on SDIM, which is computed by the routine ZTRSEN later
*       in the code.)
*
      MINWRK = 1
      IF( INFO.EQ.0 ) THEN
         MAXWRK = N + N*ILAENV( 1, 'ZGEHRD', ' ', N, 1, N, 0 )
         MINWRK = MAX( 1, 2*N )
         IF( .NOT.WANTVS ) THEN
            MAXB = MAX( ILAENV( 8, 'ZHSEQR', 'SN', N, 1, N, -1 ), 2 )
            K = MIN( MAXB, N, MAX( 2, ILAENV( 4, 'ZHSEQR', 'SN', N, 1,
     $          N, -1 ) ) )
            HSWORK = MAX( K*( K+2 ), 2*N )
            MAXWRK = MAX( MAXWRK, HSWORK, 1 )
         ELSE
            MAXWRK = MAX( MAXWRK, N+( N-1 )*
     $               ILAENV( 1, 'ZUNGHR', ' ', N, 1, N, -1 ) )
            MAXB = MAX( ILAENV( 8, 'ZHSEQR', 'SV', N, 1, N, -1 ), 2 )
            K = MIN( MAXB, N, MAX( 2, ILAENV( 4, 'ZHSEQR', 'SV', N, 1,
     $          N, -1 ) ) )
            HSWORK = MAX( K*( K+2 ), 2*N )
            MAXWRK = MAX( MAXWRK, HSWORK, 1 )
         END IF
*
*        Estimate the workspace needed by ZTRSEN.
*
         IF( WANTST ) THEN
            MAXWRK = MAX( MAXWRK, ( N*N+1 ) / 2 )
         END IF
         WORK( 1 ) = MAXWRK
         IF( LWORK.LT.MINWRK .AND. LWORK.NE.LQUERV )
     $      INFO = -15
      END IF
*
*     Quick returns
*
      IF( INFO.NE.0 ) THEN
         CALL XERBLA( 'ZGEESX', -INFO )
         RETURN
      END IF
      IF( LWORK.EQ.LQUERV )
     $   RETURN
      IF( N.EQ.0 ) THEN
         SDIM = 0
         RETURN
      END IF
*
*     Get machine constants
*
      EPS = DLAMCH( 'P' )
      SMLNUM = DLAMCH( 'S' )
      BIGNUM = ONE / SMLNUM
      CALL DLABAD( SMLNUM, BIGNUM )
      SMLNUM = SQRT( SMLNUM ) / EPS
      BIGNUM = ONE / SMLNUM
*
*     Scale A if max element outside range [SMLNUM,BIGNUM]
*
      ANRM = ZLANGE( 'M', N, N, A, LDA, DUM )
      SCALEA = .FALSE.
      IF( ANRM.GT.ZERO .AND. ANRM.LT.SMLNUM ) THEN
         SCALEA = .TRUE.
         CSCALE = SMLNUM
      ELSE IF( ANRM.GT.BIGNUM ) THEN
         SCALEA = .TRUE.
         CSCALE = BIGNUM
      END IF
      IF( SCALEA )
     $   CALL ZLASCL( 'G', 0, 0, ANRM, CSCALE, N, N, A, LDA, IERR )
*
*
*     Permute the matrix to make it more nearly triangular
*     (CWorkspace: none)
*     (RWorkspace: need N)
*
      IBAL = 1
      CALL ZGEBAL( 'P', N, A, LDA, ILO, IHI, RWORK( IBAL ), IERR )
*
*     Reduce to upper Hessenberg form
*     (CWorkspace: need 2*N, prefer N+N*NB)
*     (RWorkspace: none)
*
      ITAU = 1
      IWRK = N + ITAU
      CALL ZGEHRD( N, ILO, IHI, A, LDA, WORK( ITAU ), WORK( IWRK ),
     $             LWORK-IWRK+1, IERR )
*
      IF( WANTVS ) THEN
*
*        Copy Householder vectors to VS
*
         CALL ZLACPY( 'L', N, N, A, LDA, VS, LDVS )
*
*        Generate unitary matrix in VS
*        (CWorkspace: need 2*N-1, prefer N+(N-1)*NB)
*        (RWorkspace: none)
*
         CALL ZUNGHR( N, ILO, IHI, VS, LDVS, WORK( ITAU ), WORK( IWRK ),
     $                LWORK-IWRK+1, IERR )
      END IF
*
      SDIM = 0
*
*     Perform QR iteration, accumulating Schur vectors in VS if desired
*     (CWorkspace: need 1, prefer HSWORK (see comments) )
*     (RWorkspace: none)
*
      IWRK = ITAU
      CALL ZHSEQR( 'S', JOBVS, N, ILO, IHI, A, LDA, W, VS, LDVS,
     $             WORK( IWRK ), LWORK-IWRK+1, IEVAL )
      IF( IEVAL.GT.0 )
     $   INFO = IEVAL
*
*     Sort eigenvalues if desired
*
      IF( WANTST .AND. INFO.EQ.0 ) THEN
         IF( SCALEA )
     $      CALL ZLASCL( 'G', 0, 0, CSCALE, ANRM, N, 1, W, N, IERR )
         DO 10 I = 1, N
            BWORK( I ) = SELECT( W( I ) )
   10    CONTINUE
*
*        Reorder eigenvalues, transform Schur vectors, and compute
*        reciprocal condition numbers
*        (CWorkspace: if SENSE is not 'N', need 2*SDIM*(N-SDIM)
*                     otherwise, need none )
*        (RWorkspace: none)
*
         CALL ZTRSEN( SENSE, JOBVS, BWORK, N, A, LDA, VS, LDVS, W, SDIM,
     $                RCONDE, RCONDV, WORK( IWRK ), LWORK-IWRK+1,
     $                ICOND )
         IF( .NOT.WANTSN )
     $      MAXWRK = MAX( MAXWRK, 2*SDIM*( N-SDIM ) )
         IF( ICOND.EQ.-14 ) THEN
*
*           Not enough complex workspace
*
            INFO = -15
         END IF
      END IF
*
      IF( WANTVS ) THEN
*
*        Undo balancing
*        (CWorkspace: none)
*        (RWorkspace: need N)
*
         CALL ZGEBAK( 'P', 'R', N, ILO, IHI, RWORK( IBAL ), N, VS, LDVS,
     $                IERR )
      END IF
*
      IF( SCALEA ) THEN
*
*        Undo scaling for the Schur form of A
*
         CALL ZLASCL( 'U', 0, 0, CSCALE, ANRM, N, N, A, LDA, IERR )
         CALL ZCOPY( N, A, LDA+1, W, 1 )
         IF( ( WANTSV .OR. WANTSB ) .AND. INFO.EQ.0 ) THEN
            DUM( 1 ) = RCONDV
            CALL DLASCL( 'G', 0, 0, CSCALE, ANRM, 1, 1, DUM, 1, IERR )
            RCONDV = DUM( 1 )
         END IF
      END IF
*
      WORK( 1 ) = MAXWRK
      RETURN
*
*     End of ZGEESX
*
      END
