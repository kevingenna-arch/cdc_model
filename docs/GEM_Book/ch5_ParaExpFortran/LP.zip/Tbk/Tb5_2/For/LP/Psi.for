C Psi.for: definition of the various functions that approximate
C          Psi1(gamma,x), Psi2(gamma,x), and Psi3(gamma,x)

	Module PsiDef

	Character(4) Name(21), Name2(14)
	Integer(2)   Coef(21,3)	

	DATA Name2/'k','m','x','z','k^2','m^2','x^2','z^2','k*m','k*x','k*z','m*x','m*z','x*z'/

	End Module PsiDef


C GetPsi: read in names and size of Psi1 to Psi3

	Subroutine GetPsi()

	use Par
	use PsiDef

	Integer(2) i

	open(14,file='PsiDef.txt')
	do i=1,21
		read(14,"(A4,1X,I1,1X,I1,1X,I1))") Name(i), Coef(i,1), Coef(i,2), Coef(i,3)
	end do

	close(14)

	Npar1=Sum(Coef(1:21,1))
	Npar2=Sum(Coef(1:21,2))
	Npar3=Sum(Coef(1:21,3))

	return

	End Subroutine

C PrintPsi: prints result to file
	Subroutine PrintPsi(i,n,gamma,tgamma)

	use Par
	use PsiDef

	Integer(4) i, n
	Real(8) gamma(n), tgamma(n)

	Integer(4) j, k

	k=0

	do j=1,21

		if (Coef(j,i).eq.1) then
			k=k+1
			write(15,"(A4,1X,F10.4)") Name(j), gamma(k)
			write(15,"('      (',F8.2,')')") tgamma(k)
		End if

	End Do

	Return

	End Subroutine


	

C Psi: Defines Psi
	Real(8) Function Psi(i,n,Gamma,xs)

	use Par
	use PsiDef

	Integer(4) i, n
	Real(8) Gamma(1:n), xs(1:5)

	Integer(4) k

	k=0

	Psi=0.0

	If (Coef(1,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)
	endif

	if (Coef(2,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(1))
	End if

	if (Coef(3,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(2))
	End if

	if (Coef(4,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(3))
	End if

	if (Coef(5,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(4))
	End if

	if (Coef(6,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(5))
	End if

	if (Coef(7,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(1))*dlog(xs(1))
	End if

	if (Coef(8,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(2))*dlog(xs(2))
	End if

	if (Coef(9,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(3))*dlog(xs(3))
	End if

	if (Coef(10,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(4))*dlog(xs(4))
	End if

	if (Coef(11,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(5))*dlog(xs(5))
	End if

	if (Coef(12,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(1))*dlog(xs(2))
	End if

	if (Coef(13,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(1))*dlog(xs(3))
	End if

	if (Coef(14,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(1))*dlog(xs(4))
	End if

	if (Coef(15,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(1))*dlog(xs(5))
	End if

	if (Coef(16,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(2))*dlog(xs(3))
	End if

	if (Coef(17,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(2))*dlog(xs(4))
	End if

	if (Coef(18,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(2))*dlog(xs(5))
	End if

	if (Coef(19,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(3))*dlog(xs(4))
	End if

	if (Coef(20,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(3))*dlog(xs(5))
	End if

	if (Coef(21,i).eq.1) then
		k=k+1
		Psi=Psi+gamma(k)*dlog(xs(4))*dlog(xs(5))
	End if

	Psi=beta*(a**(-eta))*dexp(Psi)

	Return

	End Function



C Psi1: returns Psi1(Par1,xt(t,1:5)) in the case of a first degree polynomial
      
	Real(8) Function Psi1(gamma,xs)

      use Par

      Real(8) gamma(Npar1), xs(5)

	Integer(4) i
	Real(8) Psi

	External Psi

	i=1
      
	Psi1=Psi(i,Npar1,gamma,xs)

	Return

	End Function

C Psi2: returns Psi2(Par2,xt(t,1:5)) in the case of a first degree polynomial
      
	Real(8) Function Psi2(gamma,xs)

      use Par

      Real(8) gamma(Npar2), xs(5)

	Integer(4) i
	Real(8) Psi

	External Psi

	i=2

	Psi2=Psi(i,Npar2,gamma,xs)

	Return

	End Function

C Psi3: returns Psi3(Par3,xt(t,1:5)) in the case of a first degree polynomial
      
	Real(8) Function Psi3(gamma,xs)

      use Par

      Real(8) gamma(Npar3), xs(5)

	Integer(4) i
	Real(8) Psi

	External Psi

	i=3

	Psi3=Psi(i,Npar3,gamma,xs)

	Return
	End Function


C dPsi: computes the gradient of Psi
      
	Subroutine dPsi(i,n,Gamma,xs,g)

	use PsiDef	
	use Par

	Integer(4) i, n
	Real(8) Gamma(1:n), xs(1:5), g(1:n), Psi

      External Psi

      Integer(4) k
	Real(8) temp

	k=0	
	temp=Psi(i,n,gamma,xs)

	If (Coef(1,i).eq.1) then
		k=k+1
		g(k)=temp
	endif

	if (Coef(2,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(1))
	End if

	if (Coef(3,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(2))
	End if

	if (Coef(4,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(3))
	End if

	if (Coef(5,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(4))
	End if

	if (Coef(6,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(5))
	End if

	if (Coef(7,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(1))*dlog(xs(1))
	End if

	if (Coef(8,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(2))*dlog(xs(2))
	End if

	if (Coef(9,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(3))*dlog(xs(3))
	End if

	if (Coef(10,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(4))*dlog(xs(4))
	End if

	if (Coef(11,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(5))*dlog(xs(5))
	End if

	if (Coef(12,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(1))*dlog(xs(2))
	End if

	if (Coef(13,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(1))*dlog(xs(3))
	End if

	if (Coef(14,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(1))*dlog(xs(4))
	End if

	if (Coef(15,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(1))*dlog(xs(5))
	End if

	if (Coef(16,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(2))*dlog(xs(3))
	End if

	if (Coef(17,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(2))*dlog(xs(4))
	End if

	if (Coef(18,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(2))*dlog(xs(5))
	End if

	if (Coef(19,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(3))*dlog(xs(4))
	End if

	if (Coef(20,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(3))*dlog(xs(5))
	End if

	if (Coef(21,i).eq.1) then
		k=k+1
		g(k)=temp*dlog(xs(4))*dlog(xs(5))
	End if	

	Return

      End Subroutine
	

C dPsi1: computes the gradient of Psi1
      
	Subroutine dPsi1(Gamma,xs,g)
	
	use Par

	Real(8) Gamma(Npar1), xs(5), g(Npar1)

	Integer(4) i

	i=1
      
	Call dPsi(i,Npar1,gamma,xs,g)

      Return

	End Subroutine

C dPsi2: computes the gradient of Psi2
      
	Subroutine dPsi2(Gamma,xs,g)
	
	use Par

	Real(8) Gamma(Npar2), xs(5), g(Npar2)

	Integer(4) i

	i=2
      
	Call dPsi(i,Npar2,gamma,xs,g)

      Return

	End Subroutine

C dPsi3: computes the gradient of Psi3
      
	Subroutine dPsi3(Gamma,xs,g)
	
	use Par

	Real(8) Gamma(Npar3), xs(5), g(Npar3)

	Integer(4) i

	i=3
      
	Call dPsi(i,Npar3,gamma,xs,g)

      Return

	End Subroutine

