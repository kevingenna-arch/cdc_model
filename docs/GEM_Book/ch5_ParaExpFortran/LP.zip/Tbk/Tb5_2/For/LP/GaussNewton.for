C GaussNewton.for
C
C This file contains the source code and module
C defintions that implement the damped Gauss-Newton algorithm
C explained in Chapter 2.2.2 of Heer and Maussner

C The module GNPars holds the parameters used by the
C algorithm. You can change any of them by changing
C the parameter asignment.

      Module GNP

	Integer(4), Parameter :: GN_Maxit=500 ! maximum number of iterations
	Real(8), Parameter :: GN_ParTol=1.0e-10  ! convergence criterium 2
	Real(8), Parameter :: GN_GradTol=1.0e-6  ! convergence criterium 1
	Logical GN_Print, GN_vc

	Data GN_Print/.true./GN_vc/.false./

	End Module GNP

C GaussNewton
C
C Solves a non-linear least squares problem using
C the damped Gauss-Newton algorithm
C
C Usage: Call GaussNewton(m,n,x0,typx,typS,f,df,x1,tx1,crit)
C
C Input:   m, Integer(4), number of parameters
C          n, Integer(4), numboer of observations
C         x0, Real(8), m times 1 vector, starting parameters
C       typx, Real(8), m timex 1 vector, the typical elements of x
C       typS, Real(8), the typical size of S
C          f, pointer to the function that returns y-F(.,x),
C             usage must be Call f(m,n,,x, fx), where fx=y-F(.,x) is
C             a Real(8) n times 1 vector
C         df, pointer to the function that returns the
C             gradient of F(.,x) with respect to x, usage
C             must be Call df(m,n,x,xx), where xx is a Real(8)
C             n times m matrix.
C
C Output: x1, Real(8), m times 1 vector, the final parameter estimate
C        tx1, Real(8), m times 1 vector, t-ratios
C         crit(1), error code
C                  where: 1: it was not possible to solve the linear system
C                         2: step size smaller than step tolerance but
C                            gradient different from zero
C                         3: parameter estimate converged to non-optimal point
C                         4: maximum number of iterations exceeded
C                         5: it was not possible to evaluate the function f
C         crit(2), MaxRelGrad
C         crit(3), Sum of squarred errors
C         crit(4), |dx/x|
C         crit(5), number of iterations

            

	SUBROUTINE GaussNewton(m,n,x0,typx,typS,f,df,x1,tx1,crit)

      use GNP
      use DFLIB
      use IMSLF90
	use Errors

	Integer(4) m, n
	Real(8) x0(m), typx(m), x1(m), tx1(m), typS, crit(6)

	INTEGER(4) I, step, fh, iercd	
	INTEGER(2) Inkey
      Real(8) x2(1:m), dx(1:m), xy(1:n), xx(1:n,1:m), bvec(1:m), 
     +        amat(1:m,1:m), sx, gradS(1:m), lambda1, lambda2, vc(1:m,1:m), sighut
	Real(8) Contest1, Contest2, GN_MinStep
	      
      External f, df

      TYPE (rccoord) curpos	

C Initialize
	      
	fh=GetActiveQQ() ! Handle of active window to write messages
	if (GN_Print) then
         fh=GetActiveQQ() ! Handle of active window to write messages      
c	   Call ClearScreen($GCLEARSCREEN)
	   CALL SETTEXTPOSITION(1,1,curpos)
	   WRITE(fh,*) 'Algorithm Damped Gauss-Newton'
	endif

      crit=1.0
             
      x1=x0
	dx=x0	      
      
C Change Error Behavior of DLSADS
      Call Erset(0,0,0)      
      Call UMACH(-3,fh)
      FError=0
      Call  f(m,n,x1,xy) ! vector of errors
	if (FError .ne. 0) then
	  crit(1)=5.0
	  return
	endif
	Call df(m,n,x1,xx) ! matrix xbar (gradient of f at x1)
	sx=Dot_Product(xy,xy) ! sum of squared errors
	sx=dble(sx/n)
	crit(3)=sx
	gradS=MATMUL(Transpose(xx),xy)
	gradS=-2.0*dble(gradS/n) ! gradient of S(x), the sum of squared errors
      	
C Gauss-Newton Iterationens
	do Step=1,GN_Maxit,1

	if (GN_Print) then
		Call SetTextPosition(2,1,curpos)
		write(fh,"('GN-Iteration=',I4)") Step
		write(11,"('GN-Iteration=',I4)") Step		
	Endif
C	   Call DLSVRR(n,m,xx,n,ipath,tol,irank,smat,umat,n,vmat,m)
      Bvec=MATMUL(TRANSPOSE(xx),xy)
	Amat=MATMUL(TRANSPOSE(xx),xx)	   
      CALL DLSADS(m, Amat, m, Bvec, dx) !compute new vector
	Select Case (IERCD())
		Case(1)
			If (GN_Print) then
				Call SetTextposition(3,1,curpos)
				WRITE(fh,"('Warning: ill conditioned matrix')")
				WRITE(11,"('Warning: ill conditioned matrix')")
			Endif
		Case(2)
			crit(1)=1.
			exit
	End Select		
	Lambda1=GN_MinStep(m,x1,typx,dx)
	CALL GNStep(m,n,x1,dx,f,sx,gradS,lambda1,lambda2,crit(3)) ! compute stepsize
      
	if (GN_Print) then
		Call SetTextPosition(4,1,curpos)
		Write(fh,"('Stepsize= ',D15.5)") lambda2
		Write(11,"('Stepsize= ',D15.5)") lambda2
	endif
	dx=lambda2*dx	   
	x2=x1+dx	   
      Call  f(m,n,x2,xy)
	sx=Dot_Product(xy,xy)
	sx=dble(sx/n)
	crit(3)=sx

	Call df(m,n,x2,xx)
      gradS=MATMUL(Transpose(xx),xy)
	gradS=-2.0*dble(gradS/n)
      crit(2)=ConTest2(m,gradS,x2,sx,typx,typS)
	crit(4)=ConTest1(m,x1,x2,typx)
	if (GN_Print) then
		Call SetTextPosition(5,1,curpos)
		Write(fh,"('RelGrad= ',D15.7)") crit(2)
		Write(11,"('RelGrad= ',D15.7)") crit(2)
		Call SetTextPosition(6,1,curpos)
		Write(fh,"('|dx/x| = ',D15.7)") crit(4)
		Write(11,"('|dx/x| = ',D15.7)") crit(4)
		Call SetTextPosition(7,1,curpos)
		Write(fh,"('S(x)   = ',D15.7)") crit(3)
		Write(11,"('S(x)   = ',D15.7)") crit(3)		
	Endif   
	if (crit(2) .lt. GN_GradTol) then 	   
		crit(1)=0.0
		x1=x2
		if (GN_vc) then !c compute t-ratios
			sighut=(dble(n)/dble(n-m))*sx
			Amat=MatMul(Transpose(xx),xx)
			Call DLINRG(m,Amat,m,vc,m)
			vc=sighut*vc
			do i=1,m
				tx1(i)=x2(i)/dsqrt(vc(i,i))
			end do
		endif
		exit	      
		elseif ((Lambda2.lt.Lambda1) .and. (Lambda1.lt.1.0)) then
	      crit(1)=2
	endif
	  
	x1=x2            

	crit(5)=crit(5)+1.

      End Do

      If (Step .gt. GN_Maxit) crit(1)=4.
      
C Reset Error Behavior of DLSADS
      Call Erset(0,2,2)

      Return
	End Subroutine

C GNStep: Find the step size for the Gauss-Newton Iterations
C           
C Usage: Call GNStep(m,n,x,dx,f,fin,gradS,sl,s,fout)
C
C Input: m, Integer(4), number of parameters
C        n, Integer(4), number of observations
C        x, Real(8), m times 1 vector of paramters
C       dx, Real(8), m times 1 vector, change of parameters
C        f, pointer to the function that returns y-F(.,x) in
C           a n times 1 vector
C      fin, Real(8), sum of squared errors at x 
C    gradS, Real(8), m times 1 vector, the gradient of S(x)
C     sl  , step tolerance
C
C Ouput: s, Real(8), the step size
C     fout, Real(8), sum of squared errors at x+s*dx
C
         
      Subroutine GNStep(m,n,x,dx,f,fin,gradS,sl,s,fx2)

      use GNP
      use IMSLF90 	
	use Errors

	Integer(4) m, n
	Real(8) x(m), dx(m), fin, gradS(m), s, sl

	Real(8) x1(m), s1, s2, smult, smin, smax, amat(2,2), bvec(1:2,1),
     +        ab(1:2,1), xy(1:n), fx0, fx1, fx2, 
     +        dfs

	External f


C Initialize      
	smult=1.0e-4	
	smin=0.10
	smax=0.5
            
	fx0=fin
	dfs=dot_product(GradS,dx) 
	
	s1=1.0
	FError=0		
      Call F(m,n,x+dx,xy)	
	Do while ((FError .ne. 0) .and. (s1 .gt. sl)) ! backtracking until f can be evaluated at x+s1*dx
	   s1=0.75*s1
	   FError=0
	   Call F(m,n,x+s1*dx,xy)
	end do
	if (s1 .lt. sl) return

	dx=s1*dx
      s1=1.

      fx1=Dot_Product(xy,xy)
	fx1=dble(fx1/n)
      
	if (fx1 .gt. (fx0+smult*dfs)) then
	   s=-dfs/(2*(fx1-fx0-dfs))
	   if (s .lt. smin) s=smin
	   if (s .gt. smax) s=smax
	   x1=x+s*dx
	   Call F(m,n,x1,xy)
	   fx2=Dot_Product(xy,xy)
	   fx2=dble(fx2/n)
	else
	   s=s1	
	   fx2=fx1
	   return
	endif
      s2=s
	do while (fx2 .gt. (fx0+smult*s2*dfs)) 
	   Amat(1,1)=1/(s2**2)
	   Amat(1,2)=-1/(s1**2)
	   Amat(2,1)=-s1/(s2**2)
	   Amat(2,2)=s2/(s1**2)
	   Bvec(1,1)=fx2-s2*dfs-fx0
	   Bvec(2,1)=fx1-s1*dfs-fx0
         ab=MatMul(Amat,Bvec)/(s2-s1)
	   if (ab(1,1) .eq. 0.0) then
            s=-dfs/(2*ab(2,1))
	   else
	      s=(-ab(2,1)+dsqrt((ab(2,1)**2)-3*ab(1,1)*dfs))/(3*ab(1,1))
	   endif
	   if (s .lt. s2*smin) s=s2*smin
	   if (s .gt. s2*smax) s=s2*smax
         if (s .lt. sl) return
	   s2=s
         fx1=fx2
	   x1=x+s2*dx
	   Call F(m,n,x1,xy)
	   fx2=Dot_Product(xy,xy)
	   fx2=dble(fx2/n)
	
      end do

	End Subroutine

C ConTest1: implements the parameter convergence criterium
C           from Dennis and Schnabel (1983), p. 160
C
C usage: converge=ConTest1(nx,x0,x1,typx)
C
C Input: nx, Integer(4), the number of elements in x0, x1, and typx
C        x0, Real(8) vector with nx elements, the first value of x
C        x1, Real(8) vector with nx elements, the second value of x
C       typ, Real(8) vector with nx elements, the typical values of x(i)
C
C Output: Real(8), the minimal value of the convergence criterium

      Real(8) Function ConTest1(nx,x0,x1,typx) 

	Integer(4) nx
	Real(8) x0(nx), x1(nx), typx(nx)

	Integer(4) i
	Real(8) converge, temp

      converge=0.0

	Do i=1,nx
	   temp=dabs(x1(i)-x0(i))/dmax1(dabs(x1(i)),dabs(typx(i)))
	   if (temp .gt. converge) converge=temp
      end do

	ConTest1=converge

	Return

	End Function

C ConTest2: implements the gradient criterium
C           from Dennis and Schnabel (1983), p. 160
C
C usage: converge=ConTest2(nx,gradf,x,fx,typx,typf)
C
C Input:   nx, Integer(4), the number of elements in x0, x1, and typx
C       gradf, Real(8) vector with nx elements, the gradient of
C              f at x
C           x,  Real(8) vector with nx elements, the first value of x
C          fx, the value of f at x
C        typx, Real(8) vector with nx elements, the typical values of x(i)
C        typf, Real(8) the typical value of fx
C
C Output: Real(8), the minimal value of the convergence criterium

      Real(8) Function ConTest2(nx,gradf,x,fx,typx,typf)
                        
	Integer(4) nx
	Real(8) gradf(nx), x(nx), fx, typx(nx), typf

	Integer(4) i
	Real(8) converge, temp

      converge=0.0
	Do i=1,nx
	   temp=gradf(i)*dmax1(dabs(x(i)),dabs(typx(i)))
	   temp=dabs(temp/dmax1(dabs(fx),dabs(typf)))
         if (temp .gt. converge) converge=temp
      End Do

	ConTest2=converge

	Return

	End Function


C***********************************************************************
C
C GN_MinStep: Returns the minimal step size sl so that x1=x0+s*dx=0
C            (in terms of the parameter tolerance criterium)
C          
C Usage: sl=GN_MinStep(nx,x0,typx,dx)
C
C Input: nx, Integer(4), the number of elements in x0
C        x0, Real(8), nx times 1 vector
C     typx, Real(8), nx times 1 vector, the typical elements of x
C        dx, Real(8), nx times 1 vector, change of x
C
C Output: sl, Real(8)

	Real(8) Function GN_MinStep(nx,x0,typx,dx) 

      use GNP

	Integer(4) nx
	Real(8) x0(nx), typx(nx), dx(nx)

	Integer(4) i
	Real(8) converge, temp

      converge=0.0

	Do i=1,nx
	   temp=dabs(dx(i))/dmax1(dabs(x0(i)),dabs(typx(i)))
	   if (temp .gt. converge) converge=temp
      end do

	GN_MinStep=GN_ParTol/converge

	Return

	End Function

