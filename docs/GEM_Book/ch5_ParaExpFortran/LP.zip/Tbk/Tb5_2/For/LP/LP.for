C LP: Last revision: 21 November 2008, Alfred Maussner
C
C Purpose: Solve the limited participation model presented
C          in Chapter 5 of Heer and Mau�ner, 2nd edition.
C          The solution procedure is loglinear approximation
C          and parameterized expectations
C
C
C The parameters of the model are:
C
C a    =growth factor of labor augmenting technical progress
C alpha=elasticity of production with respect to capital,
C       must be in (0,1)
C beta =discount factor
C delta=rate of capital depreciation,
C       must be in (0,1)
C eta  =elasticity of marginal utility,
C       must be greater than zero
C nu   =determines elasticity of labor supply
C nstar=share of time devoted to work
C rhoZ  =autoregressive parameter of productivity shock
C simgaZ=standard deviation of innovations to productivity shock
C rhoMu =autoregressive parameter of money growth shock
C sigmamu=standard deviation of innovations to money growth shock
C mustar =growth factor of money supply
C
C The parameters that determine the programs behavior are
C
C nobs =length of time series
C nofs =number of time series
C nobs_pea=number of observations used to compute the PEA solution
C ta=number of initial observations that are discarded
C HPLambda=the smoothing parameter of the Hodrick-Prescott Filter
C          see Appendix A1.5 to Chapter 1 for relevant values
C Lambda=parameter used in the iterative computation of the fixed point
C
C Different from other versions of this program this version parameterizes lambda(t), lambda(t)*m(t+1)
C and lambda(t)*x(t+1)


C In the module Par we define the model's parameters common to many subprograms
      Module Par

	Integer(4) Npar, Npar1, Npar2, Npar3, nobs, ta
	Real(8) a, alpha, beta, delta, eta, nue, theta, rhoZ, sigmaZ, RhoMu, SigmaMu
      Real(8) kstar, nstar, cstar, xstar, lstar, qstar, mstar, pistar, mustar, ystar, gstar
	
	Logical shocks_exist

	End Module Par

C     Errors
	Module Errors
	Integer(4) FError
	Character(15) EMessage(7)

	DATA EMessage(1)/'Lambda<0'/
	DATA EMessage(2)/'x<0'/
	DATA EMessage(3)/'pi<0'/
	DATA EMessage(4)/'(c-t*n**nue)<0'/
	DATA EMessage(5)/'k<0'/
	DATA EMessage(6)/'m<0'/
	DATA EMessage(7)/'wn<0'/

	End Module Errors

C In the module Mat we define the various matrices used to compute the
C policy function and the policy matrices

      Module Mat

      Integer(4) nu, nx, nl, nz
	Real(8)  yk, yc, ck, xi(3), yi
	Real(8) Cu(4,4), Cxl(4,5), Cz(4,2), Dxl(5,5), Fxl(5,5), Du(5,4),
     +        Fu(5,4), Dz(5,2), Fz(5,2), Rho(2,2), Llx(2,3), Llz(2,2),
     +        Lxx(3,3), Lxz(3,2), Lux(4,3), Luz(4,2)

	End Module Mat
	
	Module Series
	
	Real(8), Allocatable :: xt(:,:), ut(:,:), lt(:,:)
	
	End Module Series
			    
      Program LP

      use DFLIB
	use DFPORT
	use IMSLF90 
	use Par
	use Mat
	use Errors
	use Series
	use GNP
	use Tools
	use MNR
	use PsiDef
      
      Integer(4) nobs1, nobs2, t, i, nofs, nobs_s

      Real(8), Allocatable :: uhut(:,:),xhut(:,:), zhut(:,:), lhut(:,:), eps(:,:)	
	Real(8), Allocatable :: Par11(:), Par12(:), Par21(:), Par22(:), Par31(:), Par32(:)	
	Real(8), Allocatable :: tPar1(:), tPar2(:), tPar3(:)
	Real(8), Allocatable :: Gamma1(:), Gamma2(:)
	Real(8)  typs, typx(21), crit(5), crit2(6)
	Real(8)  dpar(3), temp, SSE(3)
	Real(8)  mom1(1:6,1:3), mom2(1:6,1:3), hplambda, lambda
	Real(8)  Psi1, Psi2, Psi3
      
	CHARACTER(11) VarName(6)		
	
	DATA VarName(1)/'Output'/
	DATA VarName(2)/'Investment'/
	DATA VarName(3)/'Consumption'/
	DATA VarName(4)/'Hours'/
	DATA VarName(5)/'Real Wage'/
	DATA VarName(6)/'Inflation'/

	
	Logical initial_s, initial_p, direct, corrx
      
      TYPE (rccoord) curpos            

	External func1, func2, func3, dfunc1, dfunc2, dfunc3, Psi1, Psi2, Psi3, dPsi1, dPsi2, dPsi3	
	External SysPEA

      
C Configure and open output window
      ok=InitialSettings()
      Call MakeSmallWindow(10,"Program Progress",2)
	
C Read Parameters from File
      a      =GetD('a','Parameters.txt')
      alpha  =GetD('alpha','Parameters.txt')
      eta    =GetD('eta','Parameters.txt')
      delta  =GetD('delta','Parameters.txt')
      nstar  =GetD('nstar','Parameters.txt')
      beta   =GetD('beta','Parameters.txt')
	nue    =GetD('nue'  ,'Parameters.txt')
      RhoZ   =GetD('rhoz','Parameters.txt')
      SigmaZ =GetD('sigmaz', 'Parameters.txt')
	RhoMu  =GetD('rhomu',  'Parameters.txt')
	SigmaMu=GetD('sigmamu','Parameters.txt')
	MuStar =GetD('mustar' ,'Parameters.txt')
      
	initial_s=GetL('initial_s','Parameters.txt')
	initial_p=GetL('initial_p','Parameters.txt')
	direct   =GetL('direct',   'Parameters.txt')
	shocks_exist=GetL('shocks_exist','Parameters.txt')
	corrx=GetL('corrx','Parameters.txt')

	nobs  =GetI('nobs_pea','Parameters.txt')		
	nobs_s=GetI('nobs_s','Parameters.txt')
	nofs  =GetI('nofs','Parameters.txt')
	ta    =GetI('ta','Parameters.txt')

	hplambda=GetD('hplambda','Parameters.txt')
	lambda  =GetD('lambda','Parameters.txt')

	Call GetPsi()

	Asec=RTC()

C Compute stationary solution to get necessary elasticities
      Call GetWg()
                
C Set the matrices
      Call MakeMat()

C Compute policy functions
      nx=3
	nl=2
	nz=2
	nu=4

      Call SolveLA(nu,nx,nl,nz,Cu,Cxl,Cz,Dxl,Fxl,Du,Fu,Dz,Fz,Rho,
     +                   Lxx,Lxz,Llx,Llz,Lux,Luz)

      open(15,file='Summary.txt')
	open(11,file='LogFile.txt')
	write(15,"(A)") MyDate()
	write(11,"(A)") MyDate()

	write(15,"('Policy functions of the loglinear solution:')")
	write(15,"('Lxx: ')")
	Do t=1,nx
	  write(15,"(3F12.7)") Lxx(t,1:nx)
	End Do
	write(15,"('Lxz: ')")
	do t=1,nx
	  write(15,"(2F12.7)") Lxz(t,1:nz)
	End Do
	write(15,"('Lux: ')")
	Do t=1,nu
	  write(15,"(3F12.7)") Lux(t,1:nx)
	End Do
	write(15,"('Luz: ')")
	Do t=1,nu
	  write(15,"(2F12.7)") Luz(t,1:nz)
	End Do
	write(15,"('Llx: ')")
	Do t=1,nl
	   write(15,"(3F12.7)") Llx(t,1:nx)
	End Do
	write(15,"('Llz: ')") 
	Do t=1,nl
	   write(15,"(2F12.7)") Llz(t,1:nz)
	End Do

C Simulate the model
	Npar=Npar1+Npar2+Npar3

	nobs2=nobs+ta+1
	nobs1=nobs+ta
	Allocate(eps(1:2,1:nobs2),zhut(1:2,1:nobs2),xhut(1:3,1:nobs2),lhut(1:2,1:nobs1),uhut(1:4,1:nobs1))
	Allocate(xt(1:nobs2,1:5),ut(1:nobs1,1:4),lt(1:nobs1,1:2))	
	Allocate(Par11(1:Npar1),Par12(1:Npar1),Par21(1:Npar2),Par22(1:Npar2),Par31(1:Npar3),Par32(1:Npar3))
	Allocate(tPar1(1:Npar1),tPar2(1:Npar2),tPar3(1:NPar3))
	Allocate(Gamma1(1:Npar), Gamma2(1:Npar))

6	continue
C Draw Shocks
	if (initial_s) then
		open(16,file='eps.bin',form='unformatted')
		read(16) eps
		close(16)
	else
		Call DRNNOR(nobs2,eps(1,1:nobs2)) ! Draw shocks from a standard normal
		Call DRNNOR(nobs2,eps(2,1:nobs2))
		open(16,file='eps.bin',form='unformatted')
		write(16) eps
		close(16)
	endif

	eps(1,1:nobs2)=sigmaZ*eps(1,1:nobs2)
	eps(2,1:nobs2)=sigmaMu*eps(2,1:nobs2)

C Compute time series in deviation form
	xhut=0.0
	zhut=0.0
	uhut=0.0
	lhut=0.0

      zhut(1:2,1)=eps(1:2,1)
	
	Do t=1,nobs1
		zhut(1:2,t+1)=MatMul(Rho,zhut(1:2,t))+eps(1:2,t+1)
		xhut(1:3,t+1)=MatMul(Lxx,xhut(1:3,t))+MatMul(Lxz,zhut(1:2,t))
	    uhut(1:4,t)  =MatMul(Lux,xhut(1:3,t))+MatMul(Luz,zhut(1:2,t))
		lhut(1:2,t)  =MatMul(Llx,xhut(1:3,t))+MatMul(Llz,zhut(1:2,t))
	End Do

C Compute time series in stationary variables
	
	Do t=1,nobs2
		xt(t,1)=kstar*(1.+xhut(1,t))
		xt(t,2)=mstar*(1.+xhut(2,t))
		xt(t,3)=xstar*(1.+xhut(3,t))
		xt(t,4)=1.+zhut(1,t)
		xt(t,5)=mustar*(1.+zhut(2,t))
	End Do
	Do t=1,nobs1
		ut(t,1)=cstar *(1.+uhut(1,t))
		ut(t,2)=nstar *(1.+uhut(2,t))
		ut(t,3)=pistar*(1.+uhut(3,t))
		ut(t,4)=gstar *(1.+uhut(4,t))
		lt(t,1)=lstar *(1.+lhut(1,t))
		lt(t,2)=qstar *(1.+lhut(2,t))
	End Do

	open(11,file='LogFile.txt')
	open(15,file='Summary.txt')
	Write(15,"('Properties of time series from the loglinear solution:')")
	Write(15,"('Variable     Min          Mean           Max')")
	write(15,"(A4,3(F10.5,1X))") 'k  ', MinVal(xt(1:nobs2,1)), kstar, MaxVal(xt(1:nobs2,1))
	write(15,"(A4,3(F10.5,1X))") 'm  ', MinVal(xt(1:nobs2,2)), mstar,  MaxVal(xt(1:nobs2,2))
	write(15,"(A4,3(F10.5,1X))") 'x  ', MinVal(xt(1:nobs2,3)), xstar,  MaxVal(xt(1:nobs2,3))
	write(15,"(A4,3(F10.5,1X))") 'Z  ', MinVal(xt(1:nobs2,4)), 1.0,    MaxVal(xt(1:nobs2,4))
	write(15,"(A4,3(F10.5,1X))") 'mu ', MinVal(xt(1:nobs2,5)), mustar, MaxVal(xt(1:nobs2,5))
	write(15,"(A4,3(F10.5,1X))") 'c  ', MinVal(ut(1:nobs1,1)), cstar,  MaxVal(ut(1:nobs1,1))
	write(15,"(A4,3(F10.5,1X))") 'N  ', MinVal(ut(1:nobs1,2)), Nstar,  MaxVal(ut(1:nobs1,2))
	write(15,"(A4,3(F10.5,1X))") 'pi ', MinVal(ut(1:nobs1,3)), pistar, MaxVal(ut(1:nobs1,3))
	write(15,"(A4,3(F10.5,1X))") 'g  ', MinVal(ut(1:nobs1,4)), gstar,  MaxVal(ut(1:nobs1,4))
	write(15,"(A4,3(F10.5,1X))") 'l  ', MinVal(lt(1:nobs1,1)), lstar,  MaxVal(lt(1:nobs1,1))
	write(15,"(A4,3(F10.5,1X))") 'q  ', MinVal(lt(1:nobs1,2)), qstar,  MaxVal(lt(1:nobs1,2))
	write(15,"('Sum of squarred errors from the loglinear solution:')")
	Call GetSSE(SSE)
	Do i=1,3
		write(15,"('SSE(',I1,')= ',D10.5)")  i, SSE(i)
	End Do
	
C Compute second moments form this solution
	Call MomentsLA(nofs,nobs_s,hplambda,Mom1)
	Write(15,"('Second Moments from simulation of the loglinear model')")

	Do i=1,6
		write(15,"(A11,2(F7.2,'&'),F7.2,'\\')") VarName(i), Mom1(i,1:3)
	End Do

	if (initial_p) then
		open(16,file='Par1.bin',form='unformatted')
		read(16) Par11
		close(16)
		open(16,file='Par2.bin',form='unformatted')
		read(16) Par21
		close(16)
		open(16,file='Par3.bin',form='unformatted')
		read(16) Par31
		goto 1
	endif

C Get Correlation matrix
	if (corrx) then
		Call GetCorrMat()
		goto 15
	Endif

C Estimate Coefficients with GaussNewton
	typx=1.0
	typS=0.0001	
	GN_vc=.true.
	Par11=0.0
	Par11(1)=1.0
	Par11(2)=0.5
	Par11(3)=0.1
	Call GaussNewton(Npar1,nobs,Par11,typx(1:Npar1),typS,func1,dfunc1,Par12,tPar1,crit)	    
	if (crit(1).ne.0.0) goto 6 !draw new shocks and try it again
	Par21=0.0
	Par21(1)=1.0
	Par21(2)=0.5
	Par21(3)=0.1
	Call GaussNewton(Npar2,nobs,Par21,typx(1:Npar2),typS,func2,dfunc2,Par22,tPar2,crit)
	if (crit(1).ne.0.0) goto 6
	Par31=0.0
	Par31(1)=1.0
	Par31(2)=0.5
	Par31(3)=0.1
	Call GaussNewton(Npar3,nobs,Par31,typx(1:Npar3),typS,func3,dfunc3,Par32,tPar3,crit)
	if (crit(1).ne.0.0) goto 6

	if (direct) then
		if (initial_p) then
			Par12=Par11
			Par22=Par21
			Par32=Par31
		endif
	
		Gamma1(1:Npar1)=Par12(1:Npar1)
		Gamma1(1+Npar1:Npar1+Npar2)=Par22(1:Npar2)
		Gamma1(1+Npar1+Npar2:Npar)=Par32(1:Npar3)

		Call FixvMN1(Npar,Gamma1,SysPEA,Gamma2,crit2)
		write(15,"(A)") MNR_Message(IDINT(crit2(1)))
		write(15,"('Max|f(x)|  = ',D15.7)") crit2(2)
		write(15,"('Max|dx/x|  = ',D15.7)") crit2(3)
		write(15,"('Max Relgrad= ',D15.7)") crit2(4)
		write(15,"('0.5*(fx^2) = ',D15.7)") crit2(5)
		write(15,"('Iterations = ',I7)")    IDINT(crit2(6)) 
		if(crit2(1).eq.0.0) then
			Par12(1:Npar1)=Gamma2(1:Npar1)
			Par22(1:Npar2)=Gamma2(Npar1+1:Npar1+Npar2)
			Par32(1:Npar3)=Gamma2(Npar1+Npar2+1:Npar)
			temp=0.0
			goto 10
		else
			goto 14
		endif
	endif				
	 
	GN_vc=.false.
C Compute a time series using these estimates and iterate over the
C parameter vectors
5	FError=0
	
      xt(1,1)=kstar
	xt(1,2)=cstar
	xt(1,3)=xstar

	do t=1,nobs1
		 lt(t,1)=Psi1(Par12,xt(t,1:5))            !lambda(t)
	   xt(t+1,2)=Psi2(Par22,xt(t,1:5))/lt(t,1)    !m(t+1)
		if (xt(t+1,2) .lt. Epsilon(a)) then
			FError=6
			goto 7
		endif
		xt(t+1,3)=Psi3(Par32,xt(t,1:5))/lt(t,1) !x(t+1)
		if (xt(t+1,3) .lt. Epsilon(a)) then
			FError=2
			goto 7
		endif            	      
	       
		Call GetU(t) !solve for c,N,pi,q, and gamma, results are stored in ut(t,1:4) and lt(t,2)
		if (FError .ne. 0) goto 7
	    
		xt(t+1,1)=(1./a)* (xt(t,4)*(ut(t,2)**alpha)*(xt(t,1)**(1.-alpha))
     +                    +(1.-delta)*xt(t,1) - ut(t,1) )  !k(t+1)
		if (xt(t+1,1) .le. Epsilon(a)) then
			FError=5
			goto 7
		endif		
	
	end do

7     Call SetTextPosition(10,1,curpos)
	if (FError.ne.0) then
		Write(10,"(A)") EMessage(FError)
		goto 14
	Endif

C Reestimate Gamma
	Call GaussNewton(Npar1,nobs,Par12,typx(1:Npar1),typS,func1,dfunc1,Par11,tPar1,crit)
	if (crit(1).ne.0.) goto 7	
	Call GaussNewton(Npar2,nobs,Par22,typx(1:Npar2),typS,func2,dfunc2,Par21,tPar2,crit)
	if (crit(1).ne.0.) goto 7
	Call GaussNewton(Npar3,nobs,Par32,typx(1:Npar3),typS,func3,dfunc3,Par31,tPar3,crit)
	if (crit(1).ne.0) goto 7
	dpar=0.0
	do i=1,Npar1	    
		temp=dabs(par12(i)-par11(i))/dmax1(dabs(par12(i)),1.0)
	    if (temp.gt.dpar(1)) dpar(1)=temp
	End do
	do i=1,Npar2
		temp=dabs(par22(i)-par21(i))/dmax1(dabs(par22(i)),1.0)
	    if (temp.gt.dpar(2)) dpar(2)=temp
	End do
	do i=1,Npar3
		temp=dabs(par32(i)-par31(i))/dmax1(dabs(par32(i)),1.0)
	    if (temp.gt.dpar(3)) dpar(3)=temp
	End do
      temp=MaxVal(dpar)
	
	Call SetTextPosition(14,1,curpos)
	Write(10,"('Max|dx/x|= ',D10.5)") temp

10	if (temp.lt.0.001) then
		GN_vc=.true. ! reestimate to get t-ratios
		Call ClearScreen($GWINDOW)
		Call GaussNewton(Npar1,nobs,Par12,typx(1:Npar1),typS,func1,dfunc1,Par11,tPar1,crit)	
		Call GaussNewton(Npar2,nobs,Par22,typx(1:Npar2),typS,func2,dfunc2,Par21,tPar2,crit)	
		Call GaussNewton(Npar3,nobs,Par32,typx(1:Npar3),typS,func3,dfunc3,Par31,tPar3,crit)
	
		Write(15,"('Properties of time series from the PEA solution:')")
		Write(15,"('Variable     Min          Mean           Max')")
		write(15,"(A4,3(F10.5,1X))") 'k  ', MinVal(xt(1:nobs2,1)), kstar,  MaxVal(xt(1:nobs2,1))
		write(15,"(A4,3(F10.5,1X))") 'm  ', MinVal(xt(1:nobs2,2)), mstar,  MaxVal(xt(1:nobs2,2))
		write(15,"(A4,3(F10.5,1X))") 'x  ', MinVal(xt(1:nobs2,3)), xstar,  MaxVal(xt(1:nobs2,3))
		write(15,"(A4,3(F10.5,1X))") 'Z  ', MinVal(xt(1:nobs2,4)), 1.0,    MaxVal(xt(1:nobs2,4))
		write(15,"(A4,3(F10.5,1X))") 'mu ', MinVal(xt(1:nobs2,5)), mustar, MaxVal(xt(1:nobs2,5))
		write(15,"(A4,3(F10.5,1X))") 'c  ', MinVal(ut(1:nobs1,1)), cstar,  MaxVal(ut(1:nobs1,1))
		write(15,"(A4,3(F10.5,1X))") 'N  ', MinVal(ut(1:nobs1,2)), Nstar,  MaxVal(ut(1:nobs1,2))
		write(15,"(A4,3(F10.5,1X))") 'pi ', MinVal(ut(1:nobs1,3)), pistar, MaxVal(ut(1:nobs1,3))
		write(15,"(A4,3(F10.5,1X))") 'g  ', MinVal(ut(1:nobs1,4)), gstar,  MaxVal(ut(1:nobs1,4))
		write(15,"(A4,3(F10.5,1X))") 'l  ', MinVal(lt(1:nobs1,1)), lstar,  MaxVal(lt(1:nobs1,1))
		write(15,"(A4,3(F10.5,1X))") 'q  ', MinVal(lt(1:nobs1,2)), qstar,  MaxVal(lt(1:nobs1,2))
		write(15,"('Sum of squarred errors of this solution:')")
		Call GetSSE(SSE)
		Do i=1,3
			write(15,"('SSE(',I1,')= ',D10.5)")  i, SSE(i)
		End Do
1		Call MomentsPEA(Npar1,Npar2,NPar3,Par11,Par21,Par31,nofs,nobs_s,hplambda,Mom2) ! compute time series moments
		Write(15,"('Second Moments from simulation of the PEA model')")
		Do i=1,6
			write(15,"(A11,2(F7.2,'&'),F7.2,'\\')") VarName(i), Mom2(i,1:3)
		End Do
		write(15,"('Coefficients of Psi1:')")
		i=1
		Call PrintPsi(i,Npar1,Par11,tPar1)
		write(15,"('Coefficients of Psi2:')")
		i=2
		Call PrintPsi(i,Npar2,Par21,tPar2)
		write(15,"('Coefficients of Psi3:')")
		i=3
		Call PrintPsi(i,Npar3,Par31,tPar3)
		write(15,"('t-ratios in parenthesis')")

		open(16,file='Par1.bin',form='unformatted')
		write(16) Par12
		close(16)
		open(16,file='Par2.bin',form='unformatted')
		write(16) Par22
		close(16)
		open(16,file='Par3.bin',form='unformatted')
		write(16) Par32
		close(16)	
		goto 14

	Endif

      Par12=lambda*Par11+(1.-lambda)*Par12
	Par22=lambda*Par21+(1.-lambda)*Par22
	Par32=lambda*Par31+(1.-lambda)*Par32

	goto 5

8	continue
	if (FError.ne.0) goto 6

14	Call Test(Par11,Par21,Par31)
	i=20
	Call Impulse(Par11,Par21,Par31,i)

15	Write(15,"('Parameters of the model:')")
	Write(15,"('a=       ',F8.4)") a
	Write(15,"('alpha=   ',F8.4)") alpha
	Write(15,"('delta=   ',F8.4)") delta
	Write(15,"('RhoZ=    ',F8.4)") RhoZ
	Write(15,"('SigmaZ=  ',F8.4)") SigmaZ
	Write(15,"('beta=    ',F8.4)") beta
	Write(15,"('eta=     ',F8.4)") eta
	Write(15,"('nstar=   ',F8.4)") nstar
	Write(15,"('nu=      ',F8.4)") nue
	Write(15,"('RhoMu=   ',F8.4)") RhoMu
	Write(15,"('SigmaMu= ',F8.4)") SigmaMu
	Write(15,"(' ')")
	Write(15,"('Parameters of the algorithm:')")
	Write(15,"('Number of Simulations= ',I7)") nofs
	Write(15,"('Length of time series= ',I7)") nobs_s
	Write(15,"('PEA nobs             = ',I7)") nobs
	Write(15,"('PEA ta               = ',I7)") ta	
	if (direct) then
		Write(15,"('method = direct')")
	else
		Write(15,"('method = iterative')")
	Endif

	Call ElapsedTime(RTC()-Asec,RunTime)
	write(15,"(A)") RunTime
	close(15)
	close(11)

	END


C -------------------------------------------- Subprograms ---------------------------------------------- 

      Subroutine GetWg()
                      
	use Par	
	use Mat	

	yk=((a**eta)-beta*(1.-delta))/(beta*(1.-alpha))
	yi=yk/(a+delta-1)
	kstar=nstar*(yk**(-1./alpha))
	ystar=yk*kstar
      ck=yk-(a+delta-1.)
	cstar=ck*kstar
      yc=yk/ck      
      qstar=mustar*(a**(eta-1.))*(1./beta)
	theta=(1./qstar)*(alpha/nue)*(ystar/nstar)*(nstar**(1.-nue))
	pistar=mustar/a
	mstar=cstar
	xstar=mustar*(cstar-((alpha*ystar)/qstar))
	lstar=((cstar-theta*(nstar**nue))**(-eta))*(1./qstar)
	gstar=lstar*(qstar-1.)

      xi=0
      xi(1)=eta/(1.-(alpha/nue)*yc*(1./qstar))
      xi(2)=(alpha*eta)/(qstar*(1./yc)-(alpha/nue))
      xi(3)=1.-(beta*(a**(-eta)))*(1.-delta)

      Return

	End Subroutine


      Subroutine MakeMat()

      use Par
	use Mat      
   
      Cu=0
      Cu(1,1)=-xi(1)
	Cu(1,2)=xi(2)
	Cu(1,4)=(1.-qstar)/qstar
      Cu(2,2)=alpha-nue             
      Cu(3,1)=1.
	Cu(3,3)=1.
      Cu(4,2)=alpha
	Cu(4,3)=1.

      Cxl=0
      Cxl(1,4)=1/qstar
      Cxl(2,1)=alpha-1
	Cxl(2,5)=1
      Cxl(3,2)=1
      Cxl(4,1)=alpha-1
	Cxl(4,2)=(qstar/alpha)*(1/yc)
	Cxl(4,3)=1-Cxl(4,2)
	Cxl(4,5)=1

      Cz=0
      Cz(2,1)=-1
      Cz(3,2)=1
      Cz(4,1)=-1
	Cz(4,2)=(qstar/alpha)*(1/yc)

      Dxl=0
      Dxl(1,1)=a
      Dxl(2,1)=alpha*xi(3)
	Dxl(2,4)=-1
      Dxl(3,4)=1/qstar
      Dxl(4,4)=1
	Dxl(4,5)=1
      Dxl(5,2)=1
   
      Fxl=0
      Fxl(1,1)=-(a**eta)/beta
      Fxl(2,4)=1
      Fxl(3,4)=-1
      Fxl(4,4)=-1
      Fxl(5,2)=-1
   
      Du=0
      Du(2,2)=alpha*xi(3)
      Du(3,3)=1
	Du(3,4)=(1-qstar)/qstar
      Du(4,3)=1
  
      Fu=0
      Fu(1,1)=-ck
	Fu(1,2)=alpha*yk
      Fu(5,3)=-1
   
      Dz=0
      Dz(2,1)=xi(3)

      Fz=0
      Fz(1,1)=yk
      Fz(5,2)=1
   
      Rho=0
      Rho(1,1)=RhoZ
      Rho(2,2)=RhoMu
   
      Return

	End Subroutine


C Functions used for GaussNewton


C Func1: error from first expectational equation

	Subroutine Func1(m,n,Gamma,fx)	

	use Par
	use Series
	
	Integer(4) m,n
	Real(8) Gamma(m), fx(n)

      Integer(4) t, nobs1
	Real(8) Psi1
      
	nobs1=nobs+ta-1

	Do t=ta,nobs1
	   fx(t-ta+1)=beta*(a**(-eta))*lt(t+1,1)*(1.-delta+(1.-alpha)*xt(t+1,4)*(ut(t+1,2)**alpha)*(xt(t+1,1)**(-alpha)))
     + 	     -Psi1(Gamma,xt(t,1:5))
	End Do

	Return

	End Subroutine



C Func2: error from second expectational equation, for iterations

	Subroutine Func2(m,n,Gamma,fx)	

	use Par
	use Series
	
	Integer(4) m,n
	Real(8) Gamma(m), fx(n)

      Integer(4) t, nobs1
	Real(8) Psi2
      
	nobs1=nobs+ta-1

	Do t=ta,nobs1
	   fx(t-ta+1)=xt(t+1,2)*beta*(a**(-eta))*lt(t+1,1)*lt(t+1,2)*(1./ut(t+1,3))
     +	     -Psi2(Gamma,xt(t,1:5))
	End Do

	Return

	End Subroutine


C Func3: error from third expectational equation, for iterations

	Subroutine Func3(m,n,Gamma,fx)	

	use Par
	use Series
	
	Integer(4) m,n
	Real(8) Gamma(m), fx(n)

      Integer(4) t, nobs1
	Real(8) Psi3
      
	nobs1=nobs+ta-1

	Do t=ta,nobs1
	   fx(t-ta+1)=beta*(a**(-eta))*xt(t+1,3)*(lt(t+1,1)+ut(t+1,4))*(1./ut(t+1,3))
     +	     -Psi3(Gamma,xt(t,1:5))
	End Do

	Return

	End Subroutine

C dFunc1: Jacobian of func1

      Subroutine dFunc1(m,n,Gamma,xx)

	use Par
      use Series

	Integer(4) m,n
	Real(8) Gamma(m), xx(n,m)

	Integer(4) t, nobs1
	Real(8) dg(m)

	nobs1=nobs+ta-1

	Do t=ta,nobs1
	   Call dPsi1(Gamma,xt(t,1:5),dg)
	   xx(t-ta+1,1:m)=dg(1:m)
	End Do

	Return

      End Subroutine

C dFunc2: Jacobian of func2

      Subroutine dFunc2(m,n,Gamma,xx)

	use Par
      use Series

	Integer(4) m,n
	Real(8) Gamma(m), xx(n,m)

	Integer(4) t, nobs1
	Real(8) dg(m)

	nobs1=nobs+ta-1

	Do t=ta,nobs1
	   Call dPsi2(Gamma,xt(t,1:5),dg)
	   xx(t-ta+1,1:m)=dg(1:m)
	End Do

	Return

      End Subroutine

C dFunc3: Jacobian of Func3

      Subroutine dFunc3(m,n,Gamma,xx)

	use Par
      use Series

	Integer(4) m,n
	Real(8) Gamma(m), xx(n,m)

	Integer(4) t, nobs1
	Real(8) dg(m)

	nobs1=nobs+ta-1

	Do t=ta,nobs1
	   Call dPsi3(Gamma,xt(t,1:5),dg)
	   xx(t-ta+1,1:m)=dg(1:m)
	End Do

	Return

      End Subroutine

C Getu: Solves for u:=(c,N,pi,gamma) given x:=(k,m,x,z,mu) and lq:=(lambda,q)

      Subroutine GetU(t)

      use Par
	use Series
	use Errors

	Integer(4) t
	
	Real(8) n, wn, c, p, q      

C First: compute pi
	p=xt(t,5)*xt(t,2)/(a*xt(t+1,2))

	if (p .lt. Epsilon(a)) then
	   FError=3
	   return
	endif

	ut(t,3)=p

C Second: compute wn
	wn=(xt(t,5)*xt(t,2)-xt(t,3))/(a*p)
	if(wn.lt.Epsilon(a)) then
		FError=7
		return
	Endif

C Thrid: Compute n
	n=((1./(theta*nue))*wn)**(1./nue)
	ut(t,2)=n

C Fourth: Compute q
	q=(alpha/(nue*theta))*xt(t,4)*(n**(alpha-nue))*(xt(t,1)**(1.-alpha))
	lt(t,2)=q
	
C Fifth: Compute c for gamma=0      	
      c=(lt(t,1)**(-1./eta))+theta*(n**nue)
	if (c .lt. xt(t+1,2)) then
	   ut(t,1)=c	   
	   ut(t,4)=0.0
	else	   
		c=xt(t+1,2)
		ut(t,1)=c
		if ((c-theta*(n**nue)).lt.Epsilon(a))then
			FError=4
			return
		Endif	   
		ut(t,4)=((c-theta*(n**nue))**(-eta))-lt(t,1)
	endif

	return

	End Subroutine

C Compute sum of squarred errors

	Subroutine GetSSE(SSE)

	use Par
	use Series

	Real(8) SSE(3), temp

	Integer(4) t, nobs1
	

	SSE=0.0
	nobs1=nobs-1

	Do t=1,nobs1
		temp=beta*(a**(-eta))*lt(t+1,1)*(1.-delta+(1.-alpha)*xt(t+1,4)*(ut(t+1,2)**alpha)*(xt(t+1,1)**(-alpha))) - lt(t,1)
	    SSE(1)=SSE(1)+(temp**2)
	    temp=lt(t,1)-beta*(a**(-eta))*lt(t+1,1)*lt(t+1,2)*(1./ut(t+1,3))
		SSE(2)=SSE(2)+(temp**2)
		temp=lt(t,1)-beta*(a**(-eta))*(lt(t+1,1)+ut(t+1,4))*(1./ut(t+1,3))
		SSE(3)=SSE(3)+(temp**2)

	End Do

	SSE=SSE/dble(nobs1)

	Return

	End Subroutine


C MomentsLA: compute second moments from simulations of the loglinear model

	Subroutine MomentsLA(nofs,nobs3,hplambda,Moments)

	use Par
	use Mat
	use IMSLF90 

	Integer(4) nofs, nobs3
	Real(8) hplambda, Moments(1:6,1:3)

	Integer(4) s, t, j
	Real(8) uhut(1:4,1:nobs3),xhut(1:3,1:nobs3+1), zhut(1:2,1:nobs3+1), lhut(1:2,1:nobs3)
	Real(8) yhut(1:nobs3), ihut(1:nobs3), whut(1:nobs3)
	Real(8) eps1(1:nobs3+1,1:nofs), eps2(1:nobs3+1,1:nofs)
	Real(8) temp(1:2), xh1(1:nobs3,6), xh2(1:nobs3-1,2), cov(6,6)	

	if (shocks_exist) then
		open(16,file='epsZ.bin',form='unformatted')
		read(16) eps1
		close(16)
		open(16,file='epsMu.bin',form='unformatted')
		read(16) eps2
		close(16)
	else
		Do s=1,nofs ! Draw Matrix of shocks and save to file for use in MomentsPEA
			Call DRNNOR(nobs3+1,eps1(1:nobs3+1,s))
			Call DRNNOR(nobs3+1,eps2(1:nobs3+1,s))
		End Do

		open (16,file='epsZ.bin',form='unformatted')
		write(16) eps1
		close(16)
		open(16,file='epsMu.bin',form='unformatted')
		write(16) eps2
		close(16)
	Endif

C Start simulations
	moments=0.0
	eps1=SigmaZ*eps1
	eps2=SigmaMu*eps2

	Do s=1,nofs
	
		xhut=0.0
		uhut=0.0	
		zhut=0.0

		zhut(1,1)=eps1(1,s)
		zhut(2,1)=eps2(1,s)

		Do t=1,nobs3			    
			temp(1)=eps1(t+1,s)
			temp(2)=eps2(t+1,s)
			zhut(1:nz,t+1)=MatMul(Rho,zhut(1:nz,t))+temp
			xhut(1:nx,t+1)=MatMul(Lxx,xhut(1:nx,t))+MatMul(Lxz,zhut(1:nz,t))
			uhut(1:nu,t)  =MatMul(Lux,xhut(1:nx,t))+MatMul(Luz,zhut(1:nz,t))
			lhut(1:nl,t)  =MatMul(Llx,xhut(1:nx,t))+MatMul(Llz,zhut(1:nz,t))
			yhut(t)       =alpha*uhut(2,t)+(1.-alpha)*xhut(1,t)+zhut(1,t)
			ihut(t)       =yi*yhut(t)+(1.-yi)*uhut(1,t)
			whut(t)       =(nue-1.)*uhut(2,t)
		End Do
		CALL HPFilter(Nobs3,yhut,hplambda,xh1(1:nobs3,1)) ! Filtering
		CALL HPFilter(Nobs3,ihut,hplambda,xh1(1:nobs3,2))
		CALL HPFILTER(Nobs3,uhut(1,1:nobs3),hplambda,xh1(1:nobs3,3))
		CALL HPFilter(Nobs3,uhut(2,1:nobs3),hplambda,xh1(1:nobs3,4))
		CALL HPFilter(Nobs3,whut,hplambda,xh1(1:nobs3,5))
		CALL HPFilter(Nobs3,uhut(3,1:nobs3),hplambda,xh1(1:nobs3,6))
		CALL Corrx(nobs3,6,xh1,cov)
		moments(1:6,1)=moments(1:6,1)+100*Diagonals(cov)
		moments(1,2)  =moments(1,2)  +1.
		moments(2:6,2)=moments(2:6,2)+cov(1,2:6)
		Do j=1,6
			xh2(1:nobs3-1,1)=xh1(1:nobs3-1,j)
			xh2(1:nobs3-1,2)=xh1(2:nobs3,j)			
			CALL Corrx(nobs3-1,2,xh2,cov(1:2,1:2))
			moments(j,3)=moments(j,3)+cov(1,2)
		End Do
	
	End Do

	moments=moments/dble(nofs)

	Return

	End Subroutine


C MomentsPEA: compute second moments from the PEA solution

	Subroutine MomentsPEA(n1,n2,n3,Par1,Par2,Par3,nofs,nobs3,hplambda,Moments)

	use Par
	use Series	
	use Errors
	use IMSLF90 

	Integer(4) n1, n2, n3, nofs, nobs3
	Real(8) Par1(n1), Par2(n2), Par3(n3), hplambda, moments(1:6,1:3)
                                  
	Integer(4) s, t, j
	Real(8) yt(1:nobs3), it(1:nobs3), wt(1:nobs3)
	Real(8) eps1(1:nobs3+1,1:nofs), eps2(1:nobs3+1,1:nofs)
	Real(8) xh1(1:nobs3,6), xh2(1:nobs3-1,2), cov(6,6)	
	Real(8) Psi1, Psi2, Psi3

	External Psi1, Psi2, Psi3

C Read matrix of shocks form file	
	open (16,file='epsZ.bin',form='unformatted')
	read(16) eps1
	close(16)
	open(16,file='epsMu.bin',form='unformatted')
	read(16) eps2
	close(16)

C Start simulations
	moments=0.0
	eps1=SigmaZ*eps1
	eps2=SigmaMu*eps2

	Do s=1,nofs
	
		xt=0.0
		ut=0.0	
		lt=0.0
		yt=0.0
		it=0.0
		wt=0.0

		xt(1,1)=kstar
		xt(1,2)=mstar
		xt(1,3)=xstar
		xt(1,4)=dexp(eps1(1,1))
		xt(1,5)=Mustar*dexp(eps2(1,1))      	 			

		Do t=1,nobs3			    
			xt(t+1,4)=(xt(t,4)**RhoZ)*dexp(eps1(t+1,s))   ! Z(t+1)
			xt(t+1,5)=(MuStar**(1.-RhoMu))*(xt(t,5)**RhoMu)*dexp(eps2(t+1,s)) ! Mu(t+1)
			
		   lt(t,1) =Psi1(Par1,xt(t,1:5))            !lambda(t)
		  xt(t+1,2)=Psi2(Par2,xt(t,1:5))/lt(t,1)    !m(t+1)
			if (xt(t+1,2) .lt. Epsilon(a)) then
				FError=6
				return
			endif
		  	xt(t+1,3)=Psi3(Par3,xt(t,1:5))/lt(t,1) !x(t+1)
			if (xt(t+1,3) .lt. Epsilon(a)) then
				FError=2
				return
			endif            	      
	 
			Call GetU(t) !solve for c, N,pi, q, and gamma, results are stored in ut(t,1:4) and lt(t,2)
			if (FError .ne. 0) Return			
			xt(t+1,1)=(1./a)* (xt(t,4)*(ut(t,2)**alpha)*(xt(t,1)**(1.-alpha))
     +                    +(1.-delta)*xt(t,1) - ut(t,1) )  !k(t+1)
			if (xt(t+1,1) .le. Epsilon(a)) then
				FError=5
				return
			Endif
			yt(t)=xt(t,4)*(ut(t,2)**alpha)*(xt(t,1)**(1.-alpha))
			it(t)=yt(t)-ut(t,1)
			wt(t)=(nue*theta)*(ut(t,2)**(nue-1.))
		End Do
		CALL HPFilter(Nobs3,dlog(yt),hplambda,xh1(1:nobs3,1)) ! Filtering
		CALL HPFilter(Nobs3,dlog(it),hplambda,xh1(1:nobs3,2))
		CALL HPFILTER(Nobs3,dlog(ut(1:nobs3,1)),hplambda,xh1(1:nobs3,3))
		CALL HPFilter(Nobs3,dlog(ut(1:nobs3,2)),hplambda,xh1(1:nobs3,4))
		CALL HPFilter(Nobs3,dlog(wt),hplambda,xh1(1:nobs3,5))
		CALL HPFilter(Nobs3,dlog(ut(1:nobs3,3)),hplambda,xh1(1:nobs3,6))
		CALL Corrx(nobs3,6,xh1,cov)
		moments(1:6,1)=moments(1:6,1)+100*Diagonals(cov)
		moments(1,2)  =moments(1,2)  +1.
		moments(2:6,2)=moments(2:6,2)+cov(1,2:6)
		Do j=1,6
			xh2(1:nobs3-1,1)=xh1(1:nobs3-1,j)
			xh2(1:nobs3-1,2)=xh1(2:nobs3,j)			
			CALL Corrx(nobs3-1,2,xh2,cov(1:2,1:2))
			moments(j,3)=moments(j,3)+cov(1,2)
		End Do
	
	End Do

	moments=moments/dble(nofs)

	Return

	End Subroutine
		
	Subroutine SysPea(n,m,gamma,fx)

	use Par
	use Series
	use Errors

	Integer(4) n, m
	Real(8) gamma(1:n), fx(m)

	Integer(4) t, nobs1, nobs2, i
	Real(8) Par1(1:Npar1), Par2(1:Npar2), Par3(1:Npar3), temp(1:3)
	Real(8) g1(1:Npar1), g2(1:Npar2), g3(1:Npar3)
	Real(8) Psi1, Psi2, Psi3

	External Psi1, Psi2, Psi3, dPsi1, dPsi2, dPsi3

	Par1=gamma(1:Npar1)
	Par2=gamma(Npar1+1:Npar1+Npar2)
	Par3=gamma(Npar1+Npar2+1:Npar1+Npar2+Npar3)

	xt(1,1)=kstar
	xt(1,2)=cstar
	xt(1,3)=xstar

	nobs1=nobs+ta
	nobs2=nobs1-1

	do t=1,nobs1
		 lt(t,1)=Psi1(Par1,xt(t,1:5))            !lambda(t)
	   xt(t+1,2)=Psi2(Par2,xt(t,1:5))/lt(t,1)    !m(t+1)
		if (xt(t+1,2) .lt. Epsilon(a)) then
			FError=6
			return
		endif
		xt(t+1,3)=Psi3(Par3,xt(t,1:5))/lt(t,1) !x(t+1)
		if (xt(t+1,3) .lt. Epsilon(a)) then
			FError=2
			return
		endif            	      
	       
		Call GetU(t) !solve for c,N,pi,q, and gamma, results are stored in ut(t,1:4) and lt(t,2)
		if (FError .ne. 0) return
	    
		xt(t+1,1)=(1./a)* (xt(t,4)*(ut(t,2)**alpha)*(xt(t,1)**(1.-alpha))
     +                    +(1.-delta)*xt(t,1) - ut(t,1) )  !k(t+1)
		if (xt(t+1,1) .le. Epsilon(a)) then
			FError=5
			return
		endif		
	
	end do

	fx=0.0

	Do t=ta,nobs2
		
		temp(1)=beta*(a**(-eta))*lt(t+1,1)*(1.-delta+(1.-alpha)*xt(t+1,4)*(ut(t+1,2)**alpha)*(xt(t+1,1)**(-alpha)))
     + 	     -Psi1(Par1,xt(t,1:5))
		temp(2)=xt(t+1,2)*beta*(a**(-eta))*lt(t+1,1)*lt(t+1,2)*(1./ut(t+1,3))
     +	     -Psi2(Par2,xt(t,1:5))
		temp(3)=beta*(a**(-eta))*xt(t+1,3)*(lt(t+1,1)+ut(t+1,4))*(1./ut(t+1,3))
     +	     -Psi3(Par3,xt(t,1:5))
		Call dPsi1(Par1,xt(t,1:5),g1)
		Call dPsi2(Par2,xt(t,1:5),g2)
		Call dPsi3(Par3,xt(t,1:5),g3)
		do i=1,Npar1
			fx(i)      =fx(i)+temp(1)*g1(i)
		end do
		do i=1,Npar2
			fx(Npar1+i)=fx(Npar1+i)+temp(2)*g2(i)
		end do
		do i=1,Npar3
			fx(Npar1+Npar2+i)=fx(Npar1+Npar2+i)+temp(3)*g3(i)
		end do

	end do

	Return

	End Subroutine


C Test: Computes the steady state values of the model from the parameterized equation,
C       computes the percentage deviation of these solutions to the exact ones, and
C       write the result to the file summary.txt

      Subroutine Test(Par1,Par2,Par3)

	use Par
	use series

	Real(8) Par1(1:Npar1), Par2(1:Npar2), Par3(1:Npar3)

      Integer(4) t
      Real(8) Psi1, Psi2, Psi3, dx(8)
      

	External Psi1, Psi2, Psi3

      
	t=1	
	xt(1,1)=kstar
      xt(1,2)=mstar 
      xt(1,3)=xstar
	xt(1,4)=1.0
	xt(1,5)=mustar
              
      lt(1,1)=Psi1(Par1,xt(1,1:5))         !lambda	       
	xt(2,2)=Psi2(Par2,xt(1,1:5))/lt(1,1) !m(t+1)
	xt(2,3)=Psi3(Par3,xt(1,1:5))/lt(1,1) !x(t+1)	   
	Call GetU(t) !solve for c, N, pi, q, and gamma	   		   
	dx(1)=(ut(1,1)-cstar)/cstar
	dx(2)=(ut(1,2)-nstar)/nstar
	dx(3)=(ut(1,3)-pistar)/pistar
	dx(4)=(lt(1,1)-lstar)/lstar
	dx(5)=(lt(1,2)-qstar)/qstar
	dx(6)=(ut(1,4)-gstar)/gstar	       
	dx(7)=(xt(2,3)-xstar)/xstar
	dx(8)=(xt(2,2)-mstar)/mstar

	write(15,"('Accuracy of Solution:')")
	write(15,"('(dc/c)= ',F12.6)") dx(1)
	write(15,"('(dN/N)= ',F12.6)") dx(2) 
	write(15,"('(dp/p)= ',F12.6)") dx(3)
	write(15,"('(dl/l)= ',F12.6)") dx(4)
	write(15,"('(dq/q)= ',F12.6)") dx(5)
	write(15,"('(dg/g)= ',F12.6)") dx(6)
	write(15,"('(dx/x)= ',F12.6)") dx(7)
	write(15,"('(dm/m)= ',F12.6)") dx(8)

      Return

	End Subroutine


C Impulse
	Subroutine Impulse(Par1,Par2,Par3,ns)

	use Par
	use Series	
	use Errors

	Integer(4) ns
	Real(8) Par1(1:Npar1), Par2(1:Npar2), Par3(1:NPar3)
                                  
	Integer(4)  t
	Real(8) yt(1:ns), it(1:ns), wt(1:ns), ct(1:ns), pt(1:ns), nt(1:ns), qt(1:ns)
	Real(8) wstar, istar
	Real(8) Psi1, Psi2, Psi3

	External Psi1, Psi2, Psi3

C Start simulations
	wstar=alpha*ystar/nstar
	istar=ystar-cstar

	xt(1:2,1)=kstar
	xt(1:2,2)=mstar
	xt(1:2,3)=xstar
	xt(1:ns+1,4)=1.0
	xt(1:2,5)=MuStar
	xt(3,5)=MuStar*dexp(SigmaMu)
	ut(1:2,1)=cstar
	ut(1:2,2)=nstar
	ut(1:2,3)=pistar
	lt(1:2,2)=qstar

	yt(1:2)=ystar
	it(1:2)=istar
	wt(1:2)=wstar

	Do t=3,ns
			
			xt(t+1,4)=(xt(t,4)**RhoZ)   ! Z(t+1)
			xt(t+1,5)=(MuStar**(1.-RhoMu))*(xt(t,5)**RhoMu) ! Mu(t+1)
			
		   lt(t,1) =Psi1(Par1,xt(t,1:5))            !lambda(t)
		  xt(t+1,2)=Psi2(Par2,xt(t,1:5))/lt(t,1)    !m(t+1)
			if (xt(t+1,2) .lt. Epsilon(a)) then
				FError=6
				return
			endif
		  	xt(t+1,3)=Psi3(Par3,xt(t,1:5))/lt(t,1) !x(t+1)
			if (xt(t+1,3) .lt. Epsilon(a)) then
				FError=2
				return
			endif            	      
	 
			Call GetU(t) !solve for c, N,pi, q, and gamma, results are stored in ut(t,1:4) and lt(t,2)
			if (FError .ne. 0) Return			
			xt(t+1,1)=(1./a)* (xt(t,4)*(ut(t,2)**alpha)*(xt(t,1)**(1.-alpha))
     +                    +(1.-delta)*xt(t,1) - ut(t,1) )  !k(t+1)
			if (xt(t+1,1) .le. Epsilon(a)) then
				FError=5
				return
			Endif
			yt(t)=xt(t,4)*(ut(t,2)**alpha)*(xt(t,1)**(1.-alpha))
			it(t)=yt(t)-ut(t,1)
			wt(t)=(nue*theta)*(ut(t,2)**(nue-1.))
	End Do

	open(16,file='Impulse.txt')
	
	
	Do t=1,ns
		yt(t)=100*(yt(t)-ystar)/ystar
		it(t)=100*(it(t)-istar)/ystar
		ct(t)=100*(ut(t,1)-cstar)/cstar
		nt(t)=100*(ut(t,2)-nstar)/nstar
		wt(t)=100*(wt(t)-wstar)/wstar
		pt(t)=100*(ut(t,3)-pistar)/pistar
		qt(t)=100*(lt(t,2)-qstar)/qstar
		write(16,"(7(F10.4))") yt(t), it(t), ct(t), nt(t), wt(t), pt(t), qt(t)
	End Do

	close(16)

	Return

	End Subroutine
	

	Subroutine GetCorrMat()

	use Par
	use PsiDef
	use Series

	Integer(4) i, m
	Real(8) xmat(1:nobs,1:20), cr(20,20)
	
	if (sigmaMu.gt.0.0)	then
		Do i=ta,nobs+ta-1		
			xmat(i-ta+1, 1)=xt(i,1)
			xmat(i-ta+1, 2)=xt(i,2)
			xmat(i-ta+1, 3)=xt(i,3)
			xmat(i-ta+1, 4)=xt(i,4)
			xmat(i-ta+1, 5)=xt(i,5)
			xmat(i-ta+1, 6)=xt(i,1)*xt(i,1)
			xmat(i-ta+1, 7)=xt(i,2)*xt(i,2)
			xmat(i-ta+1, 8)=xt(i,3)*xt(i,3)
			xmat(i-ta+1, 9)=xt(i,4)*xt(i,4)
			xmat(i-ta+1,10)=xt(i,5)*xt(i,5)
			xmat(i-ta+1,11)=xt(i,1)*xt(i,2)
			xmat(i-ta+1,12)=xt(i,1)*xt(i,3)
			xmat(i-ta+1,13)=xt(i,1)*xt(i,4)
			xmat(i-ta+1,14)=xt(i,1)*xt(i,5)
			xmat(i-ta+1,15)=xt(i,2)*xt(i,3)
			xmat(i-ta+1,16)=xt(i,2)*xt(i,4)
			xmat(i-ta+1,17)=xt(i,2)*xt(i,5)
			xmat(i-ta+1,18)=xt(i,3)*xt(i,4)
			xmat(i-ta+1,19)=xt(i,3)*xt(i,5)
			xmat(i-ta+1,20)=xt(i,4)*xt(i,5)		
		End Do
		m=20
		Call Corrx(nobs,m,xmat,cr)
	else
		Do i=ta,nobs+ta-1		
			xmat(i-ta+1, 1)=xt(i,1)
			xmat(i-ta+1, 2)=xt(i,2)
			xmat(i-ta+1, 3)=xt(i,3)
			xmat(i-ta+1, 4)=xt(i,4)		
			xmat(i-ta+1, 5)=xt(i,1)*xt(i,1)
			xmat(i-ta+1, 6)=xt(i,2)*xt(i,2)
			xmat(i-ta+1, 7)=xt(i,3)*xt(i,3)
			xmat(i-ta+1, 8)=xt(i,4)*xt(i,4)			
			xmat(i-ta+1, 9)=xt(i,1)*xt(i,2)
			xmat(i-ta+1,10)=xt(i,1)*xt(i,3)
			xmat(i-ta+1,11)=xt(i,1)*xt(i,4)			
			xmat(i-ta+1,12)=xt(i,2)*xt(i,3)
			xmat(i-ta+1,13)=xt(i,2)*xt(i,4)			
			xmat(i-ta+1,14)=xt(i,3)*xt(i,4)						
		End Do
		m=14
		Call Corrx(nobs,m,xmat,cr(1:m,1:m))
	Endif
	
	cr=Transpose(cr)
	write(15,"('Correlations matrix of regressors')")
	write(15,"(' ')")
	
	if (SigmaMu.gt.0.0) then
			
		write(15,"('      ',20(A4,4X))") Name(2:21)
		Do i=1,20
			write(15,"(A4,1X,20(F6.3,2X))") Name(i+1), cr(i,1:i)
		End Do

	else

		write(15,"('      ',14(A4,4X))") Name2(1:14)
		Do i=1,14
			write(15,"(A4,1X,14(F6.3,2X))") Name2(i), cr(i,1:i)
		End Do
	Endif

	Return

	End Subroutine

