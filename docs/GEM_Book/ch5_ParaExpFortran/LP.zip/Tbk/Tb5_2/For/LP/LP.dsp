# Microsoft Developer Studio Project File - Name="LP" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) QuickWin Application" 0x0107

CFG=LP - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "LP.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "LP.mak" CFG="LP - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "LP - Win32 Release" (based on "Win32 (x86) QuickWin Application")
!MESSAGE "LP - Win32 Debug" (based on "Win32 (x86) QuickWin Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
F90=df.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "LP - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE F90 /compile_only /libs:qwin /nologo /warn:nofileopt
# ADD F90 /compile_only /libs:qwin /nologo /warn:nofileopt
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "NDEBUG"
# ADD RSC /l 0x407 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib /nologo /entry:"WinMainCRTStartup" /subsystem:windows /machine:I386 /nodefaultlib:"dfconsol.lib"
# ADD LINK32 kernel32.lib /nologo /entry:"WinMainCRTStartup" /subsystem:windows /machine:I386 /nodefaultlib:"dfconsol.lib"

!ELSEIF  "$(CFG)" == "LP - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE F90 /check:bounds /compile_only /debug:full /extend_source:132 /libs:qwin /nologo /traceback /warn:argument_checking /warn:declarations /warn:nofileopt /warn:unused
# ADD F90 /check:bounds /compile_only /debug:full /extend_source:132 /libs:qwin /nologo /traceback /warn:argument_checking /warn:declarations /warn:nofileopt /warn:unused
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /GZ  /c
# ADD CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /GZ  /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "_DEBUG"
# ADD RSC /l 0x407 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 IMSL.LIB IMSLS_ERR.LIB IMSLMPISTUB.LIB CXML.LIB CXMLDLL.LIB kernel32.lib /nologo /stack:0x9896800 /entry:"WinMainCRTStartup" /subsystem:windows /incremental:no /debug /machine:I386 /nodefaultlib:"dfconsol.lib" /pdbtype:sept
# ADD LINK32 IMSL.LIB IMSLS_ERR.LIB IMSLMPISTUB.LIB CXML.LIB CXMLDLL.LIB kernel32.lib /nologo /stack:0x9896800 /entry:"WinMainCRTStartup" /subsystem:windows /incremental:no /debug /machine:I386 /nodefaultlib:"dfconsol.lib" /pdbtype:sept

!ENDIF 

# Begin Target

# Name "LP - Win32 Release"
# Name "LP - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat;f90;for;f;fpp"
# Begin Source File

SOURCE=.\GaussNewton.for
DEP_F90_GAUSS=\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\LP.for
DEP_F90_LP_FO=\
	{$(INCLUDE)}"IMSLF90.mod"\
	
NODEP_F90_LP_FO=\
	".\Debug\GNP.mod"\
	".\Debug\MNR.mod"\
	".\Debug\PsiDef.mod"\
	".\Debug\Tools.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\MNR.for
DEP_F90_MNR_F=\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\Psi.for
DEP_F90_PSI_F=\
	".\Debug\Par.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\QN.FOR
DEP_F90_QN_FO=\
	".\Debug\Errors.mod"\
	".\Debug\Tools.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\QuickWin.for
# End Source File
# Begin Source File

SOURCE=.\SolveLA.for
DEP_F90_SOLVE=\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\ToolBox.for
DEP_F90_TOOLB=\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl;fi;fd"
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# End Group
# Begin Source File

SOURCE=.\Parameters.txt
# End Source File
# End Target
# End Project
