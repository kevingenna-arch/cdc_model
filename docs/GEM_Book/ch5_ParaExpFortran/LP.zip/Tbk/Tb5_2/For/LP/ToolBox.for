C Toolbox.for

C Module Definition for interfaces and variables used in Toolbox
	Module Tools

	Integer(4) GetI
	Character(256) RunTime
	Character(50) MyDate
	Real(8) Asec
	Real(8) GetD

	Logical ok, InitialSettings, GetL	            

	External MyDate, InitialSettings, GetD, GetL, GetI

	Interface 
	Real(8) Function SeqaD(xmin,step,nobs)
	         
	Integer(4) nobs
	Real(8) xmin, step
	Dimension SeqaD(1:nobs)
	
	End Function
	
	End Interface

	Interface
	Real(8) Function Ztrans(n,bounds,x)

	Integer(4) n
	Real(8) bounds(1:n,1:2), x(1:n)
	Dimension Ztrans(1:n)

	End Function

	End Interface
	
	End Module	

C**********************************************************************
C
C GetI
C
C Purpose: Same as GetD, but returns an Integer value in
C Var
C
C Usage: Call GetI(VarName,FileName,Var)

      Integer(4) Function GetI(String1,String2)

      use DFLIB 
      Character*(*), INTENT(IN) :: String1, String2
	      
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,action="Read",file=String2,err=105)
          
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) GetI
      End If
      end do
      if (I1 .eq. 0) then
	continue
	GetI=-1
      Text="Variable " // String1 // " not found in File " 
     +        //  String2 // " !"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)       
      endif
      close(99)
105   If (I1 .eq. 0) then
      Text="File not found"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return
	End Function

C*********************************************************************
C
C GetL
C
C Purpose: Same as GetD, but returns a logical value in
C Var
C
C Usage: L=GetL(VarName,FileName)

      Logical Function GetL(String1,String2)
 
      use DFLIB
      Character*(*), INTENT(IN) :: String1, String2
	      
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,action="Read",file=String2,err=107)
          
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) GetL
      End If
      end do
      if (I1 .eq. 0) then
	continue
	GetL=.false.
      Text="Variable " // String1 // " not found in File " 
     +        //  String2 // " !"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
      endif
      close(99)
107   If (I1 .eq. 0) then
       Text="File not found"
	 I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return
	End Function


C******************************************************************
C
C GetD
C
C Purpose: read a double precion variable from a text file
C
C Usage: x=GetD(VarName,FileName)
C
C
C Input: VarName:  Character*(*), the name of the variable
C                  in the file
C        FileName: Character*(*), the name of the file
C                  (must be in the current working directory
C
C Output: x: the name of the variable that is asigned the
C            number read from the file
C
C Example: Suppose in the ASCII-File Parameters.txt
C          contains the following lines\
C          alpha=0.35
C          beta=0.99
C          delta=0.01
C          The command CALL delta=GetD("delta","Parameters.txt")
C          returns 0.01 and stores that value in the variable
C          delta.
C

      Real(8) Function GetD(String1,String2)
 
      use DFLIB
      Character*(*), INTENT(IN) :: String1, String2
	      
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,file=String2,err=104)
      
      
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) GetD
      End If
      end do
      if (I1 .eq. 0) then
	continue
	GetD=-1
      Text="Variable " // String1 // " not found in file " 
     +        //  String2 // "!"
	I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL )      
      endif
      close(99)
104   If (I1 .eq. 0) then
       Text="File not found"
	 I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL )
	End If
      Return      
	End Function
	
		
C****************************************************************
C
C ElapsedTime
C
C Purpose: returns an elapsed time string
C
C Usage: Call ElapsedTime(Seconds,Time)
C
C Input:   Seconds: Real(4), gives the
C          elapsed time in seconds
C
C
C Output:  Time: Character(100), holds the
C          formated time string
C          
      Subroutine ElapsedTime(Seconds,Time)

      Real(8) Seconds, totdays, tothrs, totmins, secs
	Integer days, hrs, mins
	Character(256) Time

      if (Seconds .lt. 0.0) then
	   Write(Time,"('Negative Time')")
	   Return
	endif	
	totdays = Seconds/(3600*24)
      days = floor(totdays)
	
      tothrs = (totdays-Real(days))*24
      hrs = floor(tothrs)
	
      totmins = (tothrs-real(hrs))*60
      mins = floor(totmins)
	
      secs = (totmins-real(mins))*60;
      
      if (days .gt. 1) then
        Write(Time,"(I1,' Days')") days
      endif

	if (days .eq. 1) then    
        Write(Time,"(I1,' Day')") days
      endif

      if (days .eq. 0) then
        Time=""
      endif    
      
	if (hrs .eq. 1) then
	  write(Time,"(A,I2,A)") trim(Time), hrs, ' hour '
      endif

	if (hrs .gt. 1) then
	  write(Time,"(A,I3,A)") trim(Time), hrs, ' hours '
      endif
	
	if (mins .eq. 1) then
	  write(Time,"(A,I2,A)") trim(Time), mins, ' minute '
      endif

      if (mins .gt. 1) then
	  write(Time,"(A,I3,A)") trim(Time), mins, ' minutes '
      endif
      
	write(Time,"(A,F6.2,A)") trim(Time), secs, ' seconds'            

      RETURN
	END Subroutine
C***********************************************************************
C MyDate
C
C Purpose: Retrieve the current date and time and
C          returns it in a Character(50) string
C
C Usage: X=MyDate()

      CHARACTER(50) Function  MyDate()

	INTEGER(2) year,month,day, hour, min, sec, hsec
	CALL GETDAT(year,month,day)
	CALL GETTIM (hour, min, sec, hsec) 
	WRITE(MyDate,"(I2,'.',I2,'.',I4,'  ',I2,':',I2,':',
     +      I2)") day,month,year,hour,min,sec

      Return
	END FUNCTION



C **************************************************************************************************
C ChebEval4
C
C Evaluates a complete polynomial in four independent variables
C
C Usage: y=ChebEval4(npar,gvec,degree,z,bounds)
C
C Input: npar  := Integer(4) number of elements of gvec
C        gvec  := Real(8)    npar times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    4 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    4 times 2 matrix, first row:  lower/upper bound for z1,
C                                              second row: lower/upper bound for z2
C                                              third row:  lower/upper bound for z3
C                                              fourth row: lower/upper bound for z4
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval4(npar,gvec,degree,z,bounds)

      Integer(4) degree, npar
	Real(8)  gvec(1:npar), z(1:4), bounds(1:4,1:2)

      Integer(2) p, i, i1, i2, i3, i4, k
      Real(8) tmat(1:degree+1,1:4), y, x(1:4)
      
      p=degree+1
      x(1)=((2.0*(z(1)-bounds(1,1)))/(bounds(1,2)-bounds(1,1))) - 1.0 ! Map z1 into [-1,1] 
      x(2)=((2.0*(z(2)-bounds(2,1)))/(bounds(2,2)-bounds(2,1))) - 1.0 ! Map z2 into [-1,1] 
	x(3)=((2.0*(z(3)-bounds(3,1)))/(bounds(3,2)-bounds(3,1))) - 1.0 ! Map z3 into [-1,1]
      x(4)=((2.0*(z(4)-bounds(4,1)))/(bounds(4,2)-bounds(4,1))) - 1.0 ! Map z3 into [-1,1]

      tmat(1,1:4)=1.0
	tmat(2,1:4)=x(1:4)
	
      Do i=3,p,1
  
       tmat(i,1)=2.0*x(1)*tmat(i-1,1)-tmat(i-2,1)
       tmat(i,2)=2.0*x(2)*tmat(i-1,2)-tmat(i-2,2)
	 tmat(i,3)=2.0*x(3)*tmat(i-1,3)-tmat(i-2,3)
       tmat(i,4)=2.0*x(4)*tmat(i-1,4)-tmat(i-2,4)  
      
	End do

      y=0.0
	k=1
      Do i1=1,p,1
		Do i2=1,(p+1-i1),1
			Do i3=1,(p+2-i1-i2),1
				Do i4=1,(p+3-i1-i2-i3),1 
					y=y+gvec(k)*tmat(i1,1)*tmat(i2,2)*tmat(i3,3)*tmat(i4,4)              
					k=k+1
				End Do
			End Do
		End Do
      End Do
      ChebEval4=y

	Return
      End Function


C **************************************************************************************************
C ChebEval8
C
C Evaluates a complete polynomial in eight independent variables
C
C Usage: y=ChebEval8(npar,gvec,degree,z,bounds)
C
C Input: npar  := Integer(4) number of elements of gvec
C        gvec  := Real(8)    npar times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    8 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    8 times 2 matrix, first row:  lower/upper bound for z1,
C                                              second row: lower/upper bound for z2
C                                              third row:  lower/upper bound for z3
C                                              fourth row: lower/upper bound for z4
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval8(npar,gvec,degree,z,bounds)

      Integer(4) degree, npar
	Real(8)  gvec(1:npar), z(1:8), bounds(1:8,1:2)

      Integer(2) p, i, j, i1, i2, i3, i4, i5, i6, i7, i8, k
      Real(8) tmat(1:degree+1,1:8), y, x(1:8)
      
      p=degree+1
	Do i=1,8
		x(i)=((2.0*(z(i)-bounds(i,1)))/(bounds(i,2)-bounds(i,1))) - 1.0 ! Map z(i) into [-1,1] 
	End Do

      tmat(1,1:8)=1.0
	tmat(2,1:8)=x(1:8)
	
      Do i=3,p,1
		Do j=1,8
			tmat(i,j)=2.0*x(j)*tmat(i-1,j)-tmat(i-2,j)
		End Do
	End Do
      
      y=0.0
	k=1
      Do i1=1,p,1
		Do i2=1,(p+1-i1),1
			Do i3=1,(p+2-i1-i2),1
				Do i4=1,(p+3-i1-i2-i3),1 
					Do i5=1,(p+4-i1-i2-i3-i4),1
						Do i6=1,(p+5-i1-i2-i3-i4-i5),1
							Do i7=1,(p+6-i1-i2-i3-i4-i5-i6),1
								Do i8=1,(p+7-i1-i2-i3-i4-i5-i6-i7),1									
									y=y+gvec(k)*tmat(i1,1)*tmat(i2,2)*tmat(i3,3)*tmat(i4,4)              
     +                                           *tmat(i5,5)*tmat(i6,6)*tmat(i7,7)*tmat(i8,8)
									k=k+1
								End Do
							End Do
						End Do
					End Do
				End Do
			End Do
		End Do
      End Do
      ChebEval8=y

	Return
      End Function



C *****************************************************************************************************
C ChebCoef4
C
C Compute the coefficients of a four-dimensional complete Chebychev polynomial.
C The formula is adapted from Heer/Maussner equation (8.42) to the case of 4
C
C Usage: Call ChebCoef4(f,degree,nodes,bounds,na,avec)
C
C Input:    f pointer to the function that returns y=f(z1(i1),z2(i2),z3(i3),z4(i4))
C        degree, Integer(4), degree of the polynomial
C        nodes,  Integer(4), the number of nodes for all 4 variables
C        bounds, 4 times 2 Real(8) matrix, where bounds(1,1) the lower bound of z1,
C                                                bounds(1,2) the upper bound of z1
C                                          and so forth
C
C Output: avec, na times 1 Real(8) vector, the coefficients of the polynomial
C
C Note: the user is responsible for computing na

      Subroutine ChebCoef4(f,degree,nodes,bounds,na,avec)

      use IMSLF90      
      
	Integer(4) degree, nodes, na
	Real(8) f, bounds(4,2), avec(na)

      Integer(4) j1, j2, j3, j4, k1, k2, k3, k4, i, j	
	Real(8) x(nodes), z(nodes,4), m(4), sum	
	Real(8) dconst, pi, Cheb

	External f, dconst, Cheb

C Compute Chebyshev nodes
      pi=dconst('pi')

      Do i=1,nodes
	   x(i)=dcos(((2.*i - 1.)/(2.*dble(nodes)))*pi)                !zero of the n-th degree Chebyshev polynomila for x
	   Do j=1,4
	    z(i,j)=(x(i)+1.)*(bounds(j,2)-bounds(j,1))*0.5+bounds(j,1) !mapped into the interval on which z1 is defined
	   End Do      
	End Do

C Compute coefficients
      j=0
	Do j1=0,degree
	    m(1)=2./dble(nodes)
	    if (j1.eq.0) m(1)=1./dble(nodes)
		Do j2=0,degree-j1
			m(2)=2./dble(nodes)
			if (j2.eq.0) m(2)=1./dble(nodes)
			Do j3=0,degree-j1-j2
				m(3)=2./dble(nodes)
				if(j3.eq.0) m(3)=1./dble(nodes)
				Do j4=0,degree-j1-j2-j3
					m(4)=2./dble(nodes)
					if(j4.eq.0) m(4)=1./dble(nodes)
					j=j+1
	                sum=0.0
					Do k1=1,nodes
						Do k2=1,nodes
							Do k3=1,nodes
								Do k4=1,nodes
									sum=sum+f(z(k1,1),z(k2,2),z(k3,3),z(k4,4))*
     +									Cheb(j1,x(k1))*Cheb(j2,x(k2))*Cheb(j3,x(k3))*Cheb(j4,x(k4))
								End Do
							End Do
						End Do
					End Do
					avec(j)=m(1)*m(2)*m(3)*m(4)*sum
				End Do
			End Do
		End Do
	End Do
      
	Return

	End Subroutine

C *****************************************************************************************************
C ChebCoef8
C
C Compute the coefficients of a eight-dimensional complete Chebychev polynomial.
C The formula is adapted from Heer/Maussner equation (8.42) to the case of 8
C
C Usage: Call ChebCoef4(f,degree,nodes,bounds,na,avec)
C
C Input:    f pointer to the function that returns y=f(z), dimension z = 16
C        degree, Integer(4), degree of the polynomial
C        nodes,  Integer(4), the number of nodes for all 8 variables
C        bounds, 8 times 2 Real(8) matrix, where bounds(i,1) the lower bound of z(i)
C                                                bounds(i,2) the upper bound of z(i)
C
C Output: avec, na times 1 Real(8) vector, the coefficients of the polynomial
C
C Note: the user is responsible for computing na

      Subroutine ChebCoef8(f,degree,nodes,bounds,na,avec)

      use IMSLF90      
      
	Integer(4) degree, nodes, na
	Real(8) f, bounds(8,2), avec(na)

      Integer(4) j1, j2, j3, j4, j5, j6, j7, j8, k1, k2, k3, k4, k5, k6, k7, k8, i, j	
	Real(8) x(nodes), z(nodes,8), m(8), sum, zvec(1:8)	
	Real(8) dconst, pi, Cheb

	External f, dconst, Cheb

C Compute Chebyshev nodes
      pi=dconst('pi')

      Do i=1,nodes
	   x(i)=dcos(((2.*i - 1.)/(2.*dble(nodes)))*pi)                !zero of the n-th degree Chebyshev polynomila for x
	   Do j=1,8
	    z(i,j)=(x(i)+1.)*(bounds(j,2)-bounds(j,1))*0.5+bounds(j,1) !mapped into the interval on which z1 is defined
	   End Do      
	End Do

C Compute coefficients
      j=0
	Do j1=0,degree
	    m(1)=2./dble(nodes)
	    if (j1.eq.0) m(1)=1./dble(nodes)
		Do j2=0,degree-j1
			m(2)=2./dble(nodes)
			if (j2.eq.0) m(2)=1./dble(nodes)
			Do j3=0,degree-j1-j2
				m(3)=2./dble(nodes)
				if(j3.eq.0) m(3)=1./dble(nodes)
				Do j4=0,degree-j1-j2-j3
					m(4)=2./dble(nodes)
					if(j4.eq.0) m(4)=1./dble(nodes)
						Do j5=0,degree-j1-j2-j3-j4
							m(5)=2./dble(nodes)
							if(j5.eq.0) m(5)=1./dble(nodes)
								Do j6=0,degree-j1-j2-j3-j4-j5
									m(6)=2./dble(nodes)
									if(j6.eq.0) m(6)=1./dble(nodes)
										Do j7=0,degree-j1-j2-j3-j4-j5-j6
											m(7)=2./dble(nodes)
											if(j7.eq.0) m(7)=1./dble(nodes)
												Do j8=0,degree-j1-j2-j3-j4-j5-j6-j7
													m(8)=2./dble(nodes)
													if(j8.eq.0) m(8)=1./dble(nodes)
													j=j+1
													sum=0.0
													Do k1=1,nodes
													Do k2=1,nodes
													Do k3=1,nodes
													Do k4=1,nodes
													Do k5=1,nodes
													Do k6=1,nodes
													Do k7=1,nodes
													Do k8=1,nodes
														zvec(1)=z(k1,1)
														zvec(2)=z(k2,2)
														zvec(3)=z(k3,3)
														zvec(4)=z(k4,4)
														zvec(5)=z(k5,5)
														zvec(6)=z(k6,6)
														zvec(7)=z(k7,7)
														zvec(8)=z(k8,8)
														sum=sum+f(zvec)*
     +														Cheb(j1,x(k1))*Cheb(j2,x(k2))*
     +														Cheb(j3,x(k3))*Cheb(j4,x(k4))*
     +														Cheb(j5,x(k5))*Cheb(j6,x(k6))*
     +														Cheb(j7,x(k7))*Cheb(j8,x(k8))
													End Do
													End Do
													End Do
													End Do
													End Do
													End Do
													End Do
													End Do
					avec(j)=m(1)*m(2)*m(3)*m(4)*m(5)*m(6)*m(7)*m(8)*sum
												End Do
											End Do
										End Do
									End Do
				End Do
			End Do
		End Do
	End Do
      
	Return

	End Subroutine



C Cheb(p,x) : Returns the p-th degree of a Chebyshev-polynomial, x^p, x must be in [-1,1]
C             T_(p=0)=1,, T_(p=1)=x, T_(p=2)=2*x*T_(p=1)-T_(p=0) is and so forth

      Real(8) Function Cheb(p,x)

	Integer(4) p
	Real(8) x

	Integer(4) i
	Real(8)  x0,x1,x2


      Select Case(p)

        Case(0)
	     Cheb=1.0
	     Return

	  Case(1)
	     Cheb=x
	     Return

        Case(2:)
          x0=1.0	
	    x1=x	          
	    do i=2,p
	       x2=2.*x*x1-x0
	       x0=x1
		   x1=x2	       
          End Do	
	    Cheb=x2
      End Select

	Return

	End Function


	Integer(4) Function GetNA4(degree)

	Integer(4) degree

	Integer(4) i1, i2, i3, i4, n

	n=0
	Do i1=0,degree
		Do i2=0,degree-i1
			Do i3=0,degree-i1-i2
				Do i4=0,degree-i1-i2-i3
					n=n+1
				End Do
			End Do
		End Do
	End Do

	GetNA4=n

	Return

	End Function

C ************************************************************************************
C
C Module GH_Def: nodes and weights for Gauss-Hermite 4 point integration
C
	Module GH_Def

	Real(8) ghx(1:4), ghw(1:4)

	DATA ghx/-1.6506801230,-0.5246476232,0.5246476232,1.6506801230/
	DATA ghw/ 0.08131283544,0.8049140900,0.8049140900,0.08131283544/

	End Module GH_Def

C ************************************************************************************
C GH_INT3: Gauss-Hermite integration over a three-dimensional space using four points
C
C usage: x=GH_INT3(f,sigma)
C
C Input: f, Real(8) pointer to the function y=f(z1,z2,z3)
C           which is to be integrated
C        sigma, the standard deviation of the n(0,sigma) distribution
C Output: x, Real(8) value of the integral of y over [-inf,+inf]x[-inf,+inf]x[-inf,+inf]
C
C Remark: The integration nodes and weights (taken from Judd (1998), p. 262)
C         are stored in gcx and gcx, respectively and initialized with a data statement.
C         this takes place in the module GH_Def


	Real(8) Function GH_INT3(f,sigma)

	use GH_Def	
	use Errors
	use IMSLF90 

	Real(8) f, sigma

	Integer(4) i1, i2, i3
	Real(8) sum, s, temp, dconst, pi
	 
	pi=dconst('pi')
	sum=0.0
	s=2.0
	s=dsqrt(s)*sigma
	Do i1=1,4
		Do i2=1,4
			Do i3=1,4
				temp=f(s*ghx(i1),s*ghx(i2),s*ghx(i3))
				if (FError.ne.0) return
				sum=sum+temp*ghw(i1)*ghw(i2)*ghw(i3)
			End Do
		End Do
	End Do
	GH_INT3=sum*((pi)**(-3./2.))

	Return
	End Function

C ************************************************************************************
C GH_INT5: Gauss-Hermite integration over a five-dimensional space using four points
C
C usage: x=GH_INT5(f,sigma)
C
C Input: f, Real(8) pointer to the function y=f(z1,z2,z3,z4,z5)
C           which is to be integrated
C    sigma, the standard deviation of the n(0,sigma) distribution
C Output: x, Real(8) value of the integral of y over [-inf,+inf]^5
C
C Remark: The integration nodes and weights (taken from Judd (1998), p. 262)
C         are stored in gcx and gcx, respectively and initialized with a data statement.
C         this takes place in the module GH_Def


	Real(8) Function GH_INT5(f,sigma)

	use GH_Def	
	use Errors
	use IMSLF90 

	Real(8) f, sigma

	Integer(4) i1, i2, i3, i4, i5
	Real(8) sum, s, temp, dconst, pi
	 
	pi=dconst('pi')
	sum=0.0
	s=2.0
	s=dsqrt(s)*sigma
	Do i1=1,4
		Do i2=1,4
			Do i3=1,4
				Do i4=1,4
					Do i5=1,4
						temp=f(s*ghx(i1),s*ghx(i2),s*ghx(i3),s*ghx(i4),s*ghx(i5))
						if (FError.ne.0) return
						sum=sum+temp*ghw(i1)*ghw(i2)*ghw(i3)*ghw(i4)*ghw(i5)
					End Do
				End Do
			End Do
		End Do
	End Do
	GH_INT5=sum*((pi)**(-5./2.))

	Return
	End Function

C ************************************************************************************
C EN_Mon3: Compute the expectation of f(x), x in R^n, when the elements
C          of x are identically and indepentently normal with E(x_i)=0
C          and var(x_i)=sigma^2
C        
C          uses Formula (7.5.9) from Judd
C
C usage: int=EN_Mon3(n,sigma,f)
C
C Input: n, Integer(4), the number of independent variables
C        sigma, Real(8)
C        f, Real(8), pointer to the function f(n,x) that returns the function
C                    value at x
C       int, Real(8), the value of the integral
C
	Real(8) Function EN_Mon3(n,sigma,f)

	use Errors

	Integer(4) n
	Real(8) sigma, f

	Integer(4) i
	Real(8) r, sum, x(n)

	External f

	r=2.0
	sum=0.0
	r=dsqrt(r)*sigma*dsqrt(dble(n)/2.0)
	x=0.0

	Do i=1,n
		x(i)=r
		sum=sum+f(n,x)
		if (FError.ne.0) return
		x(i)=-r
		sum=sum+f(n,x)
		if (FError.ne.0) return
		x(i)=0.0
	End Do

	EN_Mon3=sum/(dble(n)*2.)

	Return

	End Function

C
C

C ************************************************************************************
C GH_Mon5: Monomial integration over a five-dimensional space using 
C
C		formula (7.5.9) from Judd
C
C usage: x=GH_Mon5(f,sigma)
C
C Input: f, Real(8) pointer to the function y=f(z1,z2,z3,z4,z5)
C           which is to be integrated
C   sigma, the standard deviation of the n(0,sigma) distribution
C Output: x, Real(8) value of the integral of y over [-inf,+inf]x[-inf,+inf]x[-inf,+inf]
C			x[-inf,+inf]x[-inf,+inf]
C
C Remark: The integration nodes and weights (taken from Judd (1998), p. 262)
C         are stored in gcx and gcx, respectively and initialized with a data statement.
C         this takes place in the module GH_Def


	Real(8) Function GH_Mon5(f,sigma)
	
	use Errors
	use IMSLF90 

	Real(8) f, sigma

	Real(8) sum, V, r, s, temp, dconst, pi
	 
	pi=dconst('pi')
	sum=0.0

	V=pi**(5.0/2.0)
	r=DSQRT(dble(5.0/2.0))

	s=2.0
	s=dsqrt(s)*sigma

	r=r*s
				temp=f(r,0,0,0,0)
				if (FError.ne.0) return
				sum=sum+temp

				temp=f(-r,0,0,0,0)
				if (FError.ne.0) return
				sum=sum+temp


				temp=f(0,r,0,0,0)
				if (FError.ne.0) return
				sum=sum+temp

				temp=f(0,-r,0,0,0)
				if (FError.ne.0) return
				sum=sum+temp


				temp=f(0,0,r,0,0)
				if (FError.ne.0) return
				sum=sum+temp

				temp=f(0,0,-r,0,0)
				if (FError.ne.0) return
				sum=sum+temp

				temp=f(0,0,0,r,0)
				if (FError.ne.0) return
				sum=sum+temp

				temp=f(0,0,0,-r,0)
				if (FError.ne.0) return
				sum=sum+temp

				temp=f(0,0,0,0,r)
				if (FError.ne.0) return
				sum=sum+temp

				temp=f(0,0,0,0,-r)
				if (FError.ne.0) return
				sum=sum+temp

				GH_Mon5=sum*V/10.0
				GH_Mon5=GH_Mon5*(2**2.5)
				GH_Mon5=GH_Mon5*((2*pi)**(-2.50))

		Return
	End Function



C*********************************************************************
C SeqaD
C
C Puropse: creates an additive series of double precion
C
C Usage x=SeqaD(xmin, step, nobs)
C
C Inputs:
C 
C xmin: Real(8), the first element in the series
C step: Real(8), increment
C nobs: Integer(4), number of elements in the series
C
C Output:
C
C x: Real(8) vector with nobs elements, where
C   x(i)=xmin+(i-1)*step


      Real(8) Function SeqaD(xmin,step,nobs)

	Integer(4) nobs
      Real(8)    xmin, step
	Dimension SeqaD(1:nobs)
	Integer(4) i

	SeqaD(1)=xmin
	
	do i=2,nobs
	 SeqaD(i)=SeqaD(i-1)+step	
      end do     
      
	Return
	End Function

C ***************************************************************************************
C MyStat
C
C Computes Minimum, Maximum and Standard Deviation of the
C Elements of a Vector
C
C Useage: Call MyStat(n,x,stat)
C
C Input: N: Integer(4), number of elements in x
C        X: Real(8), N times 1 vector
C
C Output: stat, Real(8), 4 times 1 vector, where
C              stat(1)=minimum of x
C              stat(2)=maximum of x
C              stat(3)=mean of x 
C              stat(4)=standard deviation of x


      Subroutine MyStat(n,x,stat)

	INTEGER(4) n, i
	REAL(8)  x(1:n), stat(4)
       
      stat(1)=MinVal(x)
	stat(2)=MaxVal(x)      
	stat(3)=dble(Sum(x)/n)
	stat(4)=0.0
	Do I=1,n
        stat(4)=stat(4)+(x(i)-stat(3))**2
      End Do
	stat(4)=DSQRT(dble(stat(4)/(n-1)))
      Return
	END SUBROUTINE


C *************************************************************************************************************
C GC_Int4
C
C Integrate a real valued function f(x1,x2,x3,x4) over [a,b]x[c,d]x[e,f]x[g,yh], using Gauss-Chebyshev quadrature
C
C Usage:  y=GC_Int(f, d, n)
C
C Input: f := Real(8) pointer to the procedure that evaluates the function, usage must be z=f(x1,x2,x3,x4)
C        d := Real(8) 4 times 2 matrix, d(i,1) lower, d(i,2) upper limit of integration for xi, i=1,2,3,4
C        n := Integer(4) 4 times 1 vector, n(i) the number of nodes for xi
C
C   Output:  Real(8) v := scalar: the (approximate) value of the integral
C
C   Remarks: if f(x1,x2,x3,x4) returns a scalar missing value (since f is not computable at this point)
C            the procedure stops and returns 


      Real(8) Function GC_Int4(f,d,n)

	use IMSLF90      
      

	Integer(4) n(4)
	Real(8) f, d(4,2)

      Integer(4) i, i1, i2, i3, i4
	Real(8) x1(n(1)), x2(n(2)), z1(n(1)), z2(n(2)), y, sum, dconst, pi
	Real(8) x3(n(3)), x4(n(4)), z3(n(3)), z4(n(4))
      External f, dconst

      pi=dconst('pi')
      Do i=1,n(1),1

         x1(i)=dcos(((2.*i - 1.)/(2.*dble(n(1))))*pi)  ! zero of the n-th degree Chebyshev polynomila for x1
         z1(i)=(x1(i)+1.)*(d(1,2)-d(1,1))*0.5 + d(1,1) ! adjusted to [a,b]                             
   
      End Do

      Do i=1,n(2)
         x2(i)=dcos(((2.*i-1.)/(2.*dble(n(2))))*pi)    ! zeros of the n-th degree Chebyshev polynomial for x2 
         z2(i)=(x2(i)+1.)*(d(2,2)-d(2,1))*0.5 + d(2,1) ! adjusted to [c,d]                             

      End Do
      
	Do i=1,n(3)
         x3(i)=dcos(((2.*i-1.)/(2.*dble(n(3))))*pi)    ! zeros of the n-th degree Chebyshev polynomial for x3 
         z3(i)=(x3(i)+1.)*(d(3,2)-d(3,1))*0.5 + d(3,1) ! adjusted to [e,f]                             

      End Do
      
	Do i=1,n(4)
         x4(i)=dcos(((2.*i-1.)/(2.*dble(n(4))))*pi)    ! zeros of the n-th degree Chebyshev polynomial for x4
         z4(i)=(x4(i)+1.)*(d(4,2)-d(4,1))*0.5 + d(4,1) ! adjusted to [g,h]                             

      End Do
      
      sum=0
      Do i1=1,n(1),1
		Do i2=1,n(2),1        
			Do i3=1,n(3),1
				Do i4=1,n(4),1
					y=f(z1(i1),z2(i2),z3(i3),z4(i4))	      
					if (isnan(y)) then
						GC_INT4=y
						Return
					Endif	      
					y=y*dsqrt(1.-(x1(i1)**2))*dsqrt(1.-(x2(i2)**2))*
     +					dsqrt(1.-(x3(i3)**2))*dsqrt(1.-(x4(i4)**2))
					sum=sum+y
				End Do        
			End Do
		End Do
	End Do
      
      sum=pi*(d(1,2)-d(1,1))*pi*(d(2,2)-d(2,1))*pi*(d(3,2)-d(3,1))*pi*(d(4,2)-d(4,1))*sum
      sum=sum/(2.*dble(n(1))*2.*dble(n(2))*2.*dble(n(3))*2.*dble(n(4)))
   
      GC_INT4=sum

	Return

	End Function
C*********************************************************************************************
C 
C Mon_IntN: Integrates a function f(n,z) over the hyper-rectangle bounds
C          using a monimial formula (formula 7.5.12 in Judd, 1998, p. 275)
C
C Usage int=Mon_IntN(n,bounds,f)
C
C Input:      n, integer, the dimension of z
C        bounds, real(8), matrix with n rows and two columns which stores
C                         the lower and upper bounds of integration,
C                         i.e., bounds(i,1) is the lower bound of z_i and bounds(i,2)
C                         the upper bound of z_i.
C             f, pointer to the function f(n,z) that returns the value of f (in R)
C                at point z. Must be declared external in the calling program
C Output: int, real(8) the approximate value of the integral
C
	Real(8) Function Mon_IntN(n,bounds,f)

	use Tools
	use Errors

	Integer(4) n
	Real(8) bounds(1:n,1:2), f

	External f

	Integer(4) i, kmax, k, iend, jend, j
	Real(8) A, B, r, D, V, sum, x(1:n), xmat(2**n,1:n)

	a=2.0
	b=5.0
	r=dsqrt(a/b)
	V=2.**n
	A=((8.-5.*n)/9.0)*V
	B=(5./18.)*V
	D=1./9.

	x=0.0
	sum=A*f(n,Ztrans(n,bounds,x))
	if (FError.ne.0) return
	Do i=1,n
		x(i)=r
		sum=sum+B*f(n,Ztrans(n,bounds,x))
		if (FError.ne.0) return
		x(i)=-r
		sum=sum+B*f(n,Ztrans(n,bounds,x))
		if (FError.ne.0) return
		x(i)=0.0
	End Do

	kmax=2**n
	iend=kmax

	Do k=1,n,1
		iend=iend/2
		Do i=1,iend,1
			jend=(kmax/iend)-2
			Do j=0,jend,2
				xmat(i+j*iend,k)=1
				xmat(i+(j+1)*iend,k)=-1
			End Do
		End Do
	End Do

	Do i=1,kmax
		sum=sum+D*f(n,Ztrans(n,bounds,xmat(i,1:n)))
		if (FError.ne.0) return		
	End Do

	Do i=1,n
		sum=sum*(bounds(i,2)-bounds(i,1))*0.5
	End Do

	Mon_IntN=sum
	Return
	End Function

C*************************************************************************************************
C

C*************************************************************************************************
C
C Ztrans: Linear transformation of n-vector x in [-1,1]^n to n-vector z in [a_1,b_1]x...x[a_n,b_n]
C
C usage z=Ztrans(n,bounds,x)
C
C Input:      n, integer(4), the dimension of x and z
C       bounds, real(8), n times 2 matrix that stores upper and lower bounds,
C                        i.e., bounds(i,1) is a_i and bounds(i,2) is b_i.
C            x, real(8), n vector
C
C Output: z, real(8), n vector

	Real(8) Function Ztrans(n,bounds,x)
	
	Integer(4) n
	Real(8) bounds(1:n,1:2), x(1:n)

	Integer(4) i

	Dimension Ztrans(1:n)

	Do i=1,n
		Ztrans(i)=0.5*(x(i)+1.)*(bounds(i,2)-bounds(i,1)) + bounds(i,1)
	End Do

	Return

	End Function


C***********************************************************************
C
C HPFilter
C
C Purpose: Compute the Hodrick-Prescott cyclical filter
C
C Usage:   CALL HPFilter(N,Y,Lambda,C)
C
C Input: N: Integer(4), the number of observations in Y
C        Y: Real(8), column vector of length N, the series whose
C                    cyclical component is to be computed
C   Lambda: Smoothing Parameter
C
C Ouput: C: Real(8), the cyclical component if Y

      Subroutine HPFilter(N,Y,Lambda,C)

      use IMSLF90 
      
	Integer(4) N
	Real(8) Y(N), Lambda, C(N)

	Integer I, NCODA, LDA
	Real(8) M(3,N)

      Parameter (LDA=3, NCODA=2)

C     Set up band matrix
      Do I=1,N
	   M(1,I)=Lambda
	   M(2,I)=-4*Lambda
	   M(3,I)=1+6*Lambda
	End Do

	M(1,1)=0.0
	M(1,2)=0.0
	M(2,1)=0.0
	M(2,2)=-2*Lambda
	M(2,N)=-2*Lambda
	M(3,1)=1+Lambda
	M(3,2)=1+5*Lambda
	M(3,N)=1+Lambda
	M(3,N-1)=1+5*Lambda
	
	CALL DLSAQS(N,M,LDA,NCODA,Y,C)
	C=Y-C

	End Subroutine

C********************************************************************
C
C Corrx
C
C Purpose: Compute correlation matrix vom data maxtrix
C
C Usage:   Call Corrx(n,m,x,crx)
C
C Input:   n, Integer(4), number of observations in x
C          m, Integer(4), number of variables (columns) in x
C          x, Real(8), n x m data matrix
C
C Output:  crx: m x m correlation matrix with standard
C               deviations on the diagonal
C
      Subroutine Corrx(n,m,x,crx)

      use IMSLF90 
	Integer(4) n, m
	Real(8) x(n,m), crx(m,m)
	
	Real(8) xbar(n,m), means(m), moment(m,m), stdv(m)
	Integer(4) I, J

C  Compute moment matrix
      means=Sum(x,dim=1)/n
	Do I=1,N
	   Do J=1,M
	    xbar(i,j)=x(i,j)-means(j)
	   End Do
	End Do
      moment=MatMul(Transpose(xbar),xbar)/dble(n-1)
      stdv=dsqrt(Diagonals(moment))
	Do I=1,M	   
	   crx(I,I)=stdv(i)
	End Do

	Do I=1,M
	   Do J=I+1,M
	      crx(i,j)=moment(i,j)/(stdv(i)*stdv(j))
	   End Do
	End Do

	End Subroutine

	  
