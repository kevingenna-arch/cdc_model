	Subroutine Euler

	use Def_Par
	use Def_Moments
	use Def_Euler
	use Errors

	use DFLIB
	use DFPORT

	Integer(4) i, j, l, fh
	Real(8) temp, k1, c0, m0, rhs, c1
	Real(8) GH_INT1, GetRHS
	   
	TYPE (rccoord) curpos            		

	External GetRHS

	fh=GetActiveQQ()
	Call GetTextPosition(curpos)
	CALL SETTEXTPOSITION(curpos.row+1,1,curpos)
	WRITE(fh,*) 'Compute Euler equation residuals'

	bind1=0

	Lsec(2)=RTC()
	Allocate(kt(1:eu_nk),zt(1:eu_nz),eer(1:eu_nk,1:eu_nz))

	Do l=1,2,1

		temp=DBLE((eu_z(l,2)-eu_z(l,1))/(eu_nz-1))		
		CALL SeqaD(eu_z(l,1),temp,eu_nz,zt)	
		temp=DBLE((kstar*(eu_k(l,2)-eu_k(l,1)))/(eu_nk-1))
		Call SeqaD(kstar*eu_k(l,1),temp,eu_nk,kt)

		Do i=1,eu_nk
		
			Do j=1,eu_nz
				zex=rho*dlog(zt(j))
				FError=0
				Call GetKCM(kt(i),dlog(zt(j)),kex,c0,m0)			
				if (m0.gt.0.0d0) bind1(l,1)=bind1(l,1)+1
				if (FError.ne.0) then
					write(lfh,"('Not able to EER at i=',I5,' and j=',I5)") i, j
					return
				Endif
				bind2=0
				rhs=GH_INT1(GetRhs,sigma)				
				bind1(l,2)=bind1(l,2)+bind2
				rhs=rhs*beta
				c1=(rhs+m0)**(-1.0d0/eta)
				eer(i,j)=(c1/c0)-1.0d0
			EndDo
		EndDo

		emax(l)=MaxVal(dabs(eer))

	End Do

	Lsec(2)=RTC()-Lsec(2)

	deallocate(kt,zt)
	Return

	End Subroutine


C Compute the rhs of the Euler equation as a function of x
	Real(8) Function GetRhs(x)	

	use Def_Par
	use Def_Euler
	use Errors

	Real(8) x

	Real(8) z1, k2, c1,  m1
	

	z1=zex+x ! note that zex=rho*dlog(zj)
	FError=0
	Call GetKCM(kex,z1,k2,c1,m1)
	if (m1.gt.0.0d0) bind2=bind2+1
	if (FError.ne.0) then
		write(lfh,"('Not able to compute RHS')")
		return
	Endif
	
	GetRhs=(c1**(-eta))*(1.d0-delta+alpha*dexp(z1)*(kex**(alpha-1.0)))-m1*(1.0d0-delta)

	Return

	End Function


C DM_Stat
	Subroutine DM

	use Def_Par
	use Def_Moments
	use Def_DM
	use Def_Euler
	Use Errors

	use IMSLF90
	use DFPORT
	use DFLIB

	Integer(4) i, j, t1, t2, t, df, fh, row, iercd
	Real(8) temp(1:2*dm_lags+1,1), xt(1:dm_nobs,1+2*dm_lags), qvec(1:2*dm_lags+1,1), vmat(1:2*dm_lags+1,1:2*dm_lags+1)
	Real(8) et(1:dm_nobs,1), DCHIIN, test(1,1), bvec(1:2*dm_lags+1,1)

	TYPE (rccoord) curpos            		

	fh=GetActiveQQ()
	Call GetTextPosition(curpos)
	CALL SETTEXTPOSITION(curpos.row+1,1,curpos)	
	WRITE(fh,*) 'Compute DM statistic'
	Call GetTextPosition(curpos)	
	row=curpos.row

	Call Erset(0,0,0)

	Lsec(3)=RTC()

C Compute random numbers, if required	
	t1=dm_nobs+dm_start+dm_lags
      Allocate(ct(1:t1),yt(1:t1),kt(1:t1+1),zt(1:t1+1),mut(1:t1+1),eps_sim(1:t1+1,1:dm_nofs))	
	
	If (dm_new_shocks) then
		Do t=1,dm_nofs
			CALL DRNNOR(t1, eps_sim(1:t1,t))
		enddo
		open (25,file='Eps_DM.bin',form='unformatted')
		write(25) eps_sim
		close(25)
	else
		open(25,file='Eps_DM.bin',form='unformatted')
		read(25,err=1, iostat=i) eps_sim
1		if (i.ne.0) then
			Call MyMessage('Not enough records to read. Restart the program and set dm_new_shocks=.true.','Error')
			stop
		else
			close(25)
		endif
	endif

	
      dm_stat=0.0d0
	kminmax=0.0d0
	zminmax=0.0d0
	kminmax(3,1)=kstar
	kminmax(3,2)=0.0d0
	
      avbc=0
	Do i=1,dm_nofs  ! loop over simulations starts here          
		zt(1)=sigma*eps_sim(1,i)
		kt(1)=kstar
		Call SetTextPosition(row+1,2,curpos)
		Write(fh,"('Simulation # ',I8)") i
		Do t=1,t1   ! simulation of time series starts here
			Call SetTextPosition(row+1,25,curpos)
			Write(fh,"('Period # ',I8)") t
			FError=0
			Call GetKCM(kt(t),zt(t),kt(t+1),ct(t),mut(t))	
			if (FError.ne.0) then
				write(lfh,"('not able to obtain solution at s=',I8,' and t=',I8,'FError= ', I1)") i, t, FError
				exit	
			endif
			zt(t+1)=rho*zt(t)   +sigma*eps_sim(t+1,i)	     
		End Do 	   
		if (FError.eq.0) then
			dm_stat(3)=dm_stat(3)+1.d0
		else
			goto 2
		endif
		avbc=avbc+count(mut(dm_start+dm_lags:t1).gt.0.0d0)
		t1=dm_nobs+dm_start+dm_lags-1

		et(1:dm_nobs,1)=zt(dm_start+dm_lags:t1)		
		Call DSORTQ("a",dm_nobs,et(1:dm_nobs,1),1)
		Do j=1,2,1
			zminmax(j,1)=zminmax(j,1)+et(dm_z(j)*dm_nobs,1)
			zminmax(j,2)=zminmax(j,2)+et((1.-dm_z(j))*dm_nobs,1)
		End Do	
		if (zminmax(3,1).gt.et(1,1)) zminmax(3,1)=et(1,1)
		if (zminmax(3,2).lt.et(dm_nobs,1)) zminmax(3,2)=et(dm_nobs,1)
	
		et(1:dm_nobs,1)=kt(dm_start+dm_lags:t1)
		Call DSORTQ("a",dm_nobs,et(1:dm_nobs,1),1)
		Do j=1,2,1
			kminmax(j,1)=kminmax(j,1)+et(dm_k(j)*dm_nobs,1)
			kminmax(j,2)=kminmax(j,2)+et((1.-dm_k(j))*dm_nobs,1)
		End Do
		if (kminmax(3,1).gt.et(1,1)) kminmax(3,1)=et(1,1)
		if (kminmax(3,2).lt.et(dm_nobs,1)) kminmax(3,2)=et(dm_nobs,1)
		Do t=dm_start+dm_lags,t1  ! computation of residual starts here
			t2=t-dm_start-dm_lags+1;
	  et(t2,1)=beta*(ct(t+1)**(-eta))*(1.d0-delta+alpha*dexp(zt(t+1))*(kt(t+1)**(alpha-1.d0)))
     +           - beta*mut(t+1)*(1.0d0-delta)-(ct(t)**(-eta))+mut(t)
			xt(t2,1)=1.0d0
			Do j=1,dm_lags
				xt(t2,1+j)=ct(t-j)
				xt(t2,1+dm_lags+j)=dexp(zt(t-j))			
			End Do
		End Do
C Regression of yt on xt	
		df=1+2*dm_lags
		qvec=MatMul(Transpose(xt),et)
		vmat=MatMul(Transpose(xt),xt)
		Call DLSADS(df,vmat,df,qvec,bvec(1:df,1))
		if (iercd() .eq. 2) then
	      write(lfh,"('Not able to regress error on lagged consumption and productivity. s= ',I5)") i
		  goto 2
	    endif
		Do t=1,dm_nobs,1
			yt(t)=et(t,1)
			Do j=1,df
				yt(t)=yt(t)-bvec(j,1)*xt(t,j)
			End Do
		End Do
		vmat=0.0d0      
		Do t=1,dm_nobs
		   temp(1:df,1)=xt(t,1:df)
		   vmat(1:df,1:df)=vmat(1:df,1:df)+(yt(t)**2)*MatMul(temp,Transpose(temp))
		End Do

		Call DLINRG(df,vmat,df,vmat,df)

		temp=MatMul(vmat,qvec)
		test=MatMul(Transpose(qvec),temp)
     
		chi(1)=0.025d0
		chi(2)=0.975d0
		
		chi(1)=DCHIIN(chi(1),dble(df))
		chi(2)=DCHIIN(chi(2),dble(df))

		if (test(1,1) .lt. chi(1)) dm_stat(1)=dm_stat(1)+1.d0
		if (test(1,1) .gt. chi(2)) dm_stat(2)=dm_stat(2)+1.d0

2     continue

      End Do

	Lsec(3)=RTC()-Lsec(3)
	deallocate(ct,yt,kt,zt,mut,eps_sim)	
	Call Erset(0,2,2) 

	Do j=1,2,1
		Do i=1,2,1
			zminmax(j,i)=dexp(dble(zminmax(j,i)/dm_nofs))
			kminmax(j,i)=dble(kminmax(j,i)/dm_nofs)/kstar
		End Do
	End Do
	zminmax(3,1)=dexp(zminmax(3,1))
	zminmax(3,2)=dexp(zminmax(3,2))
	kminmax(3,1)=kminmax(3,1)/kstar
	kminmax(3,2)=kminmax(3,1)/kstar

	Return

	End Subroutine 


