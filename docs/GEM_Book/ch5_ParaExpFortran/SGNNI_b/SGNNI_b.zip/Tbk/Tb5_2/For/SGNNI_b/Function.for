C Cheb(p,x) : Returns the p-th degree of a Chebyshev-polynomial, x^p, x must be in [-1,1]
C             T_(p=0)=1,, T_(p=1)=x, T_(p=2)=2*x*T_(p=1)-T_(p=0) is and so forth

      Real(8) Function Cheb(p,x)

	Integer(4) p
	Real(8) x

	Integer(4) i
	Real(8)  x0,x1,x2


      Select Case(p)

        Case(0)
	     Cheb=1.0d0
	     Return

	  Case(1)
	     Cheb=x
	     Return

        Case(2:)
          x0=1.0	
	    x1=x	          
	    do i=2,p
	       x2=2.*x*x1-x0
	       x0=x1
		   x1=x2	       
          End Do	
	    Cheb=x2
      End Select

	Return

	End Function

C**********************************************************************************************
C
C Mon(p,x): returns the p-th degree monomial x**p
C
	Real(8) Function Mon(p,x)

	Integer(4) p
	Real(8) x

	Integer(4) i

	Select Case(p)

		Case(0)
			Mon=1.0d0
			Return

		Case(1)
			Mon=x
			Return
		
		Case(2:)
			Mon=x
			do i=2,p
				Mon=Mon*x
			End Do
			Return

	End Select

	End Function 


C **************************************************************************************************
C ChebEval2
C
C Evaluates complete polynomial in two independent variables
C
C Usage: y=ChebEval2(gvec,ng,z,bounds)
C
C Input: gvec  := Real(8)    ng times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    2 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    2 times 2 matrix, first row: lower/upper bound for z1,
C                                             second row: lower/upper bound for for z2
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval2(gvec,degree,z,bounds)

      Integer(4) degree
	Real(8)  gvec((degree+1)*(degree+2)/2), z(1:2), bounds(1:2,1:2)

      Integer(2) p, i, j, k
      Real(8) t1(1:degree+1), t2(1:degree+1), y, x(1:2)
      
      p=degree+1
      x(1)=((2.0*(z(1)-bounds(1,1)))/(bounds(1,2)-bounds(1,1))) - 1.0 ! Map z1 into [-1,1] 
      x(2)=((2.0*(z(2)-bounds(2,1)))/(bounds(2,2)-bounds(2,1))) - 1.0 ! Map z2 into [-1,1] 

      t1(1)=1.0
	t2(1)=1.0
	t1(2)=x(1)
	t2(2)=x(2)

      Do i=3,p,1
  
       t1(i)=2.0*x(1)*t1(i-1)-t1(i-2)
       t2(i)=2.0*x(2)*t2(i-1)-t2(i-2)
         
      End do

      y=0.0
	k=1
      Do i=1,p,1
         Do j=1,(p+1-i),1
            y=y+gvec(k)*t1(j)*t2(i)
	      k=k+1
         End Do
      End Do
      ChebEval2=y

	Return
      End Function

