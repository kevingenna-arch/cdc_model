# Microsoft Developer Studio Project File - Name="SGNNI_c" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) QuickWin Application" 0x0107

CFG=SGNNI_c - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "SGNNI_c.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "SGNNI_c.mak" CFG="SGNNI_c - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "SGNNI_c - Win32 Release" (based on "Win32 (x86) QuickWin Application")
!MESSAGE "SGNNI_c - Win32 Debug" (based on "Win32 (x86) QuickWin Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
F90=df.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "SGNNI_c - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE F90 /compile_only /libs:qwin /nologo /warn:nofileopt
# ADD F90 /compile_only /libs:qwin /nologo /warn:nofileopt
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "NDEBUG"
# ADD RSC /l 0x407 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib /nologo /entry:"WinMainCRTStartup" /subsystem:windows /machine:I386 /nodefaultlib:"dfconsol.lib"
# ADD LINK32 kernel32.lib /nologo /entry:"WinMainCRTStartup" /subsystem:windows /machine:I386 /nodefaultlib:"dfconsol.lib"

!ELSEIF  "$(CFG)" == "SGNNI_c - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE F90 /check:bounds /compile_only /debug:full /extend_source:132 /libs:qwin /nologo /traceback /warn:argument_checking /warn:declarations /warn:nofileopt
# ADD F90 /check:bounds /compile_only /debug:full /extend_source:132 /libs:qwin /nologo /traceback /warn:argument_checking /warn:declarations /warn:nofileopt
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /GZ /c
# ADD CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /YX /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "_DEBUG"
# ADD RSC /l 0x407 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 IMSL.LIB IMSLS_ERR.LIB IMSLMPISTUB.LIB CXML.LIB CXMLDLL.LIB kernel32.lib /nologo /stack:0x3938700 /entry:"WinMainCRTStartup" /subsystem:windows /incremental:no /debug /machine:I386 /nodefaultlib:"dfconsol.lib" /pdbtype:sept
# ADD LINK32 IMSL.LIB IMSLS_ERR.LIB IMSLMPISTUB.LIB CXML.LIB CXMLDLL.LIB kernel32.lib /nologo /stack:0x3938700 /entry:"WinMainCRTStartup" /subsystem:windows /incremental:no /debug /machine:I386 /nodefaultlib:"dfconsol.lib" /pdbtype:sept

!ENDIF 

# Begin Target

# Name "SGNNI_c - Win32 Release"
# Name "SGNNI_c - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat;f90;for;f;fpp"
# Begin Source File

SOURCE=.\Differentiation.for
DEP_F90_DIFFE=\
	".\Debug\Errors.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\Function.for
# End Source File
# Begin Source File

SOURCE=.\MinPack.for
DEP_F90_MINPA=\
	".\Debug\Errors.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\MNR.for
DEP_F90_MNR_F=\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\Optimization.for
DEP_F90_OPTIM=\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\Projection.FOR
DEP_F90_PROJE=\
	".\Debug\Def_Moments.mod"\
	".\Debug\Def_Par.mod"\
	".\Debug\Def_Proj.mod"\
	".\Debug\Errors.mod"\
	".\Debug\GH_Def.mod"\
	".\Debug\GSPars1.mod"\
	".\Debug\MNR.MOD"\
	".\Debug\QNP.MOD"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\QuickWin.for
# End Source File
# Begin Source File

SOURCE=.\Search1.for
DEP_F90_SEARC=\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\SGNNI_c.FOR
DEP_F90_SGNNI=\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\Simulations.for
DEP_F90_SIMUL=\
	".\Debug\Def_DM.mod"\
	".\Debug\Def_Euler.mod"\
	".\Debug\Def_Moments.mod"\
	".\Debug\Def_Par.mod"\
	".\Debug\Def_Proj.mod"\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# Begin Source File

SOURCE=.\ToolBox.for
DEP_F90_TOOLB=\
	".\Debug\Errors.mod"\
	{$(INCLUDE)}"IMSLF90.mod"\
	
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl;fi;fd"
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# End Group
# Begin Source File

SOURCE=.\Parameters.txt
# End Source File
# End Target
# End Project
