C Function.for:
C
C Alfred Maussner 03 March 2008
C
C Collection of Fortran routines for function approximation
C
C - Cheb
C - Mon
C - ChebEval2
C - ChebEval3
C - ChebCoef2a
C - ChebCoef2b

C*********************************************************************************************
C Cheb(p,x) : Returns the p-th degree of a Chebyshev-polynomial, x^p, x must be in [-1,1]
C             T_(p=0)=1,, T_(p=1)=x, T_(p=2)=2*x*T_(p=1)-T_(p=0) is and so forth

      Real(8) Function Cheb(p,x)

	Integer(4) p
	Real(8) x

	Integer(4) i
	Real(8)  x0,x1,x2


      Select Case(p)

        Case(0)
	     Cheb=1.0d0
	     Return

	  Case(1)
	     Cheb=x
	     Return

        Case(2:)
          x0=1.0	
	    x1=x	          
	    do i=2,p
	       x2=2.*x*x1-x0
	       x0=x1
		   x1=x2	       
          End Do	
	    Cheb=x2
      End Select

	Return

	End Function

C**********************************************************************************************
C
C Mon(p,x): returns the p-th degree monomial x**p
C
	Real(8) Function Mon(p,x)

	Integer(4) p
	Real(8) x

	Integer(4) i

	Select Case(p)

		Case(0)
			Mon=1.0d0
			Return

		Case(1)
			Mon=x
			Return
		
		Case(2:)
			Mon=x
			do i=2,p
				Mon=Mon*x
			End Do
			Return

	End Select

	End Function 


C **************************************************************************************************
C ChebEval2
C
C Evaluates complete polynomial in two independent variables
C
C Usage: y=ChebEval2(gvec,ng,z,bounds)
C
C Input: gvec  := Real(8)    ng times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    2 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    2 times 2 matrix, first row: lower/upper bound for z1,
C                                             second row: lower/upper bound for for z2
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval2(gvec,degree,z,bounds)

      Integer(4) degree
	Real(8)  gvec((degree+1)*(degree+2)/2), z(1:2), bounds(1:2,1:2)

      Integer(2) p, i, j, k
      Real(8) t1(1:degree+1), t2(1:degree+1), y, x(1:2)
      
      p=degree+1
      x(1)=((2.0*(z(1)-bounds(1,1)))/(bounds(1,2)-bounds(1,1))) - 1.0 ! Map z1 into [-1,1] 
      x(2)=((2.0*(z(2)-bounds(2,1)))/(bounds(2,2)-bounds(2,1))) - 1.0 ! Map z2 into [-1,1] 

      t1(1)=1.0
	t2(1)=1.0
	t1(2)=x(1)
	t2(2)=x(2)

      Do i=3,p,1
  
       t1(i)=2.0*x(1)*t1(i-1)-t1(i-2)
       t2(i)=2.0*x(2)*t2(i-1)-t2(i-2)
         
      End do

      y=0.0
	k=1
      Do i=1,p,1
         Do j=1,(p+1-i),1
            y=y+gvec(k)*t1(j)*t2(i)
	      k=k+1
         End Do
      End Do
      ChebEval2=y

	Return
      End Function

C **************************************************************************************************
C ChebEval3
C
C Evaluates a product base polynomial in two independent variables
C
C Usage: y=ChebEval3(gvec,degree,z,bounds)
C
C Input: gvec  := Real(8)    ng times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) 2 times  1 vector, degree(1): degree of polynomial in z1
C                                               degree(2): degree of polynomial in z2
C        z     := Real(8)    2 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    2 times 2 matrix, first row: lower/upper bound for z1,
C                                             second row: lower/upper bound for for z2
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval3(gvec,degree,z,bounds)

      Integer(4) degree(2)
	Real(8)  gvec(degree(1)*degree(2)), z(1:2), bounds(1:2,1:2)

      Integer(2) i, j, k
      Real(8) t1(1:degree(1)), t2(1:degree(2)), y, x(1:2)
      
      
      x(1)=((2*(z(1)-bounds(1,1)))/(bounds(1,2)-bounds(1,1))) - 1. ! Map z1 into [-1,1] 
      x(2)=((2*(z(2)-bounds(2,1)))/(bounds(2,2)-bounds(2,1))) - 1. ! Map z2 into [-1,1] 

      t1(1)=1.
	t2(1)=1.
	t1(2)=x(1)
	t2(2)=x(2)

      Do i=3,degree(1),1
  
       t1(i)=2*x(1)*t1(i-1)-t1(i-2)       
         
      End do

	Do i=3,degree(2),1

	  t2(i)=2*x(2)*t2(i-1)-t2(i-2)

	End Do

      y=0
      k=1
      Do i=1,degree(1),1
         Do j=1,degree(2),1
            y=y+gvec(k)*t1(i)*t2(j)	      
	      k=k+1
         End Do
      End Do
      ChebEval3=y

	Return
      End Function


C *****************************************************************************************************
C ChebCoef2a
C
C Compute the coefficients of a two-dimensional product base Chebychev polynomial.
C The formulas used are from Heer/Maussner, equation (8.42)
C
C Usage: Call ChebCoef2a(f,degree,nodes,bounds,avec)
C
C Input:    f pointer to the function that returns y=f(z1(i1),z2(i2))
C        degree, 2 times 1 Integer(4) vector that stores the degree of the first and second variable,
C                          respectively
C        nodes,  2 times 1 Integer(4) vector that stores the number of nodes for the first and second
C                          variable, respectively
C        bounds, 2 times 2 Real(8) matrix, where bounds(1,1) the lower bound of z1,
C                                                bounds(1,2) the upper bound of z1
C                                                bounds(2,1) the lower bound of z2
C                                                bounds(2,2) the upper bound of z2
C
C Output: avec, degree(1)*degree(2) times 1 Real(8) vector, the coefficients of the polynomial
C
      Subroutine ChebCoef2a(f,degree,nodes,bounds,avec)

      use IMSLF90      
      
	Integer(4) degree(2), nodes(2)
	Real(8) f, bounds(2,2), avec(degree(1)*degree(2))

      Integer(4) i, i1, i2, k, j
	Real(8) y(nodes(1),nodes(2)), x1(nodes(1)), x2(nodes(2)), z1(nodes(1)), z2(nodes(2))
	Real(8) gvec(degree(1),degree(2))
	Real(8) dconst, pi, Cheb

	External f, dconst, Cheb

C Compute Chebyshev nodes
      pi=dconst('pi')

      Do i=1,nodes(1)
	   x1(i)=dcos(((2.*i - 1.)/(2.*dble(nodes(1))))*pi)            !zero of the n-th degree Chebyshev polynomila for x1
	   z1(i)=(x1(i)+1.)*(bounds(1,2)-bounds(1,1))*0.5+bounds(1,1)  !mapped into the interval on which z1 is defined
	End Do      

      Do i=1,nodes(2)
	   x2(i)=dcos(((2.*i - 1.)/(2.*dble(nodes(2))))*pi)           ! zero of the n-th degree Chebyshev polynomila for x2
	   z2(i)=(x2(i)+1.)*(bounds(2,2)-bounds(2,1))*0.5+bounds(2,1) ! mapped into the interval on which z2 is defined
	End Do      

C Evaluate y      
      Do i1=1,nodes(1)
	   Do i2=1,nodes(2)
            y(i1,i2)=f(z1(i1),z2(i2))
	   End Do
	End Do

C Compute coefficients according to formula (8.42)
      gvec(1,1)=sum(y)/dble(nodes(1)*nodes(2))
      Do i=2,degree(2)
	    gvec(1,i)=0.0
	    Do i1=1,nodes(1)
	       Do i2=1,nodes(2)
	          gvec(1,i)=gvec(1,i)+y(i1,i2)*Cheb(i-1,x2(i2))
	       End Do
	    End Do
	    gvec(1,i)=2.*gvec(1,i)/dble(nodes(1)*nodes(2))
	End Do

	Do i=2,degree(1)
	   gvec(i,1)=0.0
	   Do i1=1,nodes(1)
	      Do i2=1,nodes(2)
	         gvec(i,1)=gvec(i,1)+y(i1,i2)*Cheb(i-1,x1(i1))
	      End Do
	   End Do
	   gvec(i,1)=2.*gvec(i,1)/dble(nodes(1)*nodes(2))
	End Do

	Do i=2,degree(1)
	   Do j=2,degree(2)
	      gvec(i,j)=0.0
	      Do i1=1,nodes(1)
	         Do i2=1,nodes(2)
	            gvec(i,j)=gvec(i,j)+y(i1,i2)*Cheb(i-1,x1(i1))*Cheb(j-1,x2(i2))
	         End Do
	      End Do
	      gvec(i,j)=4.*gvec(i,j)/dble(nodes(1)*nodes(2))
         End do
	End Do

C Reshape gvec to avec
      k=1
	Do i=1,degree(1)
	   do j=1,degree(2)
	      avec(k)=gvec(i,j)
	      k=k+1
	   end do
	End Do

	Return

	End Subroutine

C *****************************************************************************************************
C ChebCoef2b
C
C Compute the coefficients of a two-dimensional complete Chebychev polynomial.
C The formula is adapted from Heer/Maussner equation (8.42) to the case of 4
C
C Usage: Call ChebCoef2b(f,degree,nodes,bounds,na,avec)
C
C Input:    f pointer to the function that returns y=f(z1(i1),z2(i2),z3(i3),z4(i4))
C        degree, Integer(4), degree of the polynomial
C        nodes,  Integer(4), the number of nodes for both variables
C        bounds, 2 times 2 Real(8) matrix, where bounds(1,1) the lower bound of z1,
C                                                bounds(1,2) the upper bound of z1
C
C Output: avec, na times 1 Real(8) vector, the coefficients of the polynomial
C
C Note: the user is responsible for computing na

      Subroutine ChebCoef2b(f,degree,nodes,bounds,na,avec)

      use IMSLF90      
      
	Integer(4) degree, nodes, na
	Real(8) f, bounds(2,2), avec(na)

      Integer(4) j1, j2, k1, k2, i, j	
	Real(8) x(nodes), z(nodes,2), m(2), sum	
	Real(8) dconst, pi, Cheb

	External f, dconst, Cheb

C Compute Chebyshev nodes
      pi=dconst('pi')

      Do i=1,nodes
	   x(i)=dcos(((2.0d0*i - 1.0d0)/(2.0d0*dble(nodes)))*pi)  !zero of the n-th degree Chebyshev polynomila for x
	   Do j=1,2
	    z(i,j)=(x(i)+1.0d0)*(bounds(j,2)-bounds(j,1))*0.5d0+bounds(j,1) !mapped into the interval on which z1 is defined
	   End Do      
	End Do

C Compute coefficients
      j=0
	Do j1=0,degree,1
	    m(1)=2.0d0/dble(nodes)
	    if (j1.eq.0) m(1)=1.0d0/dble(nodes)
		Do j2=0,degree-j1
			m(2)=2.0d0/dble(nodes)
			if (j2.eq.0) m(2)=1.0d0/dble(nodes)
			j=j+1
	        sum=0.0
			Do k1=1,nodes,1
				Do k2=1,nodes,1
					sum=sum+f(z(k1,1),z(k2,2))*Cheb(j1,x(k1))*Cheb(j2,x(k2))
				End Do
			End Do
			avec(j)=m(1)*m(2)*sum
		End Do
	End Do
	
	Return

	End Subroutine

C *****************************************************************************************************
