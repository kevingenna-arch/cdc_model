C ***********************************************************************************
C
C MyJac: Compute Jacobian of f using forward differences
C
C Usage: Call MyJac(m,n,x,f,df)
C
C Input: m, integer(4), the number of elements in x
C        n, integer(4), the number of elemtend returned by f(m,n,x,fx) in fx
C        x, real(8), m times 1 vector
C        f, pointer to the function f(m,n,x,fx)
C
C Output: df, real(8) n times n matrix
C
C Remarks: Code adapted from Press et al. (2001),p. 381

      Subroutine MyJac(m,n,x,f,df)

	Integer(4) n, m
	Real(8) x(m), df(n,m)

      Integer(4) i, j
	Real(8) eps, eps1, h, temp, fx1(n), fx2(n), x1(m)
	External f

      x1=x
      Call f(n,n,x,fx1)

      eps1=Epsilon(eps1)
	eps=Epsilon(eps)**(0.5)
      
      do j=1,m
	   temp=x1(j)
	   h=eps*abs(temp)
C	   if (h .eq. 0.0) h=eps
         if (h.le.eps1) h=eps
	   x1(j)=temp+h
	   h=x1(j)-temp
	   Call F(m,n,x1,fx2)
         x1(j)=temp
	   do i=1,n
	      df(i,j)=(fx2(i)-fx1(i))/h
	   end do
	end do

	return

	End Subroutine

C ***********************************************************************************
C
C CDJac: Compute Jacobian of f using central differences
C
C Usage: Call CDJac(m,n,x,f,df)
C
C Input: m, integer(4), the number of elements in x
C        n, integer(4), the number of elements returned by f(m,n,x,fx) in fx
C        x, real(8), m times 1 vector
C        f, pointer to the function f(m,n,x,fx)
C
C Output: df, real(8) n times n matrix
C
C Remarks: This is algorithm A.5.6.4. from Dennis and Schnabel (1983), p. 323

      Subroutine CDJac(m,n,x,f,df)

      use Errors
	Integer(4) n, m
	Real(8) x(m), df(n,m)

      Integer(4) i, j
	Real(8) eps, eps1, h, temp, fx1(n), fx2(n), x1(m), x2(m)
	External f

      x1=x      
      x2=x

      eps1=Epsilon(eps1)
	eps=Epsilon(eps)**(1.0/3.0)
      
      do j=1,m
	   temp=x1(j)
	   h=eps*dabs(temp)
	   if (h .le. eps1) h=eps
	   x1(j)=temp+h
	   x2(j)=temp-h
	   h=x1(j)-temp
	   Call F(m,n,x1,fx1)
	   if (FError.ne.0) return
	   Call F(m,n,x2,fx2)     
	   if (FError.ne.0) return    
	   do i=1,n
	      df(i,j)=(fx1(i)-fx2(i))/(2.*h)
	   end do
	   x1(j)=x(j)
	   x2(j)=x(j)
	end do

	return

	End Subroutine


C ***********************************************************************************
C
C CDGrad: Compute the central difference gradient of a user supplied function
C         y=f(n,x)
C
C Usage: Call CDGrad(n,x,f,df)
C
C Input: n, integer(4), the number of elements in x
C        x, real(8), n times 1 vector
C        f, pointer to the function y=f(n,x)
C
C Output: df, real(8) n times 1 vector
C
C Remarks: This is algorithm A.5.6.4. from Dennis and Schnabel (1983), p. 323
C          As there, I use eps**(1/3), instead of eps**(1/2) as in the manual of the IMSL library.
C          With this latter setting, the minization of the
C          Rosenbrock function - see QNTest.for - failed, at least when
C          I used the BFGS update of the hessian.

      Subroutine CDGrad(n,x,f,df)

	Integer(4) n
	Real(8) x(n), df(n)

      Integer(4) j
	Real(8) eps, h, temp, fx1, fx2, x1(n), x2(n), f
	External f

      x1=x      
      x2=x

	eps=Epsilon(eps)**(1.0/3.0)
      
      do j=1,n
	   if (x1(j) .lt.0.0) then
	      h=-eps*dmax1(dabs(x1(j)),1.0)
	   else
	      h=eps*dmax1(dabs(x1(j)),1.0)
	   endif
	   temp=x1(j)
	   x1(j)=temp+h
	   x2(j)=temp-h
	   h=x1(j)-temp
	   fx1=F(n,x1)
	   fx2=F(n,x2)         
	   df(j)=(fx1-fx2)/(2.*h)	
	   x1(j)=x(j)
	   x2(j)=x(j)
	end do

	return

	End Subroutine

C ***********************************************************************************
C
C FDGrad: Compute the forward difference gradient of a user supplied function
C         y=f(n,x)
C
C Usage: Call FDGrad(n,x,f,df)
C
C Input: n, integer(4), the number of elements in x
C        x, real(8), n times 1 vector
C        f, pointer to the function y=f(n,x)
C
C Output: df, real(8) n times 1 vector
C
C Remarks: This is algorithm A.5.6.3. from Dennis and Schnabel (1983), p. 322
C          
      Subroutine FDGrad(n,x,f,df)

	Integer(4) n
	Real(8) x(n), df(n)

      Integer(4) j
	Real(8) eps, h, temp, fx1, fx0, x1(n), f
	External f

      x1=x      
      fx0=f(n,x)

      eps=Epsilon(eps)**(1.0/2.0)
      
      do j=1,n
	   if (x1(j) .lt.0.0) then
	      h=-eps*dmax1(dabs(x1(j)),1.0)
	   else
	      h=eps*dmax1(dabs(x1(j)),1.0)
	   endif
	   temp=x1(j)
	   x1(j)=temp+h	   
	   h=x1(j)-temp
	   fx1=F(n,x1)	
	   df(j)=(fx1-fx0)/h	
	   x1(j)=x(j)	   
	end do

	return

	End Subroutine





C******************************************************************************************
C
C CDHesse: compute approximation of the Hesse matrix of a real valued function
C          fx=f(n,x), where x is a n vector
C
C Usage:  Call CDHesse(n,x0,f,hmat)
C
C input:  n: Integer(4), the number of elements of x0
C        x0: Real(8),    the point at which the derivatives are to be computed
C         f: pointer to the procedure that returns the value of f at x in fx
C
C output: hmat: Real(8), n by n matrix
C
C Remarks:  algorithm: based on the formulas (A.2.10) and (A.2.11) in Heer and Maussner
C
C           f must be declared as external in the calling program
C


	Subroutine CDHesse(n,x0,f,hmat)

	Integer(4) n
	Real(8) x0(1:n), hmat(1:n,1:n), f

	Integer(4) i, j
	Real(8) eps, temp, x1(1:n), x2(1:n), x3(1:n), x4(1:n), h(1:n)
 
	eps=Epsilon(eps)**(1.0/3.0)
 
	Do i=1,n,1
    
		if (x0(i).lt.0.0d0) then
			h(i)=-dmax1(dabs(x0(i)),1.d0)*eps
		else
			h(i)=dmax1(dabs(x0(i)),1.0)*eps
		endif
	
		temp=x0(i)+h(i)
		h(i)=temp-x0(i) ! the last two steps increase precision slightly, see Dennis and Schnabel (1983), p. 321 for this trick 
	End Do

	Do i=1,n,1
		x1=x0
		x2=x0
		x1(i)=x1(i)+h(i)
		x2(i)=x2(i)-h(i)
		hmat(i,i)=(f(n,x1)+f(n,x2)-2*f(n,x0))/((h(i)**2.d0))
		Do j=i+1,n,1    
			x1=x0
			x1(i)=x1(i)+h(i)
			x1(j)=x1(j)+h(j)
              x2=x0
			x2(i)=x2(i)-h(i)
			x2(j)=x2(j)+h(j)
              x3=x0
			x3(i)=x3(i)+h(i)
			x3(j)=x3(j)-h(j)
              x4=x0
			x4(i)=x4(i)-h(i)
			x4(j)=x4(j)-h(j)
			hmat(i,j)=(f(n,x1)-f(n,x2)-f(n,x3)+f(n,x4))/(4*h(i)*h(j))
			hmat(j,i)=hmat(i,j)           
		End Do
	End Do

	Return
	
	End Subroutine


