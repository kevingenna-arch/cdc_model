      Module QNP

	Integer(4) GradType      
	Logical QN_Print, QN_Global
	Real(8) QN_GradTol, QN_ParTol, QN_MaxIt, TypF

	Data QN_Print/.True./
	Data QN_Global/.True./
	Data QN_MaxIt/500./
	Data QN_GradTol/-1./
	Data QN_ParTol/-1./
	Data GradType/1/
	Data TypF/1.0/

	End Module QNP

C*************************************************************************************************************
C QuasiNewton
C
C Find the minimizer of a user supplied function y=f(nx,x)
C
C Usage: Call QuasiNewton(f,x0,x1,crit)
C
C Input:  f  : Real(8) pointer to f(nx,x) that returns the value of x, where nx is number of elements of x
C         x0 : Real(8) nx times 1 vector
C
C Output: x1 : Real(8) nx times 1 vector, the found solution
C       crit : Real(8) 5 times 1 vector, crit(1):=return code: 0: normal termination
C                                                              1: function evaluation at x not possible
C                                                              2: step2<Mstep, and no further reduction in f possible,
C                                        crit(2):=the maximum absolute value of the scaled gradient at x1                                     
C                                        crit(3):=the value of f at x1C                   
C                                        crit(4):=number of iterations
C
C  Gobals:     QN_Print    = .t. print to screen
C              QN_Global   = .t. use line search
C              QN_GradTol  = -1 use default value of MachEps**(1/3)
C              QN_ParTol   = -1 use default value of MachEps**(2/3)
C              TypF        = 1.0 as default value
C
C  Remarks: This program uses the updating formula for the inverse of the approximate Hessian matrix
C           given in Press et al. (1997), p. 420

      Subroutine QuasiNewton(f,nx,x0,x1,crit)

      use DFLIB
	use Errors
	use QNP
	use DFLIB	
	use IMSLF90 

      Integer(4) nx
	Real(8) f,x0(nx),x1(nx),crit(4)

      Logical ishere
	Integer(2) fh
      Integer(4) i
	Real(8) step, mstep, f1, f2, df1(nx), df2(nx), dx(nx), ddf(nx)
	Real(8) MinStep, GradTest2, hinv(nx,nx), x2(nx)
	 
	Type(rccoord) curpos

      External F
C Initialize
      Inquire(File='QNP.txt',Exist=ishere)
	if (ishere) then
	   Call GetD('qn_gradtol','QNP.txt',QN_GradTol)
	   Call GetD('qn_partol','QNP.txt',QN_ParTol)
	   Call GetD('qn_maxit','QNP.txt',QN_MaxIt)	   
	   Call GetL('qn_print','QNP.txt',QN_Print)
	   Call GetL('qn_global','QNP.txt',QN_Global)
      endif
C Set Default values, if not otherwise specified
      IF (QN_GradTol .lt. 0.) QN_GradTol=Epsilon(step)**(1./3.)
	IF (QN_ParTol  .lt. 0.) QN_ParTol=Epsilon(step)**(2./3.)
	
      x1=x0

C Initial function value and gradient
      FError=0
      f1=f(nx,x1)

	If (FError .ne. 0) then ! return,if x0 is not admissible
		crit(1)=1
		crit(2:3)=-1.0
		crit(4)=0.0
	   return
	endif

	if (GradType.eq.1) then
		Call CDGrad(nx,x1,f,df1)
	else
		Call FDGrad(nx,x1,f,df1)
	endif

C Test whether the current x0 is already a good solution  (as suggested by Dennis and Schnable (1983), p. 349))
      crit(2)=GradTest2(nx,df1,x1,f1,TypF)
	if (crit(2) .lt. (1.0e-3)*QN_GradTol) then
	   crit(1)=0.0	
	   crit(3)=f1
	   return
	endif

C initialize inverse of approximate Hessian and compute Newton direction
      hinv=0.0
	Do i=1,nx
	   hinv(i,i)=1.0
	       dx(i)=-df1(i)
	end do

      mstep=MinStep(nx,x1,dx) 

      crit(4)=1.0

      if (QN_Print) then
         fh=GetActiveQQ() ! Handle of active window to write messages      
	   Call ClearScreen($GCLEARSCREEN)
	   CALL SETTEXTPOSITION(1,1,curpos)
	   WRITE(fh,*) 'Algorithm Quasi Newton1'
	endif

C start iterations
      do while (crit(4) .le. QN_MaxIt)
	   
	   if (QN_Global) then
           Call QNStep(nx,x1,dx,df1,f1,mstep,F,step,f2)
	     crit(3)=f2 ! save new function value
           if ((mstep .le. 1.0) .and. (step .lt. mstep)) then ! return if it was not possible to decrease f along step*dx sufficiently
	       crit(1)=2
	       crit(3)=f1
	       return
	     endif
	   else
	     f2=F(nx,x1+dx)
	     step=1.0
	   endif
         x2=x1+step*dx ! next iterate of x
C	   f2=F(nx,x2)
		if (GradType.eq.1) then
			Call CDGrad(nx,x2,f,df2)
		else
			Call FDGrad(nx,x2,f,df2)
		Endif
	   crit(2)=GradTest2(nx,df2,x2,f2,TypF)
         if (QN_Print) then
	      Call SetTextPosition(2,1,curpos)
	      Write(fh,"('Iteration No. ',I5)") IDINT(crit(4))
            Call SetTextPosition(3,1,curpos)
	      Write(fh,"('Max. Rel. Grad: ',F20.15)") crit(2)
	      Call SetTextPosition(4,1,curpos)
	      Write(fh,"('Steplength:     ',F20.15)") step
	      Call SetTextPosition(5,1,curpos)
	      Write(fh,"('f(x):           ',F20.15)") crit(3)
	   Endif
	   if (crit(2) .lt. QN_GradTol) then	      
	        x1=x2
	   crit(3)=f2
	   crit(1)=0.0
	      return
         endif
C  BFGS update to inverse of approximate Hessian             
             dx=x2-x1
            ddf=df2-df1 ! the difference of the gradients
	     Call BFGS(nx,hinv,dx,ddf)
C store new x, compute new direction, store old gradient
	    x1=x2
          dx=-MatMul(hinv,df2)
	    f1=f2
	   df1=df2
       mstep=MinStep(nx,x1,dx) 
        crit(4)=crit(4)+1.0
       
	end do
      crit(1)=3
	Return

	End Subroutine
C****************************************************************************************************
C QNStep
C
C Computes the step size so that the Quasi Newton algorithm
C always moves in the direction of a (local) minimum of f(x)
C
C usage: Call QNStep(N,x,dx,df,f0,smin,F,s)
C
C Input: N, Integer(4) the number of elements in x,
C        x, Real(8) N times 1 vector, the current parameter estimate
C       dx, Real(8) N times 1 vector, the current change of the parameter estimate
C       df, Real(8) N times 1 vector, the gradient of f(x) at x
C       f0, Real(8), equal to f(n,x), i.e., the value of f at the current x
C     smin, Real(8), the minimal step size
C       f2, Real(8), the value of f at x0+s*dx (the next iterate of x)
C        F, pointer the function y=f(n,x) 
C
C Output: s, Real(8) the step size found by the algorithm, if the algorithm fails, s=-1.0 is returned

                 
      Subroutine QNStep(N,x,dx,df,f0,sl,F,s,f2)

      use Errors
      use QNP
      use DFLIB

	Integer(4) N
	Real(8) x(N), dx(N), df(N), f0, sl, F, s, f2

      Integer(2) fh
      Real(8) smult, smin, smax, disc, s1, s2, amat(2,2), 
     +        bvec(1:2,1), ab(1:2,1), x1(N), f1, dfdx

	Type(rccoord) curpos

      External F

C  Initialize 
      fh=GetActiveQQ() ! Handle of active window to write messages      
	smult=1.0E-4
	smin=0.1E0
	smax=0.5E0
     
	dfdx=Dot_Product(df,dx)

      s1=1.0
	s=1.0
	FError=0		
      f1=f(n,x+dx)
	Do while ((FError .ne. 0) .and. (s1 .gt. sl)) ! backtracking until f can be evaluated at x+s1*dx
	   s1=0.75*s1
	   FError=0
	   f1=f(n,x+s1*dx)
	end do
	if (s1 .lt. sl) return
	dx=s1*dx
      s1=1.

C Try the full Newton step s=1 
      if (f1 .le. (f0 + smult*dfdx)) then
        s=s1
	 f2=f1
	 return
      else
        s=-dfdx/(2.0*(f1-f0-dfdx))
        if (s .lt. smin) s=smin
        if (s  .gt. smax) s=smax
        x1=x+s*dx
	  f2=f(n,x1)
      endif
      s2=s
	
C  Reduce s2 further unless g2 < g0 + s2*smult*dgdx 
      do while (f2 .gt. (f0 + smult*s2*dfdx) )

        amat(1,1)=1.0/(s2**2)
	  amat(1,2)=-1.0/(s1**2)
	  amat(2,1)=-s1/(s2**2)
	  amat(2,2)=s2/(s1**2)
        bvec(1,1)=f2-s2*dfdx-f0
	  bvec(2,1)=f1-s1*dfdx-f0
	  ab=MatMul(amat,bvec)
	  ab=ab/(s2-s1)
	  if (ab(1,1) .eq. 0.0) then
            s=-dfdx/(2*ab(2,1))
	  else
	      disc=(ab(2,1)**2)-3*ab(1,1)*dfdx	
	      if (disc .lt. 0.0) then
	         s=s2*smax
	       elseif (ab(2,1) .le. 0.0) then                 
	         s=(-ab(2,1)+dsqrt(disc))/(3*ab(1,1))
	       else
	         s=-dfdx/(ab(2,1)+dsqrt(disc))
	       endif
	  endif	          
      
        if (s .lt. s2*smin) s=s2*smin
        if (s .gt. s2*smax) s=s2*smax

        if (s .lt. sl) return
	    
      s1=s2
      s2=s
	CALL SETTEXTPOSITION(15,1,curpos)
	   WRITE(fh,*) s
      
      f1=f2
      x1=x+s2*dx
      f2=f(n,x1)

      End Do

      Return

      End Subroutine
      
         


C***********************************************************************
C
C MinStep: Returns the minimal step size sl so that x1=x0+s*dx=0
C          (in terms of the parameter tolerance criterium)
C          
C Usage: sl=MinStep(nx,x0,dx)
C
C Input: nx, Integer(4), the number of elements in x0
C        x0, Real(8), nx times 1 vector
C        dx, Real(8), nx times 1 vector, change of x
C
C Output: sl, Real(8)

	Real(8) Function MinStep(nx,x0,dx) 

      use QNP

	Integer(4) nx
	Real(8) x0(nx), dx(nx)

	Integer(4) i
	Real(8) converge, temp

      converge=0.0

	Do i=1,nx
	   temp=dabs(dx(i))/dmax1(dabs(x0(i)),1.0)
	   if (temp .gt. converge) converge=temp
      end do

	MinStep=QN_ParTol/converge

	Return

	End Function


C********************************************************************************************
      Subroutine BFGS(n,h,dx,dgrad)

	Integer(4) n
	Real(8), intent(inout) :: h(n,n)
	Real(8), intent(in) :: dx(n), dgrad(n)

      Integer(4) i,j
      Logical pd
	Real(8) denom1, denom2, u(n), hdgrad(n), sumdx, sumdgrad
      Real(8) eps

      eps=1.e-8
	denom1=Dot_Product(dx,dgrad)
	hdgrad=MatMul(h,dgrad)
	denom2=Dot_Product(dgrad,hdgrad)
	sumdx=Dot_Product(dx,dx)
	sumdgrad=Dot_Product(dgrad,dgrad)
	 if (denom1 .gt. dsqrt(eps*sumdx*sumdgrad)) then
          u=(1./denom1)*dx - (1./denom2)*hdgrad
         do i=1,n
	      do j=i,n
	         h(i,j)=h(i,j)+(1./denom1)*dx(i)*dx(j)-(1./denom2)*
     +              hdgrad(i)*hdgrad(j) + denom2*u(i)*u(j)
	         h(j,i)=h(i,j)
	      End Do
	   End Do
	      pd=.true.
	      Do i=1,n ! check necessary condition for positive definite hinv
	         if (h(i,i) .lt. Epsilon(eps)) pd=.false.
	      End Do
		  if (.not.pd) then
		     h=0.0
			 Do i=1,n
			    h(i,i)=1.0
	         End Do
	      endif
	   endif

	Return

	End Subroutine

C*********************************************************************************************
C
C
C GradTest2: implements the gradient criterium
C            from Dennis and Schnabel (1983), p. 160
C
C different from GradTest, the typical value of f can
C set at a value different from 1.0 by the user
C
C usage: converge=GradTest(nx,df,x,fx,typf)
C
C Input:   nx, Integer(4), the number of elements in x0, x1
C          df, Real(8) vector with nx elements, the gradient of
C              f at x
C           x,  Real(8) vector with nx elements, the first value of x
C          fx, the value of f at x
C        typf, the typical value of f near xstar
C
C Output: Real(8), the maximal value of the convergence criterium

      Real(8) Function GradTest2(nx,df,x,fx,typf)                        

	Integer(4) nx
	Real(8) df(nx), x(nx), fx, typF

	Integer(4) i
	Real(8) converge, temp

      converge=0.0
	Do i=1,nx
	   temp=dabs(df(i))*dmax1(dabs(x(i)),1.0)
	   temp=temp/dmax1(dabs(fx),typf)
         if (temp .gt. converge) converge=temp
      End Do

	GradTest2=converge

	Return

	End Function

