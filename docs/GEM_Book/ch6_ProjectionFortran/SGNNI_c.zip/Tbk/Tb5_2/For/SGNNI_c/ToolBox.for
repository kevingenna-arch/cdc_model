C The file holds a number of simple tools
C that we use in our main programs
C
C     - MyMessage
C     - ElapsedTime
C     - GetD
C     - GetI
C     - GetI2
C     - GetC
C     - GetL
C     - MyDate
C     - StDev
C     - MyStat
C     - ChebEval1
C     - ChebEval4
C     - GC_Int1
C     - GC_Int2
C     - GH_Def
C     - GH_Int1
C     - SeqaD
C     - MarkovAR
C     - MarkovTR
C     - HPFilter
C     - FixpMN
C     - Corrx
C     - Vec
C     - pi

C****************************************************************
C
C MyMessage
C
C Purpose: opens a system modal Messagebox and prints Message to it
C
C Usage: Call MyMessage(MText,WText)
C
C Input: MText Character*(*): Text printed in the Box
C        WText Character*(*): Text printed in the title bar of the window
C
	Subroutine MyMessage(MText,Wtext)

	use DFLIB

	Character*(*) MText, WText
	
	Integer(4) i

	i=MessageBoxQQ(MText,WText,MB$SYSTEMMODAL)

	Return

	End Subroutine




C****************************************************************
C
C ElapsedTime
C
C Purpose: returns an elapsed time string
C
C Usage: Call ElapsedTime(Seconds,Time)
C
C Input:   Seconds: Real(4), gives the
C          elapsed time in seconds
C
C
C Output:  Time: Character(100), holds the
C          formated time string
C          
      Subroutine ElapsedTime(Seconds,Time)

      Real(8) Seconds, totdays, tothrs, totmins, secs
	Integer days, hrs, mins
	Character(256) Time

      if (Seconds .lt. 0.0) then
	   Write(Time,"('Negative Time')")
	   Return
	endif	
	totdays = Seconds/(3600*24)
      days = floor(totdays)
	
      tothrs = (totdays-Real(days))*24
      hrs = floor(tothrs)
	
      totmins = (tothrs-real(hrs))*60
      mins = floor(totmins)
	
      secs = (totmins-real(mins))*60;
      
      if (days .gt. 1) then
        Write(Time,"(I1,' Days')") days
      endif

	if (days .eq. 1) then    
        Write(Time,"(I1,' Day')") days
      endif

      if (days .eq. 0) then
        Time=""
      endif    
      
	if (hrs .eq. 1) then
	  write(Time,"(A,I2,A)") trim(Time), hrs, ' hour '
      endif

	if (hrs .gt. 1) then
	  write(Time,"(A,I3,A)") trim(Time), hrs, ' hours '
      endif
	
	if (mins .eq. 1) then
	  write(Time,"(A,I2,A)") trim(Time), mins, ' minute '
      endif

      if (mins .gt. 1) then
	  write(Time,"(A,I3,A)") trim(Time), mins, ' minutes '
      endif
      
	write(Time,"(A,F6.2,A)") trim(Time), secs, ' seconds'            

      RETURN
	END Subroutine

C******************************************************************
C
C GetD
C
C Purpose: read a double precion variable from a text file
C
C Usage: Call GetD(VarName,FileName,Var)
C
C GetD(VarName,FileName,Var)
C
C Input: VarName:  Character*(*), the name of the variable
C                  in the file
C        FileName: Character*(*), the name of the file
C                  (must be in the current working directory
C
C Output: Var: the name of the variable that is asigned the
C              number read from the file
C
C Example: Suppose in the ASCII-File Parameters.txt
C          contains the following lines\
C          alpha=0.35
C          beta=0.99
C          delta=0.01
C          The command CALL GetD("delta","Parameters.txt",delta)
C          returns 0.01 and stores that value in the variable
C          delta.
C

      Subroutine GetD(String1,String2,Pvalue)
 
      use DFLIB
      Character*(*), INTENT(IN) :: String1, String2
	
      Real(8) Pvalue
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,file=String2,err=104)
      
      
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) Pvalue
      End If
      end do
      if (I1 .eq. 0) then
	continue
	Pvalue=-1
      Text="Variable " // String1 // " not found in file " 
     +        //  String2 // "!"
	I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL )      
      endif
      close(99)
104   If (I1 .eq. 0) then
       Text="File not found"
	 I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL )
	End If
      Return      
	End Subroutine
	
C**********************************************************************
C
C GetI
C
C Purpose: Same as GetD, but returns an Integer value in
C Var
C
C Usage: Call GetI(VarName,FileName,Var)

      Subroutine GetI(String1,String2,Pvalue)

      use DFLIB 
      Character*(*), INTENT(IN) :: String1, String2
	
      Integer Pvalue
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,action="Read",file=String2,err=105)
          
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) Pvalue
      End If
      end do
      if (I1 .eq. 0) then
	continue
	Pvalue=-1
      Text="Variable " // String1 // " not found in File " 
     +        //  String2 // " !"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)       
      endif
      close(99)
105   If (I1 .eq. 0) then
      Text="File not found"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return
	End Subroutine

C**********************************************************************
C
C GetI2
C
C Purpose: Same as GetD, but returns an Integer(2) value in
C Var
C
C Usage: Call GetI(VarName,FileName,Var)

      Subroutine GetI2(String1,String2,Pvalue)

      use DFLIB 
      Character*(*), INTENT(IN) :: String1, String2
	
      Integer(2) Pvalue
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,action="Read",file=String2,err=108)
          
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) Pvalue
      End If
      end do
      if (I1 .eq. 0) then
	continue
	Pvalue=-1
      Text="Variable " // String1 // " not found in File " 
     +        //  String2 // " !"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)       
      endif
      close(99)
108   If (I1 .eq. 0) then
      Text="File not found"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return
	End Subroutine


C********************************************************************
C GetC
C
C Purpose: read a Character variable from a text file
C
C Usage: Call GetS(VarName,FileName,Var)
C
C
C Input: VarName:  Character*(*), the name of the variable
C                  in the file
C        FileName: Character*(*), the name of the file
C                  (must be in the current working directory
C
C Output: Var: the name of the variable that is asigned the
C              string read from the file
C
C Example: Suppose in the ASCII-File Parameters.txt
C          contains the following lines\
C          alpha=0.35
C          beta=0.99
C          file=outfile
C          The command CALL GetS("file","Parameters.txt",file)
C          returns the string 'outfile' in the variable file
C
C Remarks: The old name GetC conflicts with a routine GetC in DFPORT!
C

      Subroutine GetS(String1,String2,String3)
 
      use DFLIB
      Character*(*), INTENT(IN) :: String1, String2
	Character*(*), INTENT(OUT) :: String3
      
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,file=String2,err=106)
      
      
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) String3
      End If
      end do
      if (I1 .eq. 0) then
	continue
	String3=""
      Text="Variable " // String1 // " not found in file " 
     +        //  String2 // "!"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)	
      
      endif
      close(99)
106   If (I1 .eq. 0) then
        Text="File not found"
	  I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return      
	End Subroutine
	

C**********************************************************************
C
C GetL
C
C Purpose: Same as GetD, but returns a logical value in
C Var
C
C Usage: Call GetL(VarName,FileName,Var)

      Subroutine GetL(String1,String2,Pvalue)
 
      use DFLIB
      Character*(*), INTENT(IN) :: String1, String2
	
      Logical Pvalue
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,action="Read",file=String2,err=107)
          
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) Pvalue
      End If
      end do
      if (I1 .eq. 0) then
	continue
	Pvalue=-1
      Text="Variable " // String1 // " not found in File " 
     +        //  String2 // " !"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
      endif
      close(99)
107   If (I1 .eq. 0) then
       Text="File not found"
	 I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return
	End Subroutine


C***********************************************************************
C MyDate
C
C Purpose: Retrieve the current date and time and
C          returns it in a Character(50) string
C
C Usage: X=MyDate()

      CHARACTER(50) Function  MyDate()

	INTEGER(2) year,month,day, hour, min, sec, hsec
	CALL GETDAT(year,month,day)
	CALL GETTIM (hour, min, sec, hsec) 
	WRITE(MyDate,"(I2,'.',I2,'.',I4,'  ',I2,':',I2,':',
     +      I2)") day,month,year,hour,min,sec

      Return
	END FUNCTION


C*********************************************************************************
C StDev
C
C Computes the standard deviation of the elemtens in the row vector x(n)
C
C Usage: Result=StDev(n,x)
C
C        Input: n, Integer(4), the number of elements in x
C               x, Real(8), n times 1 vector
C
C        Output: Result, Real(8)


      Real(8) Function StDev(n,x)

	INTEGER(4) n
	REAL(8)  x(1:n)

      Integer(4) i
      Real(8) xmean, xsum  
      
	xsum=SUM(x)
	xmean=dble(Sum(x)/n)
	StDev=0.0
	Do i=1,n,1
        StDev=StDev+((x(i)-xmean)**2)
      End Do
	StDev=DSQRT(StDev/(n-1))
      Return
	END Function

C ***************************************************************************************
C MyStat
C
C Computes Minimum, Maximum and Standard Deviation of the
C Elements of a Vector
C
C Useage: Call MyStat(n,x,stat)
C
C Input: N: Integer(4), number of elements in x
C        X: Real(8), N times 1 vector
C
C Output: stat, Real(8), 4 times 1 vector, where
C              stat(1)=minimum of x
C              stat(2)=maximum of x
C              stat(3)=mean of x 
C              stat(4)=standard deviation of x


      Subroutine MyStat(n,x,stat)

	INTEGER(4) n, i
	REAL(8)  x(1:n), stat(4)
       
      stat(1)=MinVal(x)
	stat(2)=MaxVal(x)      
	stat(3)=dble(Sum(x)/n)
	stat(4)=0.0
	Do I=1,n
        stat(4)=stat(4)+(x(i)-stat(3))**2
      End Do
	stat(4)=DSQRT(dble(stat(4)/(n-1)))
      Return
	END SUBROUTINE


C **************************************************************************************************
C ChebEval1
C
C Evaluates a Chebyshev polynomial in one independent variable z
C
C Usage: y=ChebEval1(gvec,degree,z,bounds)
C
C Input: gvec  := Real(8)    degree times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    the point, where the polynomial is to be evaluated
C        bounds:= Real(8)    2 times 1 vector, first element:     lower bound for z,
C                                              second elementrow: upper bound for z
C
C Output:  y   := Real(8)    value of the polynomial at point z
C

      Real(8) Function ChebEval1(gvec,degree,z,bounds)

      Integer(4) degree
	Real(8)  gvec(degree), z, bounds(2)

      Integer(2) i
      Real(8) t0, t1, t2, x
            
      x=((2.0*(z-bounds(1)))/(bounds(2)-bounds(1))) - 1.0 ! Map z into [-1,1]       

      t0=1.0	
	t1=x	
      ChebEval1=0.0
	
      Do i=1,degree,1
            ChebEval1=ChebEval1+gvec(i)*t0
		         t2=2.0*x*t1-t0
				 t0=t1
				 t1=t2	      
      End Do      

	Return
      End Function





C **************************************************************************************************
C ChebEval4
C
C Evaluates a complete polynomial in three independent variables
C
C Usage: y=ChebEval4(npar,gvec,degree,z,bounds)
C
C Input: npar  := Integer(4) number of elements of gvec
C        gvec  := Real(8)    ng times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    3 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    3 times 2 matrix, first row: lower/upper bound for z1,
C                                              second row: lower/upper bound for for z2
C                                              third row:  lower/upper boudn for z3
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval4(npar,gvec,degree,z,bounds)

      Integer(4) degree, npar
	Real(8)  gvec(1:npar), z(1:3), bounds(1:3,1:2)

      Integer(2) p, i, i1, i2, i3, k
      Real(8) tmat(1:degree+1,1:3), y, x(1:3)
      
      p=degree+1
      x(1)=((2.0*(z(1)-bounds(1,1)))/(bounds(1,2)-bounds(1,1))) - 1.0 ! Map z1 into [-1,1] 
      x(2)=((2.0*(z(2)-bounds(2,1)))/(bounds(2,2)-bounds(2,1))) - 1.0 ! Map z2 into [-1,1] 
	x(3)=((2.0*(z(3)-bounds(3,1)))/(bounds(3,2)-bounds(3,1))) - 1.0 ! Map z3 into [-1,1]

      tmat(1,1:3)=1.0
	tmat(2,1:3)=x(1:3)
	
      Do i=3,p,1
  
       tmat(i,1)=2.0*x(1)*tmat(i-1,1)-tmat(i-2,1)
       tmat(i,2)=2.0*x(2)*tmat(i-1,2)-tmat(i-2,2)
	 tmat(i,3)=2.0*x(3)*tmat(i-1,3)-tmat(i-2,3)
         
      End do

      y=0.0
	k=1
      Do i1=1,p,1
         Do i2=1,(p+1-i1),1
	      Do i3=1,(p+2-i1-i2),1
               y=y+gvec(k)*tmat(i1,1)*tmat(i2,2)*tmat(i3,3)              
	         k=k+1
            End Do
         End Do
      End Do
      ChebEval4=y

	Return
      End Function


C ************************************************************************************
C
C Module GH_Def: nodes and weights for Gauss-Hermite 4 point integration
C
	Module GH_Def

	Real(8) ghx(1:4), ghw(1:4)

	DATA ghx/-1.6506801230,-0.5246476232,0.5246476232,1.6506801230/
	DATA ghw/ 0.08131283544,0.8049140900,0.8049140900,0.08131283544/

	End Module GH_Def



C ************************************************************************************
C GH_INT1: Gauss-Hermite integration over a one-dimensional space using four points
C
C usage: x=GH_INT1(f)
C
C Input: f, Real(8) pointer to the function y=f(z1)
C           which is to be integrated
C Output: x, Real(8) value of the integral of y over [-inf,+inf]
C
C Remark: The integration nodes and weights (taken from Judd (1998), p. 262)
C         are stored in gcx and gcx, respectively and initialized with a data statement.
C         this takes place in the module GH_Def


	Real(8) Function GH_INT1(f,sigma)

	use GH_Def
	use Errors
	use IMSLF90 

	Real(8) f, sigma

	Integer(4) i1
	Real(8) sum, s, temp, dconst, pi
	 
	pi=dconst('pi')
	sum=0.0
	s=2.0
	s=dsqrt(s)*sigma
	Do i1=1,4
			temp=f(s*ghx(i1))
			if (FError.ne.0) return
			sum=sum+temp*ghw(i1)
	End Do
	GH_INT1=sum*((pi)**(-1./2.))

	Return
	End Function



	 
C *****************************************************************************************************
C GC_Int1
C
C Integrate a real valued function over [a,b], using Gauss-Chebyshev quadrature
C
C Usage:  y=GC_Int(f, d, n)
C
C Input: f := Real(8) pointer to the procedure that evaluates the function, usage must be y=f(x)
C        d := Real(8) 2 times 1 vector, d(1) lower, d(2) upper limit of integration
C        n := Integer(4), the number of nodes where f is to be evaluated in order to compute y
C
C Ouput: y := Real(8), the value of the integral of f(x) over [a,b]


      Real(8) Function GC_Int1(f,d,n)

	use IMSLF90      

      Integer(4) n
      Real(8) f, d(2)

      Integer(4) i
      Real(8) x(n), z(n), sum, pi, dconst, y
		
      External f, dconst

      pi=Dconst('pi')

      Do i=1,n

         x(i)=dcos(((2.*i-1)/(2.*n))*pi)         ! zero of n-the degree Chebyshev polynomial
	   z(i)=(x(i)+1.)*(d(2)-d(1))*0.5 + d(1)   ! adjusted to [a,b]
      
	End Do
     
      sum=0
     
      do i=1,n
	   y=f(z(i))
	   if (IsNan(y)) then
	      GC_Int1=y
		  Return
	   endif     
         sum=sum+y*dsqrt(1.-(x(i)**2))          
      End do
   
      sum=pi*(d(2)-d(1))*sum
      sum=sum/(2.*n)
    
      GC_Int1=sum
      
	Return

	End Function


C *************************************************************************************************************
C GC_Int2
C
C Integrate a real valued function f(x,y) over [a,b]x[c,d], using Gauss-Chebyshev quadrature
C
C Usage:  y=GC_Int2(f, d, n)
C
C Input: f := Real(8) pointer to the procedure that evaluates the function, usage must be z=f(x,y)
C        d := Real(8) 2 times 2 matrix, d(1,1) lower, d(1,2) upper limit of integration for x,
C                                       d(2,1) lower, d(2,2) upper limit of integration for y
C        n := Integer(4) 2 times 1 vector, n[1] the number of nodes for x, n[2] the number of node for y
C
C   Output:  Real(8) v := scalar: the (approximate) value of the integral
C
C   Remarks: if f(x,y) returns a scalar missing value (since f is not computable at this point)
C            the procedure stops and returns 


      Real(8) Function GC_Int2(f,d,n)

	use IMSLF90      
	use Errors      

	Integer(4) n(2)
	Real(8) f, d(2,2)

      Integer(4) i, j
	Real(8) x1(n(1)), x2(n(2)), z1(n(1)), z2(n(2)), y, sum, dconst, pi

      External f, dconst

      pi=dconst('pi')
      Do i=1,n(1),1

         x1(i)=dcos(((2.*i - 1.)/(2.*dble(n(1))))*pi)        ! zero of the n-th degree Chebyshev polynomila for x
         z1(i)=(x1(i)+1.)*(d(1,2)-d(1,1))*0.5 + d(1,1) ! adjusted to [a,b]                             	
      End Do
	
      Do i=1,n(2)
         x2(i)=dcos(((2.*i-1.)/(2.*dble(n(2))))*pi)             ! zeros of the n-th degree Chebyshev polynomial for y 
         z2(i)=(x2(i)+1.)*(d(2,2)-d(2,1))*0.5 + d(2,1) ! adjusted to [c,d]               
	End Do
      
      sum=0
      Do i=1,n(1),1
        Do j=1,n(2),1        
            y=f(z1(i),z2(j))	      
            if (FError.ne.0) Return
	       y=y*dsqrt(1.-(x1(i)**2))*dsqrt(1.-(x2(j)**2))              
            sum=sum+y
        End Do        
      End Do
      
      sum=pi*(d(1,2)-d(1,1))*pi*(d(2,2)-d(2,1))*sum
      sum=sum/(2.*dble(n(1))*2.*dble(n(2)))
   
      GC_INT2=sum

	Return

	End Function

C*********************************************************************
C SeqaD
C
C Puropse: creates an additive series of double precion
C
C Usage Call SeqaD(xmin, step, nobs,x)
C
C Inputs:
C 
C xmin: Real(8), the first element in the series
C step: Real(8), increment
C nobs: Integer(4), number of elements in the series
C
C Output:
C
C x: Real(8) vector with nobs elements, where
C   x(i)=xmin+(i-1)*step


      Subroutine SeqaD(xmin,step,nobs,x)

	Integer(4) nobs
      Real(8)    xmin, step, x(nobs)
	      
      Integer(4) i

	x(1)=xmin
	
	do i=2,nobs
	 x(i)=x(i-1)+step	
      end do     
      
	Return
	End Subroutine

C**********************************************************************
C
C MarkovAR
C
C Purpose: Approximate AR-Process by Markov Chain
C
C Usage: Call MarkovAR(size,m,rho,sigma,z,p)
C
C Input: size, scalar, Real(8), fraction of
C                      unconditional variance of AR process,
C                      determines grid size
C
C        m, Integer(4), number of states of Markov Chain
C
C      rho, Real(8), autoregressiv parameter
C  
C    sigma, Real(8), standard deviation of innovations
C
C Output: z, m x 1, Real(8) vector, states of the Markov Chain
C
C         p, m x m, Real(8) transition matrix
C
      Subroutine MarkovAR(size,m,rho,sigma,z,p)

      use IMSLF90       

	Integer(4) m
	Real(8) size, rho, sigma, z(1:m), p(1:m,1:m)

      Real(8) sigmaz, zbar, dnordf
	Integer(4) I, J
		 
      sigmaz=dsqrt(sigma**2/(1-(rho**2)))
      zbar=size*sigmaz

      Call SeqaD(-zbar,dble(2.0*zbar/(m-1)), m,z)
  
      Do I=1,m
	
         p(i,1)=dnordf((z(1)-rho*z(i)+(z(2)-z(1))/2)/sigma)
         
	   Do j=2,m-1
   
           p(i,j)=dnordf((z(j)-rho*z(i)+(z(j)-z(j-1))/2)/sigma)-
     +             dnordf((z(j)-rho*z(i)-(z(j)-z(j-1))/2)/sigma)
           continue
	   End Do
	   p(i,m)=1-SUM(p(i,1:m-1))
	   
	End Do  
   
      End Subroutine



C*********************************************************************
C
C MarkovTP
C
C Purpose: Compute realization of Markov chain
C
C Usage: Call MarkovTP(n,m,p,i,zt)
C
C Input: n, Integer(4), length of time path
C    
C        m, Integer(4), size of transition matrix
C
C        p, Real(8), m x m Transition matrix
C
C        i0, Integer(2), index of first realization
C
C Ouptut: zt, Integer(4), n x 1 vector of indices from
C             the set 1, 2, 3, ..., m
C

      Subroutine MarkovTP(n,m,p,i0,zt)

      use IMSLF90       

	Integer(4) n, m, i0, zt(1:n)
	Real(8) p(1:m,1:m)

      Integer(4) i, j, l
      Real(8) eps(1:n), pu, po


C Draw a sequence of uniformly distributed random numbers
      Call DRNUN(n,eps)
 
      zt(1)=i0
	
	Do 10, I=1,N-1	
       j=zt(i)	 
       if (eps(i) .le. p(j,1)) then
             zt(i+1)=1	
             goto 10
       endif		   	       
       pu=p(j,1)
	 po=pu
	 Do 20, l=2,m
                 pu=po
                 po=pu+p(j,l)	
                 if ((eps(i) .gt. pu) .and. (eps(i) .le.po)) then
		         zt(i+1)=l
		         goto 20
			   endif
20    continue      

10    Continue

      End Subroutine

C***********************************************************************
C
C HPFilter
C
C Purpose: Compute the Hodrick-Prescott cyclical filter
C
C Usage:   CALL HPFilter(N,Y,Lambda,C)
C
C Input: N: Integer(4), the number of observations in Y
C        Y: Real(8), column vector of length N, the series whose
C                    cyclical component is to be computed
C   Lambda: Smoothing Parameter
C
C Ouput: C: Real(8), the cyclical component if Y

      Subroutine HPFilter(N,Y,Lambda,C)

      use IMSLF90 
      
	Integer(4) N
	Real(8) Y(N), Lambda, C(N)

	Integer I, NCODA, LDA
	Real(8) M(3,N)

      Parameter (LDA=3, NCODA=2)

C     Set up band matrix
      Do I=1,N
	   M(1,I)=Lambda
	   M(2,I)=-4*Lambda
	   M(3,I)=1+6*Lambda
	End Do

	M(1,1)=0.0
	M(1,2)=0.0
	M(2,1)=0.0
	M(2,2)=-2*Lambda
	M(2,N)=-2*Lambda
	M(3,1)=1+Lambda
	M(3,2)=1+5*Lambda
	M(3,N)=1+Lambda
	M(3,N-1)=1+5*Lambda
	
	CALL DLSAQS(N,M,LDA,NCODA,Y,C)
	C=Y-C

	End Subroutine

C********************************************************************
C
C FixpMN
C
C Purpose: find the zero of f(x) within prespecified bounds
C
C Usage: CALL FixpMN(x0,bounds,F,x)
C
C Input:   x0, Real(8), starting value
C      bounds, Real(8), 2 x 1, vector, lower and upper bounds for x
C           F, pointer to the function that computes f(x)
C
C Ouptut:   x, Real(8), the solution
C
     

      Subroutine FixpMN(x0,bounds,F,x)

      use IMSLF90 
      
	Real(8) x0, bounds(1:2), x

	Integer MaxIt, itn, korder
	Real(8) stopc, crit, bgstep, tol, df, fx, dx,step,x1,eps,
     +        xscale
	

	External F

C	Initialize 
      maxit=5000     ! stop after 5000 Iterations 
      stopc=1.0e-8   ! stopping criterium 
	eps=0.0
	xscale=1.0
	korder=1
      bgstep=0.01*abs(x0)
	tol=1.e-10
	
	x1=x0
      itn=1           
C Start Iterations
      crit=1.0
      do while ((crit .gt. stopc) .and. (itn .lt. maxit))
         Call F(1,x1,fx)
         Call DFDGRD(F,korder,x1,xscale,fx,eps,df)
         dx=-fx/df
	   x=x1+dx
         step=1
         do while ((x .lt. Bounds(1)) .or. (x .gt. bounds(2)))
          step=0.5*step         
          x=x1+step*dx
         End Do   
	   Call F(1,x,fx)      
	   crit=abs(fx)	   
         x1=x
         itn=itn+1
      End Do
      if (itn .gt. maxit) then
	   print *, 'Maximum number of iterations exceeded'
	   print *, 'Returned solution may be missleading'
      endif
      Return
      End Subroutine


C********************************************************************
C
C Corrx
C
C Purpose: Compute correlation matrix vom data maxtrix
C
C Usage:   Call Corrx(n,m,x,crx)
C
C Input:   n, Integer(4), number of observations in x
C          m, Integer(4), number of variables (columns) in x
C          x, Real(8), n x m data matrix
C
C Output:  crx: m x m correlation matrix with standard
C               deviations on the diagonal
C
      Subroutine Corrx(n,m,x,crx)

      use IMSLF90 
	Integer(4) n, m
	Real(8) x(n,m), crx(m,m)
	
	Real(8) xbar(n,m), means(m), moment(m,m), stdv(m)
	Integer(4) I, J

C  Compute moment matrix
      means=Sum(x,dim=1)/n
	Do I=1,N
	   Do J=1,M
	    xbar(i,j)=x(i,j)-means(j)
	   End Do
	End Do
      moment=MatMul(Transpose(xbar),xbar)/(n-1)
      stdv=dsqrt(Diagonals(moment))
	Do I=1,M	   
	   crx(I,I)=stdv(i)
	End Do

	Do I=1,M
	   Do J=I+1,M
	      crx(i,j)=moment(i,j)/(stdv(i)*stdv(j))
	   End Do
	End Do

	End Subroutine


C************************************************************************************
C
C Vec: the vec-operator
C
C Usage Call(n,m,amat,bvec)
C
C Input: n: Integer(4) the number of rows of Amat
C        m: Integer(4) the number of columns of Amat
C     Amat: Real(8) n times m matrix
C
C Output: bvec: Real(8) n*m vector
C
	Subroutine Vec(n,m,amat,bvec)

	Integer(4) n, m
	Real(8) amat(n,m), bvec(n*m)

	Integer(4) i,j

	j=1

	Do i=1,m
		bvec(j:i*n)=amat(1:n,i)
		j=j+n
	Enddo

	Return

	End Subroutine



C ***********************************************************************************
C
C  GSS: Golden section search to find the maximizer of y=f(x)
C
C   
C   usage: x1=GSS(f,xl,xu)
C
C   Input: f  : pointer to the function Real(8) function y=f(x)
C          xl : scalar, Real(8), lower bound of the interval in which the maximizer
C          xu : scalar, Real(8), upper bound of the interval in which the maximizer
C               lies.
C
C   Output: x1, scalar, Real(8), the approximate maximizer

	Real(8) Function GSS(f,xl,xu)

	Real(8) xl, xu
	Real(8) f

	Integer(4) i
	Real(8) tol, p, q, a, b, c, d, fb, fc, test(1:2) 

	External F

C Compute the parameters of the problem */
	tol=dsqrt(Epsilon(tol))
	p=0.5d0*(dsqrt(5.d0)-1.d0)
	q=1.d0-p

C Compute the initial interval [a,d] and the points b and c that divide it

	a=xl
	d=xu
	b=p*a+q*d
	c=q*a+p*d

C Compute the function value at b and c 
	fb=f(b)
	fc=f(c)
   
C Iterate so that the inverval gets small and smaller
	test(1)=1
	test(2)=dabs(a)+dabs(c)

	do while (dabs(d-a).gt.tol*MaxVal(test))
		if (fb.lt.fc) then ! choose [b,d] as next interval
			a=b         
			b=c
			fb=fc
			c=p*b+q*d
			fc=f(c)
		else ! choose [a,c] as next interval
			d=c
			c=b
			fc=fb
			b=p*c + q*a
			fb=f(b)
		endif
		test(2)=dabs(a)+dabs(c)
	End Do

	if (fb.gt.fc) then
		GSS=b
	else
		GSS=c
	endif

	Return
	
	End Function

C**********************************************************************************************
C
C pi returns pi=2.14....

	Real(8) Function pi

	use IMSLF90	

	Real(8) dconst

	pi=dconst('pi')

	Return

	End Function