C Module GSPars defines parameters that control the behavior
C of the GSearch routine. If one wants to change the
C default values, put the statement
C
C use GSPars
C
C in the calling program and assign new values to
C the parameters listet below in the calling program
C before the call to GSearch

      Module GSPars1

	  INTEGER(4) Npop, Ngen
	  REAL(8) Probco, mu1, mu2, mu3, s_sigma

	  DATA Npop/50/       ! size of population
	  DATA Ngen/100/      ! number of generations to compute
	  DATA Probco/0.950/  ! probability of crossover
	  DATA mu1/0.50/mu2/0.33/mu3/2.0/s_sigma/1.0/        

	END MODULE GSPars1

C Search1.for: The source code of the subroutine that
C             implements a genetic search algorithm
C             to find the minimum of a user specified
C             function
C
C CALL GSearch(Crit,Npar,Par,Fit)
C
C where Crit(Npar,Par,Fit) is the pointer to a  routine
C returning the fitness Fit of the parameter vector Par with Npar
C Elements.
C
C The Parameters that determine the performance of the algorithm
C are initialized in the module GSPars. At start, the program
C looks for a file GSP.txt. If this file is found in the
C directory where the main executable is located, the
C subroutine reads the parameters from this file. Otherwise,
C the default values from GSPars are used.
C
C 
C Te probability of mutations (ProbMut) is
C calculated from
C
C ProbMut(itnum)=mu1 + (mu2/itnum)
C
C and the change of an element choosen for mutation
C is given by
C 
C add=lambda*(1-var1**( (1-(mu3*itnum/Ngen))**mu4 )
C
C where lambda is a random draw from the standard normal distribution
C var1 is a random draw from the uniform distribution over [0,1]
C and add is added (subtracted) to an element if another draw from the uniform
C distribution var1 is > 0.5 (<0.5). Thus, if mu3=1.0, there
C are no mutations performed on any element in generation itnum=Ngen.
C
C and mu4 is used in the mutation operations.


      Subroutine GSearch1(Crit,Npar,Par,Fit)

	use Errors
      Use DFLIB
      use IMSLF90 
	use GSPars1      

	INTEGER(4)  P(4), Sort1(1:4), GMaxMin(1:2,1:2), IDMIN, IDMAX
	INTEGER(4) I, J, K, G, Npar, itnum, fh
	INTEGER(4) MutNum(3)
      REAL(8)  Crit
	REAL(8)  Par(Npar), Fit
      REAL(8), Allocatable ::  Genes0(:,:)
	REAL(8), Allocatable ::  Genes1(:,:)
	REAL(8)  Stat(1:4)
	REAL(8)  SelectP(1:4,1:Npar+3)
	REAL(8)  P1(1:Npar+1), P2(1:Npar+1)
	REAL(8)  C1(1:Npar+2), C2(1:Npar+2)
	REAL(8)  choose, lambda, add
      REAL(8)  probmut, mutvars(1:2)
	Logical  ishere
	EXTERNAL Crit      
		
	TYPE (rccoord) curpos

C Definition of the function that computes the probability of mutations at
C generation itnum
      ProbMut(itnum)=mu1+DBLE(mu2/itnum)

C Read parameters from GSP.txt (if here)
      Inquire(File='GSP1.txt',Exist=ishere)
	if (ishere) then
	   Call GetI('npop','GSP1.txt',npop)
	   Call GetI('ngen','GSP1.txt',ngen)
	   Call GetD('probco','GSP1.txt',Probco)
	   Call GetD('mu1   ','GSP1.txt',mu1)
	   Call GetD('mu2   ','GSP1.txt',mu2)
         Call GetD('mu3   ','GSP1.txt',mu3)	   
	   Call GetD('s_sigma ','GSP1.txt',s_sigma)
      endif
      
	Allocate(Genes0(1:Npop,1:Npar+2))
	Allocate(Genes1(1:Npop,1:Npar+2)) 

C Open Output Window
      fh=GetActiveQQ() ! Handle of active window to write messages
      
      Call ClearScreen($GWINDOW)
	CALL SETTEXTPOSITION(2,1,curpos)
	WRITE(fh,*) 'Algorithm Search 1'
	CALL SETTEXTPOSITION(3,1,curpos)
	WRITE(fh,*) 'Initialize first generation:'

C Select random number generator
      CALL RNOPT(4)

C Initialize Gene Pool     
      Do I=1,Npop	   
	   CALL SETTEXTPOSITION(3,33,curpos)
	   WRITE(fh,"('Gene #: ',I4)") I
	   CALL DRNNOR(Npar, Par)	
	   Par=s_sigma*Par   
         Fit=Crit(Npar,Par)
	   j=1  	   
	   Do While (Fit .lt. 0.0)
	      j=j+1
	      CALL DRNNOR(Npar, Par)	   	      
            Fit=Crit(NPar,Par)
	      CALL SetTextPosition(3,46,curpos)
	      WRITE(fh,"('Trials= ',I10,' ErrorType= ',I2)") j,FError
	   End Do
	   Genes0(I,1:Npar)=Par(1:Npar)	   	   	   	   
	   Genes0(I,NPar+1)=Fit	  
	End Do   
      CALL MyStat(Npop,Genes0(1:npop,Npar+1),Stat)
	CALL SETTEXTPOSITION(5,2,curpos)
      Write(fh,"('Minimum:            ',E20.4E3)") Stat(1)
	CALL SETTEXTPOSITION(6,2,curpos)
	Write(fh,"('Maximum:            ',E20.4E3)") Stat(2)
      CALL SETTEXTPOSITION(7,2,curpos)
	Write(fh,"('Standard deviation: ',E20.4E3)") Stat(4)

C genetic search:

      Do itnum=1,Ngen,1
	MutNum=0	
		
      CALL SETTEXTPOSITION(9,2,curpos)
	Write(fh,"('Generation #: ',I5)") itnum

      CALL SETTEXTPOSITION(12,2,curpos)
	Write(fh,*) 'Old:  '
	CALL SETTEXTPOSITION(13,2,curpos)
	Write(fh,*) 'Joung:'
	CALL SETTEXTPOSITION(11,25,curpos)
	Write(fh,*) 'Best: '
	CALL SETTEXTPOSITION(11,55,curpos)
	Write(fh,*) 'Worst:'

C Generate a new generation
      Do G=1,npop,2      
      
C Select to pairs of parents
      CALL RNUND (4, Npop, P)    

      Do I=1,4,1
        SelectP(I,1:Npar+1)=Genes0(P(I),1:Npar+1)
	End Do
      CALL DSORTQX("A",4,SelectP(1:4,Npar+1),1,Sort1)
	SelectP=SelectP(Sort1,1:Npar+3)
      P1=SelectP(1,1:Npar+1)
	P2=SelectP(2,1:Npar+1)

C Crossover Operations 
      CALL DRNUN (1, choose)
	if (choose .le. probco) then
	   CALL RNUND (1, 3, J)
	   if (J .eq. 1) then ! arithmetic crossover
	       CALL DRNUN(1,lambda)		                
		   C1(1:Npar)=lambda*P1(1:Npar) + (1-lambda)*P2(1:Npar)
	       C2(1:Npar)=lambda*P2(1:Npar) + (1-lambda)*P1(1:Npar)
	   End IF
	   if (J .eq. 2) then !Single point crossover
	       CALL RNUND (1, Npar-1, K)	        
             C1(1:K)=P1(1:K)
	       C1(1+K:Npar)=P2(1+K:Npar)
	       C2(1:K)=P2(1:K)
	       C2(1+K:Npar)=P1(1+K:Npar)             
         End IF
	   if (J .eq. 3) then ! Shuffle crossover             
             Do K=1,Npar
                CALL DRNUN (1, lambda)
		      if ( lambda .gt. 0.5) then
	             C1(K)=P2(K)
	             C2(K)=P1(K)
	          else               
                   C1(K)=P1(K)
                   C2(K)=P2(K)
                End IF
	       END DO
	   END IF
      ELSE         
	   C1(1:Npar+1)=P1(1:NPar+1)
	   C2(1:Npar+1)=P2(1:NPar+1)
	END IF

C Mutation operations on C1
      ishere=.false.
      C1(Npar+2)=0.0

      Do J=1,Npar
         CALL DRNUN (1, choose)
	   if (choose .lt. ProbMut(itnum)) then
	      ishere=.true.
	      C1(Npar+2)=C1(Npar+2)+1.0
	      CALL DRNNOR(1, lambda)	   	   	      
	      CALL DRNUN(2,mutvars)
	      add=lambda*
     +	  (1-(mutvars(2)**((1-(DBLE(itnum/Ngen)))**mu3)))
	      if (mutvars(1) .gt. 0.5) then	        
	        C1(J)=C1(J)+add     	
            else  
              C1(J)=C1(J)-add
            End IF
	    END IF
      END DO
      if (ishere) MutNum(3)=MutNum(3)+1

C Mutation operations on C2
      ishere=.false.
	C2(Npar+2)=0.0

      Do J=1,Npar
         CALL DRNUN (1, choose)
	   if (choose .lt. ProbMut(itnum)) then  
	      ishere=.true.          
	      C2(Npar+2)=C2(Npar+2)+1.0
	      CALL DRNNOR(1, lambda)	   	   	      	      
	      CALL DRNUN(2,mutvars)
	      add=lambda*
     +		  (1-(mutvars(2)**((1-(DBLE(itnum/Ngen)))**mu3)))
	      if (mutvars(1) .gt. 0.5) then
	        C2(J)=C2(J)+add     
            else  
              C2(J)=C2(J)-add
            End IF
	    END IF
      END DO
	if (ishere) MutNum(3)=MutNum(3)+1
      MutNum(1)=MutNum(1)+IDINT(C1(Npar+2))+IDINT(C2(Npar+2))
      
C Determine fitness of children, select the best among children and parents
C      Call Crit(Npar,C1(1:Npar), C1(Npar+1))
      C1(Npar+1)=Crit(Npar,C1(1:Npar))
C	Call Crit(Npar,C2(1:Npar), C2(Npar+1))
      C2(Npar+1)=Crit(Npar,C2(1:Npar))
      	
	SelectP(1,1:Npar+1)=P1(1:Npar+1)
	SelectP(1,Npar+2)=0.0 !is parent
	SelectP(2,1:Npar+1)=P2(1:Npar+1)
	SelectP(2,Npar+2)=0.0 !is parent
	SelectP(3,1:Npar+1)=C1(1:Npar+1)
	SelectP(3,Npar+2)=1.0 !is child
	SelectP(3,Npar+3)=C1(Npar+2)!with # mutations
	SelectP(4,1:Npar+1)=C2(1:Npar+1)
	SelectP(4,Npar+2)=1.0 !is child
	SelectP(4,Npar+3)=C2(Npar+2)!with # mutations
 
      CALL DSORTQX("A",4,SelectP(1:4,Npar+1),1,Sort1)
	SelectP=SelectP(Sort1,1:Npar+3)
	J=1
	Do while (SelectP(J,Npar+1) .lt. 0.0)
	   J=J+1
	END DO
      
	if ((SelectP(J,Npar+2) .gt. 0.0)
     +   .and. (SelectP(J,Npar+3) .gt. 0.0)) then !a mutated child survived
	   MutNum(2)=MutNum(2)+1	      
	endif

      if ((SelectP(J+1,Npar+2) .gt. 0.0)
     +   .and. (SelectP(J+1,Npar+3) .gt. 0.0)) then !a mutated child survived
	   MutNum(2)=MutNum(2)+1	      
	endif

C add to new generation
      Genes1(G,1:Npar+1)=SelectP(J,1:Npar+1)
	Genes1(G+1,1:Npar+1)=SelectP(J+1,1:Npar+1)

	END DO

C Elitism
      GMaxMin(1,1)=IDMIN(npop,Genes0(1:npop,Npar+1),1)
	GMaxMin(1,2)=IDMAX(npop,Genes0(1:npop,Npar+1),1)
      GMaxMin(2,1)=IDMIN(npop,Genes1(1:npop,Npar+1),1)
	GMaxMin(2,2)=IDMAX(npop,Genes1(1:npop,Npar+1),1)
		
	CALL SETTEXTPOSITION(12, 15, curpos) 
	Write(fh,102) genes0(GMaxMin(1,1),Npar+1)
	CALL SETTEXTPOSITION(12,45,curpos)
	Write(fh,102)  genes0(GMaxMin(1,2),Npar+1)
	CALL SETTEXTPOSITION(13,15,curpos)
	Write(fh,102)  genes1(GMaxMin(2,1),Npar+1)
	CALL SETTEXTPOSITION(13,45,curpos)
	Write(fh,102)  genes1(GMaxMin(2,2),Npar+1)
      CALL SETTEXTPOSITION(15,1,curpos)
	WRITE(fh,"('Number of mutated elements: ',I4)") MutNum(1)
	Call SetTextPosition(15,35,curpos)	
	WRITE(fh,"('fraction of total: ',F6.3)")
     + (dble(MutNum(1))/dble(npop*npar)) 
	CALL SETTEXTPOSITION(16,1,curpos)
	WRITE(fh,"('Number of survived mutants: ',I4)") MutNum(2)
      CALL SETTEXTPOSITION(16,35,curpos)
	WRITE(fh,"('fraction of total: ',F6.3)")
     + (dble(MutNum(2))/dble(MutNum(3))) 
	if (Genes1(GMaxMin(2,1),Npar+1) .gt.
     +	 Genes0(GMaxMin(1,1),Npar+1)) then
	   Genes1(GMaxMin(2,2),1:Npar+1)=
     +	   Genes0(GMaxMin(1,1),1:Npar+1)	   
	endif
	Genes0=Genes1      
      	
	END DO

      Par=Genes1(GMaxMin(2,1),1:Npar)
      Fit=Genes1(GMaxMin(2,1),Npar+1)
      
102   Format(E25.6E3)
      
      Return
      END SUBROUTINE



