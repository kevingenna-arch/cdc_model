C Function.for:
C
C Routines for function approximation
C
C CSpline
C CSplint
C LIP
C BLIP
C Cheb
C Mon
C ChebEval1
C ChebEval2
C ChebEval3
C ChebEval4
C ChebCoef2a
C ChebCoef2b
C ChebCoef3
C
C
C********************************************************************************************
C CSPLINE
C
C Computes the second derivatives for the CUBIC SPLINE APPROXIMATION
C
C	First run CSPLINE once, then CSPLINT to evaluate the function
C 
C
C Useage: Call CSPLINE(x,y,n,cmethod1,yp1,ypn,y2)
C
C Input:  N: Integer(4), number of elements in x
C         X: Real(8), N times 1 vector, nodes
C		Y: Real(8), N times 1 vector, function values at nodes
C		cmethod1: Integer(4), cubic spline method
C			if 1 - natural cubic spline, 
C			if 2 - secant hermite spline
C			if 3 - first derivaties at x(1) and x(n) are specified as yp1 and ypn
C		yp1: Real(8), 1st derivative at x(1)
C		ypn: Real(8), 1st derivative at x(n)
C
C Output: y2: Real(8), n times 1 vector
C              second derivatives at x(i), i=1,n
C
C

      Subroutine cspline(x,y,n,cmethod1,yp1,ypn,y2)

	Integer(4) n,cmethod1
	Real(8) x(1:n),y(1:n),yp1,ypn,y2(1:n)

	Integer(4) i,k
	Real(8) p,qn,sig,un,u(1:n)

	y2=0.0

	Select Case(cmethod1)

		Case(1)		! natural cubic spline
			y2(1)=0.0d0
			u(1)=0.0d0
			qn=0.d0
			un=0.d0				
		Case(2)		! secant hermite
			yp1=(y(2)-y(1))/(x(2)-x(1))
			ypn=(y(n)-y(n-1))/(x(n)-x(n-1))
			y2(1)=-0.5d0
			u(1)=(3.d0/(x(2)-x(1)))*((y(2)-y(1))/(x(2)-x(1))-yp1)
			qn=0.5d0
			un=(3.d0/(x(n)-x(n-1)))*(ypn-(y(n)-y(n-1))/(x(n)-x(n-1)))
		Case(3)
			y2(1)=-0.5d0
			u(1)=(3.d0/(x(2)-x(1)))*((y(2)-y(1))/(x(2)-x(1))-yp1)
			qn=0.5d0
			un=(3.d0/(x(n)-x(n-1)))*(ypn-(y(n)-y(n-1))/(x(n)-x(n-1)))

	End Select			

	Do i=2,n-1
		sig=(x(i)-x(i-1))/(x(i+1)-x(i-1))
		p=sig*y2(i-1)+2.d0
		y2(i)=(sig-1.d0)/p
	u(i)=(6.d0*((y(i+1)-y(i))/(x(i+1)-x(i))-(y(i)-y(i-1))/(x(i)-x(i-1)))/(x(i+1)-x(i-1))-sig*u(i-1))/p
	End Do

	y2(n)=(un-qn*u(n-1))/(qn*y2(n-1)+1.d0)

	Do k=n-1,1,-1
		y2(k)=y2(k)*y2(k+1)+u(k)
	End Do

	return

	END

C************************************************************************************************
C CSPLINT
C
C Computes the CUBIC SPLINE APPROXIMATION
C
C	First run SPLINE once, then SPLINT to evaluate the function
C 
C
C Useage: Call CSPLINT(x,y,y2,n,cmethod2,x0,m,y0)
C
C Input:  N: Integer(4), number of elements in x
C         X: Real(8), N times 1 vector, nodes
C		Y: Real(8), N times 1 vector, function values at nodes
C		Y2: Real(8), N times 1 vector, 2nd derivatives of function at nodes
C		cmethod2: Integer(4), method to allocate nearest nodes
C			if 1 - equally spaced nodes x(1), x(2), ..
C			if 2 - bisection
C		X0: Real(8), M times 1 vector, points at which the function is approximated
C		
C
C Output: y0: Real(8), m times 1 vector
C              function approximation at x(1:m)
C
C

      Subroutine csplint(x,y,y2,n,cmethod2,x0,m,y0)

	use DFLIB

	Integer(4) n,m,cmethod2
	Real(8) x(1:n),y(1:n),y2(1:n),x0(1:m),y0(1:m)

	Integer(4) k,klo,khi,i
	Real(8) a,b,h

	Do i=1,m

	if (x0(i).ge.x(n)) then
		y0(i)=y(n)

	else

	Select Case(cmethod2)

		Case(1)		! equi-distant points
C			klo=1+(x0(i)-x(1))/(x(2)-x(1))
              klo=floor((x0(i)-x(1))/(x(2)-x(1)))+1
              khi=1+klo
			if (khi.gt.n) then
				Call MyMessage("x outside of grid! Program stops","CSplint")
				stop
			endif
		
		Case(3) ! equi-distant point in log scale
			klo=floor( (dlog(x0(i))-dlog(x(1)))/(dlog(x(2))-dlog(x(1))))+1
			khi=1+klo
			if (khi.gt.n) then
				Call MyMessage("x outside of grid! Program stops","CSplint")
				stop
			endif

		Case(2)		! bisection
			klo=1
			khi=n
			do while ((khi-klo).gt.1)
C2			if (khi-klo.gt.1) then
				k=(khi+klo)/2
				if (x(k).gt.x0(i)) then
					khi=k
				else 
					klo=k
				endif
			Enddo
C			goto 2
C			endif


	End Select			

	h=x(khi)-x(klo)
	
	a=(x(khi)-x0(i))/h
	b=(x0(i)-x(klo))/h
	y0(i)=a*y(klo)+b*y(khi)+((a**3-a)*y2(klo)+(b**3-b)*y2(khi))*(h**2)/6.d0

	endif

	End Do
	return
	END

C***************************************************************************************
C
C   LIP:     given a function y=f(x) tabulated in xvec and yvec and a point x0,
C            return the function value y0=f(x0) obtained from linear interpolations
C            between x1<x<x2.
C
C    Usage: y0=LIP(n,xvec,yvec,x0)
C
C   Input:  xvec: n by 1 Real(8) vector, the tabulated values of the independent variable x
C           yvec: n by 1 Real(8) vector, the tabulated values of the dependent variable y
C             x0: scalar, Real(8), the value of the independent variable for which y0 is
C                 to be computed.
C
C   Output:   y0: scalar, Real(8), see above.
C

	Real(8) Function LIP(n,xvec,yvec,x0)

	Integer(4) n
	Real(8) xvec(1:n), yvec(1:n), x0

	Integer(4) j, k
	
      if ((x0.lt.xvec(1)) .or. (x0.gt.xvec(n))) then
		Call MyMessage("Input of of grid!","LIP-Error")
		LIP=x0
	endif
	if (x0.eq.xvec(1)) then
		LIP=yvec(1)
	elseif (x0.eq.xvec(n)) then
		LIP=yvec(n)
	else
		j=count(xvec.le.x0) ! this determines the lower bracket for x0 
		LIP=yvec(j)+((yvec(j+1)-yvec(j))/(xvec(j+1)-xvec(j)))*(x0-xvec(j))
      endif;

	Return

	End Function

		
C***************************************************************************************
C
C BLIP: Bilinear Interpolation as given by Formulas (3.6.1) through (3.6.5)
C           in Press et al. (1992), S. 116f.
C
C Usage: z=BLIP(n,m,xvec,yvec,zmat,x,y)
C
C Input: n = Integer(4) the number of points in the grid of variable x
C        m = Integer(4) the number of points in the grid of variable y
C     xvec = Real(8), vector of dimension n, the grid of variable x
C     yvec = Real(8), vector of dimension m, the grid of variable y
C     zmat = Real(8), n times m matrix, with tabulated function values at
C                     z(i,j)=f(x(i),y(j), i=1, ..., n, j=1, ...,m
C        x = Real(8), the x coordinate
C        y = Real(8), the y coordiante
C
C Output: z, the interpolated value of f(x,y)
C
C Remarks: this version just requires xvec(i)<xvec(i+1) for all i 
C          and yvec(j)<yvec(j+1) for all j
C      

	Real(8) Function BLIP(n,m,xvec,yvec,zmat,x,y)

	use DFLIB

	Integer(4) n, m
	Real(8) xvec(1:n), yvec(1:m), zmat(1:n,1:m), x, y

	Integer(4) i, j
	Real(8)  t, u

C Check for invalid input
	if ((x.lt.xvec(1)) .or. (x.gt.xvec(n))) then
		Call MyMessage("x outside of grid! Program stops","BLIP")
		stop
	endif
	if ((y.lt.yvec(1)) .or. (y.gt.yvec(m))) then
		Call MyMessage("y outside of grid! Program stops","BLIP")
		stop
	endif

C Locate the square that surrounds (x,y)
	i=count(xvec.le.x)
	j=count(yvec.le.y)

C	i=floor((x-xvec(1))/(xvec(2)-xvec(1)))+1 ! older version for equally spaced points
C	j=floor((y-yvec(1))/(yvec(2)-yvec(1)))+1 ! older version for equally spaced points

C Determine return value

	if ((i.eq.n) .and. (j.eq.m)) then
		BLIP=zmat(n,m)
		Return
	elseif ((i.eq.n) .and. (j.lt.m)) then
		u=(y-yvec(j))/(yvec(j+1)-yvec(j))
		BLIP=(1.d0-u)*zmat(n,j)+u*zmat(n,j+1)
		Return
	elseif ((i.lt.n) .and. (j.eq.m)) then
		t=(x-xvec(i))/(xvec(i+1)-xvec(i))
		BLIP=t*zmat(i+1,m)+(1.d0-t)*zmat(i,m)
		Return
	else
		t=(x-xvec(i))/(xvec(i+1)-xvec(i))
		u=(y-yvec(j))/(yvec(j+1)-yvec(j))
		BLIP=(1.d0-t)*(1.d0-u)*zmat(i,j)+t*(1.d0-u)*zmat(i+1,j)+t*u*zmat(i+1,j+1)+(1.d0-t)*u*zmat(i,j+1)
	endif

	Return

	End Function

C Cheb(p,x) : Returns the p-th degree of a Chebyshev-polynomial, x^p, x must be in [-1,1]
C             T_(p=0)=1,, T_(p=1)=x, T_(p=2)=2*x*T_(p=1)-T_(p=0) is and so forth

      Real(8) Function Cheb(p,x)

	Integer(4) p
	Real(8) x

	Integer(4) i
	Real(8)  x0,x1,x2


      Select Case(p)

        Case(0)
	     Cheb=1.0d0
	     Return

	  Case(1)
	     Cheb=x
	     Return

        Case(2:)
          x0=1.0	
	    x1=x	          
	    do i=2,p
	       x2=2.*x*x1-x0
	       x0=x1
		   x1=x2	       
          End Do	
	    Cheb=x2
      End Select

	Return

	End Function

C**********************************************************************************************
C
C Mon(p,x): returns the p-th degree monomial x**p
C
	Real(8) Function Mon(p,x)

	Integer(4) p
	Real(8) x

	Integer(4) i

	Select Case(p)

		Case(0)
			Mon=1.0d0
			Return

		Case(1)
			Mon=x
			Return
		
		Case(2:)
			Mon=x
			do i=2,p
				Mon=Mon*x
			End Do
			Return

	End Select

	End Function 
C **************************************************************************************************
C ChebEval1
C
C Evaluates a Chebyshev polynomial in one independent variable z
C
C Usage: y=ChebEval1(gvec,degree,z,bounds)
C
C Input: gvec  := Real(8)    degree times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    the point, where the polynomial is to be evaluated
C        bounds:= Real(8)    2 times 1 vector, first element:     lower bound for z,
C                                              second elementrow: upper bound for z
C
C Output:  y   := Real(8)    value of the polynomial at point z
C

      Real(8) Function ChebEval1(gvec,degree,z,bounds)

      Integer(4) degree
	Real(8)  gvec(degree), z, bounds(2)

      Integer(2) i
      Real(8) t0, t1, t2, x
            
      x=((2.0*(z-bounds(1)))/(bounds(2)-bounds(1))) - 1.0 ! Map z into [-1,1]       

      t0=1.0	
	t1=x	
      ChebEval1=0.0
	
      Do i=1,degree,1
            ChebEval1=ChebEval1+gvec(i)*t0
		         t2=2.0*x*t1-t0
				 t0=t1
				 t1=t2	      
      End Do      

	Return
      End Function




C **************************************************************************************************
C ChebEval2
C
C Evaluates complete polynomial in two independent variables
C
C Usage: y=ChebEval2(gvec,ng,z,bounds)
C
C Input: gvec  := Real(8)    ng times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    2 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    2 times 2 matrix, first row: lower/upper bound for z1,
C                                             second row: lower/upper bound for for z2
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval2(gvec,degree,z,bounds)

      Integer(4) degree
	Real(8)  gvec((degree+1)*(degree+2)/2), z(1:2), bounds(1:2,1:2)

      Integer(2) p, i, j, k
      Real(8) t1(1:degree+1), t2(1:degree+1), y, x(1:2)
      
      p=degree+1
      x(1)=((2.0*(z(1)-bounds(1,1)))/(bounds(1,2)-bounds(1,1))) - 1.0 ! Map z1 into [-1,1] 
      x(2)=((2.0*(z(2)-bounds(2,1)))/(bounds(2,2)-bounds(2,1))) - 1.0 ! Map z2 into [-1,1] 

      t1(1)=1.0
	t2(1)=1.0
	t1(2)=x(1)
	t2(2)=x(2)

      Do i=3,p,1
  
       t1(i)=2.0*x(1)*t1(i-1)-t1(i-2)
       t2(i)=2.0*x(2)*t2(i-1)-t2(i-2)
         
      End do

      y=0.0
	k=1
      Do i=1,p,1
         Do j=1,(p+1-i),1
            y=y+gvec(k)*t1(j)*t2(i)
	      k=k+1
         End Do
      End Do
      ChebEval2=y

	Return
      End Function

C **************************************************************************************************
C ChebEval3
C
C Evaluates a product base polynomial in two independent variables
C
C Usage: y=ChebEval3(gvec,degree,z,bounds)
C
C Input: gvec  := Real(8)    ng times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) 2 times  1 vector, degree(1): degree of polynomial in z1
C                                               degree(2): degree of polynomial in z2
C        z     := Real(8)    2 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    2 times 2 matrix, first row: lower/upper bound for z1,
C                                             second row: lower/upper bound for for z2
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval3(gvec,degree,z,bounds)

      Integer(4) degree(2)
	Real(8)  gvec(degree(1)*degree(2)), z(1:2), bounds(1:2,1:2)

      Integer(2) i, j, k
      Real(8) t1(1:degree(1)), t2(1:degree(2)), y, x(1:2)
      
      
      x(1)=((2*(z(1)-bounds(1,1)))/(bounds(1,2)-bounds(1,1))) - 1. ! Map z1 into [-1,1] 
      x(2)=((2*(z(2)-bounds(2,1)))/(bounds(2,2)-bounds(2,1))) - 1. ! Map z2 into [-1,1] 

      t1(1)=1.
	t2(1)=1.
	t1(2)=x(1)
	t2(2)=x(2)

      Do i=3,degree(1),1
  
       t1(i)=2*x(1)*t1(i-1)-t1(i-2)       
         
      End do

	Do i=3,degree(2),1

	  t2(i)=2*x(2)*t2(i-1)-t2(i-2)

	End Do

      y=0
      k=1
      Do i=1,degree(1),1
         Do j=1,degree(2),1
            y=y+gvec(k)*t1(i)*t2(j)	      
	      k=k+1
         End Do
      End Do
      ChebEval3=y

	Return
      End Function

C **************************************************************************************************
C ChebEval4
C
C Evaluates a complete polynomial in three independent variables
C
C Usage: y=ChebEval4(npar,gvec,degree,z,bounds)
C
C Input: npar  := Integer(4) number of elements of gvec
C        gvec  := Real(8)    ng times 1 vector, coefficients of the polynomial
C        degree:= Integer(4) degree of the polynomial
C        z     := Real(8)    3 times 1 vector, point, where the polynomial is to be evaluated
C        bounds:= Real(8)    3 times 2 matrix, first row: lower/upper bound for z1,
C                                              second row: lower/upper bound for for z2
C                                              third row:  lower/upper boudn for z3
C
C Output:  y   := Real(8)    value of the polynomial at point x
C

      Real(8) Function ChebEval4(npar,gvec,degree,z,bounds)

      Integer(4) degree, npar
	Real(8)  gvec(1:npar), z(1:3), bounds(1:3,1:2)

      Integer(2) i, i1, i2, i3, k
      Real(8) tmat(1:degree+1,1:3), y, x(1:3)
            
      x(1)=((2.0d0*(z(1)-bounds(1,1)))/(bounds(1,2)-bounds(1,1))) - 1.0d0 ! Map z1 into [-1,1] 
      x(2)=((2.0d0*(z(2)-bounds(2,1)))/(bounds(2,2)-bounds(2,1))) - 1.0d0 ! Map z2 into [-1,1] 
	x(3)=((2.0d0*(z(3)-bounds(3,1)))/(bounds(3,2)-bounds(3,1))) - 1.0d0 ! Map z3 into [-1,1]

      tmat(1,1:3)=1.0
	tmat(2,1:3)=x(1:3)
	
      Do i=3,degree,1
  
       tmat(i,1)=2.0d0*x(1)*tmat(i-1,1)-tmat(i-2,1)
       tmat(i,2)=2.0d0*x(2)*tmat(i-1,2)-tmat(i-2,2)
	 tmat(i,3)=2.0d0*x(3)*tmat(i-1,3)-tmat(i-2,3)
         
      End do

      y=0.0
	k=1
      Do i1=1,degree,1
         Do i2=1,(degree+1-i1),1
	      Do i3=1,(degree+2-i1-i2),1
               y=y+gvec(k)*tmat(i1,1)*tmat(i2,2)*tmat(i3,3)              
	         k=k+1
            End Do
         End Do
      End Do
      ChebEval4=y

	Return
      End Function


C *****************************************************************************************************
C ChebCoef2a
C
C Compute the coefficients of a two-dimensional product base Chebychev polynomial.
C The formulas used are from Heer/Maussner, equation (8.42)
C
C Usage: Call ChebCoef2a(f,degree,nodes,bounds,avec)
C
C Input:    f pointer to the function that returns y=f(z1(i1),z2(i2))
C        degree, 2 times 1 Integer(4) vector that stores the degree of the first and second variable,
C                          respectively
C        nodes,  2 times 1 Integer(4) vector that stores the number of nodes for the first and second
C                          variable, respectively
C        bounds, 2 times 2 Real(8) matrix, where bounds(1,1) the lower bound of z1,
C                                                bounds(1,2) the upper bound of z1
C                                                bounds(2,1) the lower bound of z2
C                                                bounds(2,2) the upper bound of z2
C
C Output: avec, degree(1)*degree(2) times 1 Real(8) vector, the coefficients of the polynomial
C
      Subroutine ChebCoef2a(f,degree,nodes,bounds,avec)

      use IMSLF90      
      
	Integer(4) degree(2), nodes(2)
	Real(8) f, bounds(2,2), avec(degree(1)*degree(2))

      Integer(4) i, i1, i2, k, j
	Real(8) y(nodes(1),nodes(2)), x1(nodes(1)), x2(nodes(2)), z1(nodes(1)), z2(nodes(2))
	Real(8) gvec(degree(1),degree(2))
	Real(8) dconst, pi, Cheb

	External f, dconst, Cheb

C Compute Chebyshev nodes
      pi=dconst('pi')

      Do i=1,nodes(1)
	   x1(i)=dcos(((2.*i - 1.)/(2.*dble(nodes(1))))*pi)            !zero of the n-th degree Chebyshev polynomila for x1
	   z1(i)=(x1(i)+1.)*(bounds(1,2)-bounds(1,1))*0.5+bounds(1,1)  !mapped into the interval on which z1 is defined
	End Do      

      Do i=1,nodes(2)
	   x2(i)=dcos(((2.*i - 1.)/(2.*dble(nodes(2))))*pi)           ! zero of the n-th degree Chebyshev polynomila for x2
	   z2(i)=(x2(i)+1.)*(bounds(2,2)-bounds(2,1))*0.5+bounds(2,1) ! mapped into the interval on which z2 is defined
	End Do      

C Evaluate y      
      Do i1=1,nodes(1)
	   Do i2=1,nodes(2)
            y(i1,i2)=f(z1(i1),z2(i2))
	   End Do
	End Do

C Compute coefficients according to formula (8.42)
      gvec(1,1)=sum(y)/dble(nodes(1)*nodes(2))
      Do i=2,degree(2)
	    gvec(1,i)=0.0
	    Do i1=1,nodes(1)
	       Do i2=1,nodes(2)
	          gvec(1,i)=gvec(1,i)+y(i1,i2)*Cheb(i-1,x2(i2))
	       End Do
	    End Do
	    gvec(1,i)=2.*gvec(1,i)/dble(nodes(1)*nodes(2))
	End Do

	Do i=2,degree(1)
	   gvec(i,1)=0.0
	   Do i1=1,nodes(1)
	      Do i2=1,nodes(2)
	         gvec(i,1)=gvec(i,1)+y(i1,i2)*Cheb(i-1,x1(i1))
	      End Do
	   End Do
	   gvec(i,1)=2.*gvec(i,1)/dble(nodes(1)*nodes(2))
	End Do

	Do i=2,degree(1)
	   Do j=2,degree(2)
	      gvec(i,j)=0.0
	      Do i1=1,nodes(1)
	         Do i2=1,nodes(2)
	            gvec(i,j)=gvec(i,j)+y(i1,i2)*Cheb(i-1,x1(i1))*Cheb(j-1,x2(i2))
	         End Do
	      End Do
	      gvec(i,j)=4.*gvec(i,j)/dble(nodes(1)*nodes(2))
         End do
	End Do

C Reshape gvec to avec
      k=1
	Do i=1,degree(1)
	   do j=1,degree(2)
	      avec(k)=gvec(i,j)
	      k=k+1
	   end do
	End Do

	Return

	End Subroutine

C *****************************************************************************************************
C ChebCoef2b
C
C Compute the coefficients of a two-dimensional complete Chebychev polynomial.
C The formula is adapted from Heer/Maussner equation (8.42) to the case of 4
C
C Usage: Call ChebCoef2b(f,degree,nodes,bounds,na,avec)
C
C Input:    f pointer to the function that returns y=f(z1(i1),z2(i2),z3(i3),z4(i4))
C        degree, Integer(4), degree of the polynomial
C        nodes,  Integer(4), the number of nodes for both variables
C        bounds, 2 times 2 Real(8) matrix, where bounds(1,1) the lower bound of z1,
C                                                bounds(1,2) the upper bound of z1
C
C Output: avec, na times 1 Real(8) vector, the coefficients of the polynomial
C
C Note: - the user is responsible for computing na
C       - degree=0 is the constant polynomial (not degree=1 as in some other programs)

      Subroutine ChebCoef2b(f,degree,nodes,bounds,na,avec)

      use IMSLF90      
      
	Integer(4) degree, nodes, na
	Real(8) f, bounds(2,2), avec(na)

      Integer(4) j1, j2, k1, k2, i, j	
	Real(8) x(nodes), z(nodes,2), m(2), sum	
	Real(8) dconst, pi, Cheb

	External f, dconst, Cheb

C Compute Chebyshev nodes
      pi=dconst('pi')

      Do i=1,nodes
	   x(i)=dcos(((2.0d0*i - 1.0d0)/(2.0d0*dble(nodes)))*pi)  !zero of the n-th degree Chebyshev polynomila for x
	   Do j=1,2
	    z(i,j)=(x(i)+1.0d0)*(bounds(j,2)-bounds(j,1))*0.5d0+bounds(j,1) !mapped into the interval on which z1 is defined
	   End Do      
	End Do

C Compute coefficients
      j=0
	Do j1=0,degree,1
	    m(1)=2.0d0/dble(nodes)
	    if (j1.eq.0) m(1)=1.0d0/dble(nodes)
		Do j2=0,degree-j1
			m(2)=2.0d0/dble(nodes)
			if (j2.eq.0) m(2)=1.0d0/dble(nodes)
			j=j+1
	        sum=0.0
			Do k1=1,nodes,1
				Do k2=1,nodes,1
					sum=sum+f(z(k1,1),z(k2,2))*Cheb(j1,x(k1))*Cheb(j2,x(k2))
				End Do
			End Do
			avec(j)=m(1)*m(2)*sum
		End Do
	End Do
	
	Return

	End Subroutine


C *****************************************************************************************************
C ChebCoef3
C
C Compute the coefficients of a three-dimensional complete Chebychev polynomial.
C The formula is adapted from Heer/Maussner equation (8.42) to the case of 3
C
C Usage: Call ChebCoef3(f,degree,nodes,bounds,na,avec)
C
C Input:        f pointer to the function that returns y=f(z1(i1),z2(i2),z3(i3))
C         degree, Integer(4), degree of the polynomial
C          nodes, Integer(4), the number of nodes for all 3 variables
C         bounds, 3 times 2 Real(8) matrix, where bounds(1,1) the lower bound of z1,
C                                                bounds(1,2) the upper bound of z1
C                                          and so forth
C
C Output: avec, na times 1 Real(8) vector, the coefficients of the polynomial
C
C Notes: - the user is responsible for computing na
C        - degree=0 is the constant polynomial (not degree=1 as in some other programs)
C
      Subroutine ChebCoef3(f,degree,nodes,bounds,na,avec)

      use IMSLF90      
      
	Integer(4) degree, nodes, na
	Real(8) f, bounds(1:3,1:2), avec(1:na)

      Integer(4) j1, j2, j3, k1, k2, k3, i, j	
	Real(8) x(1:nodes), z(1:nodes,1:3), m(1:3), sum	
	Real(8) dconst, pi, Cheb

	External f, dconst, Cheb

C Compute Chebyshev nodes
      pi=dconst('pi')

      Do i=1,nodes
		x(i)=dcos(((2.0d0*i - 1.0d0)/(2.0d0*dble(nodes)))*pi)               !zero of the n-th degree Chebyshev polynomila for x
		Do j=1,3
			z(i,j)=(x(i)+1.0d0)*(bounds(j,2)-bounds(j,1))*0.5d0+bounds(j,1) !mapped into the interval on which z1 is defined
		End Do      
	End Do

C Compute coefficients
      j=0
	Do j1=0,degree,1
		m(1)=2./dble(nodes)
		if (j1.eq.0) m(1)=1./dble(nodes)
		Do j2=0,degree-j1
			m(2)=2./dble(nodes)
			if (j2.eq.0) m(2)=1./dble(nodes)
			Do j3=0,degree-j1-j2
				m(3)=2./dble(nodes)
				if(j3.eq.0) m(3)=1./dble(nodes)
				j=j+1
				sum=0.0
				Do k1=1,nodes
					Do k2=1,nodes
						Do k3=1,nodes
							sum=sum+f(z(k1,1),z(k2,2),z(k3,3))*Cheb(j1,x(k1))*Cheb(j2,x(k2))*Cheb(j3,x(k3))
						End Do
					End Do
				End Do					
				avec(j)=m(1)*m(2)*m(3)*sum
			End Do
		End Do
	End Do	
      
	Return

	End Subroutine

