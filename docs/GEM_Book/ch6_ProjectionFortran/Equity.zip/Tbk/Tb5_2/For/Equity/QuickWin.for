C QuickWin:
C
C Here we collected a few procedures that
C are useful when dealing with QuickWin programs

C InitialSettings
C
C Changes the appearance of the Quick Windows
C program window

      LOGICAL(4) FUNCTION INITIALSETTINGS( )

        USE DFLIB     
        INTEGER  RetI

        TYPE (qwinfo) qwi

  
C Window Size
        qwi.x = 25
        qwi.y = 25
        qwi.w = 900
        qwi.h = 600
        qwi.type = QWIN$SET
        RetI = SetWSizeQQ( QWIN$FRAMEWINDOW, qwi )

        INITIALSETTINGS= .true.
      END FUNCTION INITIALSETTINGS
      

C MakeSmallWindow(F, Name)
C
C Purpose: Opens a new window with handle F and title
C          Name.     
	Subroutine MakeSmallWindow(F,Name,dx)
	
	Use DFLIB

	Integer(2) RDI2
	Integer(4) RDI4, F
	Logical(4) RDL, dx
	Character*(*) Name

	TYPE (windowconfig) thiswin
	TYPE (qwinfo) thiswinsize

c Define the window
	open(F,file='User',title=Name)

c Change the size of the window
      RDI4=GETWSIZEQQ(F, QWIN$SIZECURR, thisWinSize)
	thisWinSize.x=5
	thisWinSize.y=5
	thisWinSize.h=thisWinSize.h+dx
	thisWinSize.w=thisWinSize.w+dx
      thisWinSize.type=QWIN$SET
	RDI4=SETWSIZEQQ(F, thisWinSize) 
	  
c Change the window's text font size
	RDL=GetWindowConfig(thiswin)
	thiswin.numxpixels=-1
	thiswin.numypixels=-1
	thiswin.numtextrows=-1
	thiswin.numtextcols=-1
	thiswin.numColors=-1
      thisWin.fontsize=int4(1.25*thiswin.fontsize)
	RDL=SetWindowConfig(thiswin)

c Change the window's background color to grey
	RDI4=SETBKCOLOR (7) 
	RDI2=SETTEXTCOLOR(0)
	CALL ClearScreen($GCLEARSCREEN)

	Return

	End Subroutine
