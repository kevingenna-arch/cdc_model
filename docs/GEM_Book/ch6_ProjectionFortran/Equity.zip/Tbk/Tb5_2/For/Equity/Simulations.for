C****************************************************************************************
C
C Impulse: Compute the impulse repsonse to a one-time productivity shock in period t=2
	Subroutine Impulse(nobs1)

	use Def_Par
	use Def_Proj
	use Errors

	Integer(4) nobs1
	
	Integer(4) t, i
	Real(8) qt(1:nobs1), kt(1:nobs1+1), it(1:nobs1), ct(1:nobs1), yt(1:nobs1), zt(1:nobs1+1)
	Real(8) Psi1, Inv, Phi	

	kt(1)=kstar
	kt(2)=kstar
	qt(1)=qstar
	ct(1)=cstar
	zt(1)=0.0d0
	zt(2)=sigma

	FError=0

	Do t=2,nobs1,1
	
		qt(t)=Psi1(gvec1,kt(t),ct(t-1),dexp(zt(t)))
		if (FError.ne.0) exit
		it(t)=Inv(qt(t),kt(t))
		yt(t)=dexp(zt(t))*(kt(t)**alpha)
		ct(t)=yt(t)-it(t)
		kt(t+1)=phi(it(t)/kt(t))*kt(t)+(1.0d0-delta)*kt(t)
		zt(t+1)=rho*zt(t)
		
	End Do

	open(14,file='Impulse.txt')
	Do i=1,t-1,1
		write(14,"('t= ',I4,2X,'kt(t)/kstar= ',F10.4,' ct(t)/cstar= ',F10.4,' zt(t)= ',F10.4)")
     +		i, (kt(i)/kstar), (ct(i)/cstar), dexp(zt(i))
	End Do

	close(14)

	Return

	End Subroutine

C**************************************************************************************************
C Simulate: Simulates the model and returns the rates of return

      Subroutine Simulate()

      use DFLIB
      use Def_Par
	use Def_Proj
	use Def_GH6
	use Errors
	
	Integer(4) t, j, s, fh
	Integer(2) row
      Real(8), allocatable :: eps(:,:), qt(:), ct(:), yt(:), it(:), kt(:), zt(:), lt(:), rt(:,:)
	Real(8) rs(1:3)
	Real(8) hpl, i2, z2, q2, c2, l2, temp, rhs, pi
	Real(8) Psi1, Psi2, Inv, Phi, StDev
	Logical new_shocks, ok

      Type (rccoord) curpos		

	Call GetL('new_shocks','Parameters.txt',new_shocks)
	Call GetI('nobs','Parameters.txt',nobs)
	Call GetI('nofs','Parameters.txt',nofs)

	allocate(eps(1:nobs+1,1:nofs),qt(1:nobs), ct(1:nobs), yt(1:nobs), lt(1:nobs), kt(1:nobs+1), zt(1:nobs+1))
	allocate(it(1:nobs), rt(1:nobs,1:3))
	

      HPL=1600.0d0 ! Filter weight for HP-filter
	temp=2.0d0
	sy=0.0d0

	If (new_shocks) then
		j=nobs+1
		Do t=1,nofs
			CALL DRNNOR(j, eps(1:j,t))
		enddo
		open (25,file='Eps.bin',form='unformatted')
		write(25) eps
		close(25)
	else
	    inquire(file='eps.bin',exist=ok)			
		if (.not. ok) then
			Call MyMessage("File eps.bin does not exist. Program terminates","Simulation Erorr")
				stop
		endif
		open(25,file='eps.bin',form='unformatted')
		read(25,err=1, iostat=j) eps
1		if (j.ne.0) then
			Call MyMessage('Not enough records to read. Restart the program and set new_shocks=.true.','Simulation Error')
			stop
		endif
		close(25)		
	endif

      
	fh=GetActiveQQ()
	Call GetTextPosition(curpos)
	CALL SETTEXTPOSITION(curpos.row+1,1,curpos)	
	WRITE(fh,*) 'Compute Rates of Return'
	Call GetTextPosition(curpos)	
	row=curpos.row
	
	invalid=0

	xminmax(1,1)=5*kstar
	xminmax(1,2)=0.0d0
	xminmax(2,1)=5*cstar
	xminmax(2,2)=0.0d0
	xminmax(3,1)=1.0d0
	xminmax(3,2)=0.0d0
	xminmax(4,1)=2.0d0
	xminmax(4,2)=0.0d0

	Lsec(2)=RTC()

	Do s=1,nofs      
		FError=0
		kt=0.0d0
		ct=0.0d0
		it=0.0d0
		yt=0.0d0
		lt=0.0d0
		qt=0.0d0
		zt=0.0d0
		qt(1)=qstar  ! in the first period the economy is the steady state
		kt(1)=kstar
		kt(2)=kstar
		ct(1)=cstar
		it(1)=istar
		zt(1)=0.0d0
		zt(2)=sigma*eps(2,s)
		yt(1)=ystar
		lt(1)=(1-beta*b)*(((1-b)*cstar)**(-eta))
     
		Do t=2,nobs	   
			qt(t)=Psi1(gvec1,kt(t),ct(t-1),dexp(zt(t)))
			if (FError.ne.0) then
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 2
			endif
              it(t)=Inv(qt(t),kt(t))
			yt(t)=dexp(zt(t))*(kt(t)**alpha)
			ct(t)=yt(t)-it(t)			
			if ((ct(t).lt.dexp(psi_bounds(2,1))) .or. (ct(t).gt.dexp(psi_bounds(2,2)))) then
				FError=2
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 2
			endif
			rhs=it(t)/kt(t)
			kt(t+1)=Phi(rhs)*kt(t)+(1.0d0-delta)*kt(t)
			zt(t+1)=rho*zt(t)+sigma*eps(t+1,s)
		    rhs=Psi2(gvec2,kt(t),ct(t-1),dexp(zt(t)))
			if (FError.ne.0) then
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 2
			endif
			lt(t)=((ct(t)-b*ct(t-1))**(-eta))-beta*b*rhs
			if (lt(t).lt.0.0d0) then
				FError=6
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 2
			endif
			rhs=0.0d0
			Do j=1,6,1 ! Gauss-Hermite integration to determine E_t (lt(t+1))
				z2=rho*zt(t)+dsqrt(temp)*sigma*ghx(j)
				q2=Psi1(gvec1,kt(t+1),ct(t),dexp(z2))
				if (FError.ne.0) then
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 2
				endif				
				i2=Inv(q2,kt(t+1))
				c2=dexp(z2)*(kt(t+1)**alpha)-i2	      
				if ((c2.lt.dexp(psi_bounds(2,1))) .or. (c2.gt.dexp(psi_bounds(2,2)))) then
					FError=2
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 2
				endif
				l2=Psi2(gvec2,kt(t+1),ct(t),dexp(z2))
				l2=((c2-b*ct(t))**(-eta))-beta*b*l2
				if (l2.lt.0.0d0) then
					FError=6
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 2
				endif
				rhs=rhs+ghw(j)*l2	      
			end do
			rhs=rhs/dsqrt(pi())
			rt(t,1)=lt(t)/(beta*rhs)
			rt(t,1)=rt(t,1)-1.0d0
		End Do
		Do t=2,nobs-1,1 ! compute the return on equity
			rt(t,2)=(alpha*yt(t+1)-it(t+1)+qt(t+1)*kt(t+2))/(qt(t)*kt(t+1))
			rt(t,2)=rt(t,2)-1.0d0
			rt(t,3)=rt(t,2)-rt(t,1)
		End Do
		j=nobs+1
		Call DSORTQ("a",j,kt,1)
		if (xminmax(1,1).gt.kt(1)) xminmax(1,1)=kt(1)
		if (xminmax(1,2).lt.kt(j)) xminmax(1,2)=kt(j)
		j=nobs
		Call DSORTQ("a",j,ct,1)
		if (xminmax(2,1).gt.ct(1)) xminmax(2,1)=ct(1)
		if (xminmax(2,2).lt.ct(j)) xminmax(2,2)=ct(j)
		j=nobs+1
		Call DSORTQ("a",j,zt,1)
		if (xminmax(3,1).gt.dexp(zt(1))) xminmax(3,1)=dexp(zt(1))
		if (xminmax(3,2).lt.dexp(zt(j))) xminmax(3,2)=dexp(zt(j))
		j=nobs
		Call DSORTQ("a",j,qt,1)
		if (xminmax(4,1).gt.qt(1)) xminmax(4,1)=qt(1)
		if (xminmax(4,2).lt.qt(j)) xminmax(4,2)=qt(j)
	
		Do j=1,3,1			
			rs(j)=sum(rt(2:nobs-1,j))/dble(nobs-2)
			rss(j)=rss(j)+rs(j)
		End Do
	
		CALL HPFilter(nobs,dlog(it),HPL,it)
		sy(3)=sy(3)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(yt),HPL,it)
		sy(1)=sy(1)+StDev(nobs,it)
	    CALL HPFilter(nobs,dlog(ct),HPL,it)
		sy(2)=sy(2)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(kt(1:nobs)),HPL,it)
		sy(4)=sy(4)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(lt),HPL,it)
		sy(5)=sy(5)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(qt),HPL,it)
		sy(6)=sy(6)+StDev(nobs,it)

2         continue
     
      End Do

	if (invalid.lt.nofs) then
		Do j=1,3,1
			rss(j)=rss(j)/dble(nofs-invalid)	
		End Do
		Do j=1,6,1
			sy(j)=sy(j)/dble(nofs-invalid)
		End Do
	endif

	Lsec(2)=RTC()-Lsec(2)

	Return
	
	End Subroutine  

C Simulate: Simulates the model and returns the rates of return.
C           Different from Simulate, this version uses the linear policy functions

      Subroutine Simulate1()

      use DFLIB
      use Def_Par
	use Def_Proj
	use Def_GH6
	use Errors
	
	Integer(4) t, j, s, fh
	Integer(2) row
      Real(8), allocatable :: eps(:,:), qt(:), ct(:), yt(:), it(:), kt(:), zt(:), lt(:), rt(:,:)
	Real(8) rs(1:3)
	Real(8) hpl, i2, z2, q2, c2, l2, temp, rhs, pi
	Real(8) Inv, Phi, StDev, PolicyLA
	Logical new_shocks, ok

      Type (rccoord) curpos		

	Call GetL('new_shocks','Parameters.txt',new_shocks)
	Call GetI('nobs','Parameters.txt',nobs)
	Call GetI('nofs','Parameters.txt',nofs)

	allocate(eps(1:nobs+1,1:nofs),qt(1:nobs), ct(1:nobs), yt(1:nobs), lt(1:nobs), kt(1:nobs+1), zt(1:nobs+1))
	allocate(it(1:nobs), rt(1:nobs,1:3))
	

      HPL=1600.0d0 ! Filter weight for HP-filter
	temp=2.0d0
	sy=0.0d0

	If (new_shocks) then
		j=nobs+1
		Do t=1,nofs
			CALL DRNNOR(j, eps(1:j,t))
		enddo
		open (25,file='Eps.bin',form='unformatted')
		write(25) eps
		close(25)
	else
	    inquire(file='eps.bin',exist=ok)			
		if (.not. ok) then
			Call MyMessage("File eps.bin does not exist. Program terminates","Simulation Erorr")
				stop
		endif
		open(25,file='eps.bin',form='unformatted')
		read(25,err=3, iostat=j) eps
3		if (j.ne.0) then
			Call MyMessage('Not enough records to read. Restart the program and set new_shocks=.true.','Simulation Error')
			stop
		endif
		close(25)		
	endif

      
	fh=GetActiveQQ()
	Call GetTextPosition(curpos)
	CALL SETTEXTPOSITION(curpos.row+1,1,curpos)	
	WRITE(fh,*) 'Compute Rates of Return'
	Call GetTextPosition(curpos)	
	row=curpos.row
	
	invalid=0

	xminmax(1,1)=5*kstar
	xminmax(1,2)=0.0d0
	xminmax(2,1)=5*cstar
	xminmax(2,2)=0.0d0
	xminmax(3,1)=1.0d0
	xminmax(3,2)=0.0d0
	xminmax(4,1)=2.0d0
	xminmax(4,2)=0.0d0

	Lsec(2)=RTC()

	Do s=1,nofs      
		FError=0
		kt=0.0d0
		ct=0.0d0
		it=0.0d0
		yt=0.0d0
		lt=0.0d0
		qt=0.0d0
		zt=0.0d0
		qt(1)=qstar  ! in the first period the economy is the steady state
		kt(1)=kstar
		kt(2)=kstar
		ct(1)=cstar
		it(1)=istar
		zt(1)=0.0d0
		zt(2)=sigma*eps(2,s)
		yt(1)=ystar
		lt(1)=(1-beta*b)*(((1-b)*cstar)**(-eta))
     
		Do t=2,nobs	   
			qt(t)=PolicyLA('q',kt(t),ct(t-1),dexp(zt(t)))
			if (qt(t).lt.0.0d0) then
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 4
			endif
              it(t)=Inv(qt(t),kt(t))
			yt(t)=dexp(zt(t))*(kt(t)**alpha)
			ct(t)=yt(t)-it(t)			
			if (ct(t).lt.0.0d0) then
				FError=2
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 4
			endif
			rhs=it(t)/kt(t)
			kt(t+1)=Phi(rhs)*kt(t)+(1.0d0-delta)*kt(t)
			zt(t+1)=rho*zt(t)+sigma*eps(t+1,s)		    
			lt(t)=PolicyLA('l',kt(t),ct(t-1),dexp(zt(t)))
			if (lt(t).lt.0.0d0) then
				FError=6
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 4
			endif
			rhs=0.0d0
			Do j=1,6,1 ! Gauss-Hermite integration to determine E_t (lt(t+1))
				z2=rho*zt(t)+dsqrt(temp)*sigma*ghx(j)
				q2=PolicyLA('q',kt(t+1),ct(t),dexp(z2))
				if (q2.lt.0.0d0) then
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 4
				endif				
				i2=Inv(q2,kt(t+1))
				c2=dexp(z2)*(kt(t+1)**alpha)-i2	      
				if (c2.lt.0.0d0) then
					FError=2
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 4
				endif
				l2=PolicyLA('l',kt(t+1),ct(t),dexp(z2))				
				if (l2.lt.0.0d0) then
					FError=6
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 4
				endif
				rhs=rhs+ghw(j)*l2	      
			end do
			rhs=rhs/dsqrt(pi())
			rt(t,1)=lt(t)/(beta*rhs)
			rt(t,1)=rt(t,1)-1.0d0
		End Do
		Do t=2,nobs-1,1 ! compute the return on equity
			rt(t,2)=(alpha*yt(t+1)-it(t+1)+qt(t+1)*kt(t+2))/(qt(t)*kt(t+1))
			rt(t,2)=rt(t,2)-1.0d0
			rt(t,3)=rt(t,2)-rt(t,1)
		End Do
		j=nobs+1
		Call DSORTQ("a",j,kt,1)
		if (xminmax(1,1).gt.kt(1)) xminmax(1,1)=kt(1)
		if (xminmax(1,2).lt.kt(j)) xminmax(1,2)=kt(j)
		j=nobs
		Call DSORTQ("a",j,ct,1)
		if (xminmax(2,1).gt.ct(1)) xminmax(2,1)=ct(1)
		if (xminmax(2,2).lt.ct(j)) xminmax(2,2)=ct(j)
		j=nobs+1
		Call DSORTQ("a",j,zt,1)
		if (xminmax(3,1).gt.dexp(zt(1))) xminmax(3,1)=dexp(zt(1))
		if (xminmax(3,2).lt.dexp(zt(j))) xminmax(3,2)=dexp(zt(j))
		j=nobs
		Call DSORTQ("a",j,qt,1)
		if (xminmax(4,1).gt.qt(1)) xminmax(4,1)=qt(1)
		if (xminmax(4,2).lt.qt(j)) xminmax(4,2)=qt(j)
	
		Do j=1,3,1			
			rs(j)=sum(rt(2:nobs-1,j))/dble(nobs-2)
			rss(j)=rss(j)+rs(j)
		End Do
	
		CALL HPFilter(nobs,dlog(it),HPL,it)
		sy(3)=sy(3)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(yt),HPL,it)
		sy(1)=sy(1)+StDev(nobs,it)
	    CALL HPFilter(nobs,dlog(ct),HPL,it)
		sy(2)=sy(2)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(kt(1:nobs)),HPL,it)
		sy(4)=sy(4)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(lt),HPL,it)
		sy(5)=sy(5)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(qt),HPL,it)
		sy(6)=sy(6)+StDev(nobs,it)

4         continue
     
      End Do

	if (invalid.lt.nofs) then
		Do j=1,3,1
			rss(j)=rss(j)/dble(nofs-invalid)	
		End Do
		Do j=1,6,1
			sy(j)=sy(j)/dble(nofs-invalid)
		End Do
	endif

	Lsec(2)=RTC()-Lsec(2)

	Return
	
	End Subroutine  


C Simulate: Simulates the model and returns the rates of return.
C           Different from Simulate1, this version uses the quadratic policy functions

      Subroutine Simulate2()

      use DFLIB
      use Def_Par
	use Def_Proj
	use Def_GH6
	use Errors
	
	Integer(4) t, j, s, fh
	Integer(2) row
      Real(8), allocatable :: eps(:,:), qt(:), ct(:), yt(:), it(:), kt(:), zt(:), lt(:), rt(:,:)
	Real(8) rs(1:3)
	Real(8) hpl, i2, z2, q2, c2, l2, temp, rhs, pi
	Real(8) Inv, Phi, StDev, PolicyQA
	Logical new_shocks, ok

      Type (rccoord) curpos		

	Call GetL('new_shocks','Parameters.txt',new_shocks)
	Call GetI('nobs','Parameters.txt',nobs)
	Call GetI('nofs','Parameters.txt',nofs)

	allocate(eps(1:nobs+1,1:nofs),qt(1:nobs), ct(1:nobs), yt(1:nobs), lt(1:nobs), kt(1:nobs+1), zt(1:nobs+1))
	allocate(it(1:nobs), rt(1:nobs,1:3))
	

      HPL=1600.0d0 ! Filter weight for HP-filter
	temp=2.0d0
	sy=0.0d0

	If (new_shocks) then
		j=nobs+1
		Do t=1,nofs
			CALL DRNNOR(j, eps(1:j,t))
		enddo
		open (25,file='Eps.bin',form='unformatted')
		write(25) eps
		close(25)
	else
	    inquire(file='eps.bin',exist=ok)			
		if (.not. ok) then
			Call MyMessage("File eps.bin does not exist. Program terminates","Simulation Erorr")
				stop
		endif
		open(25,file='eps.bin',form='unformatted')
		read(25,err=5, iostat=j) eps
5		if (j.ne.0) then
			Call MyMessage('Not enough records to read. Restart the program and set new_shocks=.true.','Simulation Error')
			stop
		endif
		close(25)		
	endif

      
	fh=GetActiveQQ()
	Call GetTextPosition(curpos)
	CALL SETTEXTPOSITION(curpos.row+1,1,curpos)	
	WRITE(fh,*) 'Compute Rates of Return'
	Call GetTextPosition(curpos)	
	row=curpos.row
	
	invalid=0

	xminmax(1,1)=5*kstar
	xminmax(1,2)=0.0d0
	xminmax(2,1)=5*cstar
	xminmax(2,2)=0.0d0
	xminmax(3,1)=1.0d0
	xminmax(3,2)=0.0d0
	xminmax(4,1)=2.0d0
	xminmax(4,2)=0.0d0

	Lsec(2)=RTC()

	Do s=1,nofs      
		FError=0
		kt=0.0d0
		ct=0.0d0
		it=0.0d0
		yt=0.0d0
		lt=0.0d0
		qt=0.0d0
		zt=0.0d0
		qt(1)=qstar  ! in the first period the economy is the steady state
		kt(1)=kstar
		kt(2)=kstar
		ct(1)=cstar
		it(1)=istar
		zt(1)=0.0d0
		zt(2)=sigma*eps(2,s)
		yt(1)=ystar
		lt(1)=(1-beta*b)*(((1-b)*cstar)**(-eta))
     
		Do t=2,nobs	   
			qt(t)=PolicyQA('q',kt(t),ct(t-1),dexp(zt(t)))
			if (qt(t).lt.0.0d0) then
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 6
			endif
              it(t)=Inv(qt(t),kt(t))
			yt(t)=dexp(zt(t))*(kt(t)**alpha)
			ct(t)=yt(t)-it(t)			
			if (ct(t).lt.0.0d0) then
				FError=2
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 6
			endif
			rhs=it(t)/kt(t)
			kt(t+1)=Phi(rhs)*kt(t)+(1.0d0-delta)*kt(t)
			zt(t+1)=rho*zt(t)+sigma*eps(t+1,s)		    
			lt(t)=PolicyQA('l',kt(t),ct(t-1),dexp(zt(t)))
			if (lt(t).lt.0.0d0) then
				FError=6
				write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
				invalid=invalid+1
				goto 6
			endif
			rhs=0.0d0
			Do j=1,6,1 ! Gauss-Hermite integration to determine E_t (lt(t+1))
				z2=rho*zt(t)+dsqrt(temp)*sigma*ghx(j)
				q2=PolicyQA('q',kt(t+1),ct(t),dexp(z2))
				if (q2.lt.0.0d0) then
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 6
				endif				
				i2=Inv(q2,kt(t+1))
				c2=dexp(z2)*(kt(t+1)**alpha)-i2	      
				if (c2.lt.0.0d0) then
					FError=2
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 6
				endif
				l2=PolicyQA('l',kt(t+1),ct(t),dexp(z2))				
				if (l2.lt.0.0d0) then
					FError=6
					write(lfh,"('s= ',I7,' t= ',I7,'Ferror= ',I1)") s, t, Ferror
					invalid=invalid+1
					goto 6
				endif
				rhs=rhs+ghw(j)*l2	      
			end do
			rhs=rhs/dsqrt(pi())
			rt(t,1)=lt(t)/(beta*rhs)
			rt(t,1)=rt(t,1)-1.0d0
		End Do
		Do t=2,nobs-1,1 ! compute the return on equity
			rt(t,2)=(alpha*yt(t+1)-it(t+1)+qt(t+1)*kt(t+2))/(qt(t)*kt(t+1))
			rt(t,2)=rt(t,2)-1.0d0
			rt(t,3)=rt(t,2)-rt(t,1)
		End Do
		j=nobs+1
		Call DSORTQ("a",j,kt,1)
		if (xminmax(1,1).gt.kt(1)) xminmax(1,1)=kt(1)
		if (xminmax(1,2).lt.kt(j)) xminmax(1,2)=kt(j)
		j=nobs
		Call DSORTQ("a",j,ct,1)
		if (xminmax(2,1).gt.ct(1)) xminmax(2,1)=ct(1)
		if (xminmax(2,2).lt.ct(j)) xminmax(2,2)=ct(j)
		j=nobs+1
		Call DSORTQ("a",j,zt,1)
		if (xminmax(3,1).gt.dexp(zt(1))) xminmax(3,1)=dexp(zt(1))
		if (xminmax(3,2).lt.dexp(zt(j))) xminmax(3,2)=dexp(zt(j))
		j=nobs
		Call DSORTQ("a",j,qt,1)
		if (xminmax(4,1).gt.qt(1)) xminmax(4,1)=qt(1)
		if (xminmax(4,2).lt.qt(j)) xminmax(4,2)=qt(j)
	
		Do j=1,3,1			
			rs(j)=sum(rt(2:nobs-1,j))/dble(nobs-2)
			rss(j)=rss(j)+rs(j)
		End Do
	
		CALL HPFilter(nobs,dlog(it),HPL,it)
		sy(3)=sy(3)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(yt),HPL,it)
		sy(1)=sy(1)+StDev(nobs,it)
	    CALL HPFilter(nobs,dlog(ct),HPL,it)
		sy(2)=sy(2)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(kt(1:nobs)),HPL,it)
		sy(4)=sy(4)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(lt),HPL,it)
		sy(5)=sy(5)+StDev(nobs,it)
		CALL HPFilter(nobs,dlog(qt),HPL,it)
		sy(6)=sy(6)+StDev(nobs,it)

6         continue
     
      End Do

	if (invalid.lt.nofs) then
		Do j=1,3,1
			rss(j)=rss(j)/dble(nofs-invalid)	
		End Do
		Do j=1,6,1
			sy(j)=sy(j)/dble(nofs-invalid)
		End Do
	endif

	Lsec(2)=RTC()-Lsec(2)

	Return
	
	End Subroutine  


