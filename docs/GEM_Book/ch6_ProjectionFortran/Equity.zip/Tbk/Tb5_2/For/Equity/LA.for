C LA
C
C Purpose: Compute the linear approximate policy functions  of the equity premium puzzle model


      Subroutine LA

	use Def_Par
	use Def_LA
	use Errors
	use DFLIB

      Integer(4) nx, nc, nl, ns, t, i, j, fh, ngrid, nz
	
      Real(8) Cu(2,2), Cxl(2,4), Cz(1:2), Dxl(4,4), Fxl(4,4), Du(4,2),Fu(4,2), Dz(4), Fz(4), temp
      Real(8) gmat(1:6,1:14), xstar(1:14)	

	External Sys_LA

      TYPE (rccoord) curpos            
      
      fh=GetActiveQQ()
      Call ClearScreen($GCLEARSCREEN)
	CALL SETTEXTPOSITION(1,1,curpos)
	WRITE(fh,*) 'Algorithm: Linear approximation'
 
	zstar=1.0d0

C Set up the matrices
	xstar(1) =kstar
	xstar(8) =kstar
	xstar(2) =cstar
	xstar(9) =cstar
	xstar(3) =lstar
	xstar(10)=lstar
	xstar(4) =qstar
	xstar(11)=qstar
	xstar(5) =cstar
	xstar(12)=cstar
	xstar(6) =istar
	xstar(13)=istar
	xstar(7) =zstar
	xstar(14)=zstar

	Call CDJac(14,6,xstar,Sys_LA,gmat)


	
	Cu(1:2,1)=gmat(1:2,5)
	Cu(1:2,2)=gmat(1:2,6)
	Cxl(1:2,1)=-gmat(1:2,1)
	Cxl(1:2,2)=-gmat(1:2,2)
	Cxl(1:2,3)=-gmat(1:2,3)
	Cxl(1:2,4)=-gmat(1:2,4)
	Cz(1:2)=-gmat(1:2,7)

	Dxl(1:4,1)=-gmat(3:6,8)
	Dxl(1:4,2)=-gmat(3:6,9)
	Dxl(1:4,3)=-gmat(3:6,10)
	Dxl(1:4,4)=-gmat(3:6,11)
	Fxl(1:4,1)=-gmat(3:6,1)
	Fxl(1:4,2)=-gmat(3:6,2)
	Fxl(1:4,3)=-gmat(3:6,3)
	Fxl(1:4,4)=-gmat(3:6,4)
	Du(1:4,1) =gmat(3:6,12)
	Du(1:4,2) =gmat(3:6,13)
	Fu(1:4,1) =gmat(3:6,5)
	Fu(1:4,2) =gmat(3:6,6)
	Dz(1:4)   =gmat(3:6,14)
	Fz(1:4)   =gmat(3:6,7)

C Compute policy functions
      nx=2
	nl=2
	ns=1
	nc=2

      Call SolveLA(nc,nx,nl,ns,Cu,Cxl,Cz,Dxl,Fxl,Du,Fu,Dz,Fz,Rho,Lxx,Lxz,Llx,Llz,Lux,Luz)

C Save solution to file for use with other algorithms
	open(25,file='Lxx.bin',form='unformatted')
	write(25) Lxx
	close(25)

	open(25,file='Lxz.bin',form='unformatted')
	write(25) Lxz
	close(25)

	open(25,file='Lux.bin',form='unformatted')
	write(25) lux
	close(25)

	open(25,file='Luz.bin',form='unformatted')
	write(25) luz
	close(25)

	open(25,file='Llx.bin',form='unformatted')
	write(25) Llx
	close(25)

	open(25,file='Llz.bin',form='unformatted')
	write(25) Llz
	close(25)

 
      Return
	 
      END Subroutine


C ************************ Subroutines *****************************************************
C

C Sys_LA: defines the rhs of the system of equations from which the
C          the coefficients of the matrices Cu, Cxl, etc. are derived
C     
C    x(1) = k0, x(2)=c-1, x(3) =l0, x(4) =q0, x(5) =c0, x(6) =i0, x(7) =z0
C    x(8) = k1, x(9)=c,   x(10)=l1, x(11)=q1, x(12)=c1, x(13)=i1, x(14)=z1
C
 
	Subroutine Sys_LA(n,m,x,fx)

	use Def_Par

	Integer(4) n, m
	Real(8) x(1:n), fx(1:n)

	Real(8) Phi

	fx(1)=x(4)-(1.0/a1)*((x(6)/x(1))**zeta)
	fx(2)=x(7)*(x(1)**alpha)-x(5)-x(6)
	fx(3)=x(8)-Phi(x(6)/x(1))*x(1)-(1.0d0-delta)*x(1)
	fx(4)=x(4)-beta*(x(10)/x(3))*(alpha*x(14)*(x(8)**(alpha-1.0d0))-(x(13)/x(8)) + x(11)*(Phi(x(13)/x(8))+1.d0-delta))
	fx(5)=x(3)-((x(5)-b*x(2))**(-eta))+beta*b*((x(12)-b*x(5))**(-eta))
	fx(6)=x(9)-x(5)

	return

	End Subroutine

C*********************************************************************************************
	Real(8) Function qla(k1,c1,z1) ! the linear policy function for q. Note that k1, c1, and z1 are the logs, since they are use in Psi1

	use Def_Par
	use Def_LA
	use Errors

	Real(8) k1, c1, z1

	Real(8) k, c, z

	k=dexp(k1)
	c=dexp(c1)
	z=dexp(z1)

	qla=qstar + Llx(2,1)*(k-kstar) + Llx(2,2)*(c-cstar) + Llz(2,1)*(z-1.0d0)
	if (qla.lt.0.0d0) then
		Call MyMessage("Not able to use linear solution within given bounds","LA Erorr")
		stop
		Return
	Endif	
	qla=dlog(qla)

	Return

	End Function

C***********************************************************************************************
	Real(8) Function psila(k1,c1,z1) ! the linear policy function for psi2. Note, that k1, c1, and z1 are the logs since they are used in Psi2

	use Def_Par
	use Def_LA
	use Errors

	Real(8) k1, c1, z1

	Real(8) k, c, z, cla, temp, lla

	k=dexp(k1)
	c=dexp(c1)
	z=dexp(z1)

	cla=cstar+Lux(1,1)*(k-kstar) + Lux(1,2)*(c-cstar) + Luz(1,1)*(z-1.0d0)
	lla=lstar+Llx(1,1)*(k-kstar) + Llx(1,2)*(c-cstar) + Llz(1,1)*(z-1.0d0)
	temp=((cla-b*c)**(-eta)) - lla
	psila=(temp/(beta*b))
	if (psila.lt.0.0d0) then
		Call MyMessage("Not able to use linear solution within given bounds","LA Erorr")
		stop
		Return
	Endif	
	psila=dlog(psila)

	Return

	End Function 

C****************************************************************************************
C PolicyLA: returns the linear policy function of the variable specified in the
C           string var, given k, c, and z

	Real(8) Function PolicyLA(var,k,c,z)

	use Def_LA
	use Def_par

	Real(8) k, c, z
	Character(1) var

	Select Case(var)
		Case('c')
			PolicyLA=cstar+Lux(1,1)*(k-kstar)+Lux(1,2)*(c-cstar)+Luz(1,1)*(z-1.0d0)
		Case('i')
			PolicyLA=istar+Lux(2,1)*(k-kstar)+Lux(2,2)*(c-cstar)+Luz(2,1)*(z-1.0d0)
		Case('l')
			PolicyLA=lstar+Llx(1,1)*(k-kstar)+Llx(1,2)*(c-cstar)+Llz(1,1)*(z-1.0d0)
		Case('q')
			PolicyLA=qstar+Llx(2,1)*(k-kstar)+Llx(2,2)*(c-cstar)+Llz(2,1)*(z-1.0d0)
		Case('k')
			PolicyLA=kstar+Lxx(1,1)*(k-kstar)+Lxx(1,2)*(k-kstar)+Lxz(1,1)*(z-1.0d0)
	End Select

	Return

	End Function
	