C Equity.for: Solve the model of Section 6.3.4 of Heer/Mau�ner, 2nd Edition
C
	Module Def_Par

	Integer(4) degree(1:2), nofs, nobs, invalid
	Integer(4) ng1, ng2
	Real(8) alpha, beta, b, eta, delta, rho, sigma, zeta, a1, a2
	Real(8) kstar, cstar, lstar, istar, ystar, qstar, zstar
	Real(8) sy(1:6), rss(1:3), xminmax(1:4,1:2)
	Real(8), allocatable :: gvec1(:), gvec2(:)	

	Real(8) xcube(1:2,1:4,1:4), ycube(1:4,1:4,1:4)	

	Logical Linear

	End Module Def_Par

	Module Def_Proj

	use DFPORT

	Integer(4) nodes(1:3), initialize, increase, method
	Real(8) x_bounds(1:3,1:2), psi_bounds(1:3,1:2)
	Real(8) k_ex, c_ex, z_ex, l_ex

      Real(8) Lsec(1:2)

	Character(256) Laufzeit
	Character(18) Laufzeiten(1:2)

	DATA Lsec/2*0.0/
	DATA Laufzeiten(1)/'Solution:        '/
	DATA Laufzeiten(2)/'Simulation:      '/

	End Module Def_Proj


	Module Errors

	Integer(4) FError, LError, ErrorCode, lfh

	End Module Errors

	Module Def_GH6

	Real(8) ghx(1:6), ghw(1:6)

	Data ghx /-2.35060497367, -1.33584907401, -0.436077411928,  0.436077411928,  1.33584907401 , 2.35060497367/
	Data ghw /0.00453000990551, 0.157067320323, 0.724629595224, 0.724629595224, 0.157067320323,  0.00453000990551/

	End Module Def_GH6

	Module Def_LA
	
	Real(8) Lxx(1:2,1:2), Lxz(1:2,1), Lux(1:2,1:2), Luz(1:2,1), Llx(1:2,1:2), Llz(1:2,1)
	
	End Module Def_LA	   

C Here begin the program
	program Equity

	use Def_Par
	use Def_Proj
	use Def_GH6
	use MNR
	use Errors

	use DFLIB      
	
	Integer(4) i, j, iter, trials, algo, retcode, GetNPar 
	Real(8) temp, crit(1:6), xi
	Real(8), allocatable :: gamma0(:), gamma1(:), work(:)
	Real(8) inv, Phi
	Character(50) MyDate    
	Logical ok, InitialSettings
      
	External Sys_Proj1a, Sys_Proj1b, Sys_Proj2a, Sys_Proj2b

	Type (rccoord) curpos		
      
C Text for about box
      i=AboutBoxQQ('Program Equity.exe\r Authors: Burkhard Heer and Alfred Maussner\r Version: March, 12th, 2008'C)

C Prepare output window
      ok=InitialSettings()
      Call MakeSmallWindow(10,'Program Progress',2)      

C Open LogFile
	lfh=12
	open(lfh,file='LogFile.txt')
	WRITE(lfh,"(A50)") MyDate()	

C Read parameters from the file Parameters.txt
	Call GetI('degree1','Parameters.txt',degree(1))
	Call GetI('degree2','Parameters.txt',degree(2))
	Call GetI('method','Parameters.txt',method)
	Call GetI('knodes','Parameters.txt',nodes(1))
	Call GetI('cnodes','Parameters.txt',nodes(2))
	Call GetI('znodes','Parameters.txt',nodes(3))

	Call GetD('kmin','Parameters.txt',x_bounds(1,1))
	Call GetD('kmax','Parameters.txt',x_bounds(1,2))
	Call GetD('cmin','Parameters.txt',x_bounds(2,1))
	Call GetD('cmax','Parameters.txt',x_bounds(2,2))
	Call GetD('zmin','Parameters.txt',x_bounds(3,1))
	Call GetD('zmax','Parameters.txt',x_bounds(3,2))

	Call GetD('psi_kmin','Parameters.txt',psi_bounds(1,1))
	Call GetD('psi_kmax','Parameters.txt',psi_bounds(1,2))
	Call GetD('psi_cmin','Parameters.txt',psi_bounds(2,1))
	Call GetD('psi_cmax','Parameters.txt',psi_bounds(2,2))

	Call GetI('increase','Parameters.txt',increase)
	Call GetI('initialize','Parameters.txt',initialize)
	Call GetI('algo','Parameters.txt',algo)

	Call GetD('alpha','Parameters.txt',alpha)
	Call GetD('beta' ,'Parameters.txt',beta)
	Call GetD('eta'  ,'Parameters.txt',eta)
	Call GetD('delta','Parameters.txt',delta)
	Call GetD('b'    ,'Parameters.txt',b)
	Call GetD('rho'  ,'Parameters.txt',rho)
	Call GetD('sigma','Parameters.txt',sigma)
	Call GetD('xi', 'Parameters.txt',xi)
	zeta=1.0d0/xi
	Call GetI('trials','Parameters.txt',trials)

C Compute stationary solution
	a1=delta**zeta
	a2=(zeta*delta)/(zeta-1.0d0)

	kstar=((1.0d0-beta*(1.0d0-delta))/(alpha*beta))**(1.0d0/(alpha-1.0d0))
	ystar=kstar**alpha
	cstar=ystar-delta*kstar
	istar=ystar-cstar
	lstar=(1.0d0-beta*b)*(((1.d0-b)*cstar)**(-eta))
	qstar=1.0d0

C Compute bounds
	x_bounds(1,1)=kstar*x_bounds(1,1)
	x_bounds(1,2)=kstar*x_bounds(1,2)
	x_bounds(2,1)=cstar*x_bounds(2,1)
	x_bounds(2,2)=cstar*x_bounds(2,2)

	psi_bounds(1,1)=kstar*psi_bounds(1,1)
	psi_bounds(1,2)=kstar*psi_bounds(1,2)
	psi_bounds(2,1)=cstar*psi_bounds(2,1)
	psi_bounds(2,2)=cstar*psi_bounds(2,2)

C Transform bounds in psi_bounds to logarithmic scale
	Do i=1,2,1
		Do j=1,2,1
			psi_bounds(i,j)=dlog(psi_bounds(i,j))
		End Do
	End Do

C Compute bounds for z used by Psi1 and Psi2
	temp=2.0d0
	psi_bounds(3,1)=1.05*(rho*dlog(x_bounds(3,1))+dsqrt(temp)*sigma*ghx(1))
	psi_bounds(3,2)=1.05*(rho*dlog(x_bounds(3,2))+dsqrt(temp)*sigma*ghx(6))

	crit(1)=dexp(psi_bounds(3,1))
	crit(2)=dexp(psi_bounds(3,2))

C Determine the number of parameters of gvec1 and gvec2	
	ng1=GetNPar(degree(1))
	ng2=GetNPar(degree(2))

	allocate(gvec1(1:ng1), gvec2(1:ng2), gamma0(1:ng1+ng2), gamma1(1:ng1+ng2))

	iter=1

	ErrorCode=0
	Lsec(1)=RTC()
	Select Case(method)
		Case(1) ! Linear Solution
			Call LA()	
		Case(2) ! Quadratic Solution
			Call QA()
			If (FError.ne.0) ErrorCode=1			
		Case(3,4) ! Galerkin Solution or Collocation solution
1			Call GetInitialGamma(gamma0) ! Initialize Parameter vector
			If (ErrorCode.ne.0) goto 3 
			Call GetI('mnr_maxit','Parameters.txt',mnr_maxit) ! Read information for FixvMNR
			Call GetI('jac','Parameters.txt',jac)	
			crit(1)=1.0d0		
			i=ng1+ng2
			Select Case(algo)
				Case(1) ! Use FixvMNR1				
					if (method==3) Call FixvMN1(i,gamma0,Sys_Proj1a,gamma1,crit)
					if (method==4) Call FixvMN1(i,gamma0,Sys_Proj2a,gamma1,crit)			
					write(lfh,"('Exit from FixvMN1 with message: ',A50,' FError= ',I2)") MNR_Message(DINT(crit(1))), FError				
					write(lfh,"('max|f(x)| at solution:          ',F20.10)") crit(2)
					write(lfh,"('number of iterations:           ',F5.0)") crit(6)	
					if (FError.ne.0) crit(1)=1.0
				Case(2) ! Use Hybrid1		
					j=(i*(3*i+13))/2.
					crit(6)=1.e-6
					allocate(work(1:j))
					gamma1=gamma0
					if (method==3) Call hybrd1(Sys_Proj1b,i,gamma1,gamma0,crit(6),retcode,work,j)
					if (method==4) Call hybrd1(Sys_Proj2b,i,gamma1,gamma0,crit(6),retcode,work,j)			
					write(lfh,"('Exit code from hybrd1: ',I3,' FError= ',I3)") retcode, FError
					write(lfh,"('max|f(x)| at return:   ',F20.10)") MaxVal(dabs(gamma0)) 
					if (retcode.eq.1) crit(1)=0
					deallocate(work)
			End Select
			if ((crit(1).ne.0) .and. (initialize.eq.2)) then
				iter=iter+1		
				if (iter.le.trials) goto 1	
			endif
			if (crit(1).eq.0) then
				ErrorCode=0
				open(25,file='Proj_Par.bin',form='unformatted')
				write(25) gamma1
				close(25)
				gvec1(1:ng1)=gamma1(1:ng1)
				gvec2(1:ng2)=gamma1(ng1+1:ng1+ng2)
			else
				ErrorCode=1
			endif
	End Select


	Lsec(1)=RTC()-Lsec(1)	                 

3     If (ErrorCode.eq.0) then
		Select Case(method)
			Case(1)
				Call Simulate1()
			Case(2)
				Call Simulate2()
			Case(3,4)
				Call GetI('nobs1','Parameters.txt',i)
				Call Impulse(i)
				Call Simulate()
		End Select
	    CALL ElapsedTime(sum(Lsec),LaufZeit)      
		Call WriteResults
	    CALL GETTEXTPOSITION(curpos)
          CALL SETTEXTPOSITION(curpos.row+1,2,curpos)
          WRITE(10,"('Run time= ',A40)") LaufZeit
      else
		Call ClearScreen($GCLEARSCREEN)
		CALL SETTEXTPOSITION(1,1,curpos)
		WRITE(10,"(A)") 'Not able to find a solution or to simulate the model'
		Call SETTEXTPOSITION(2,1,curpos)
		WRITE(10,"(A)") 'See logfile.txt for further information'
	endif

	end

C*********************************************************************************************
C
C Subroutines and Functions
C
C
	Real(8) Function Phi(x) ! the definition of the function phi(i/k)

	use Def_Par

	Real(8) x
		
	Phi=(a1/(1.d0-zeta))*(x**(1.0d0-zeta)) + a2

	Return

	End Function Phi

C********************************************************************************************

	Real(8) Function inv(q,k) ! returns investment as a function of q and k

	use Def_Par

	Real(8) q, k

	inv=delta*(q**(1.0d0/zeta))*k

	Return

	End Function
C**********************************************************************************************

	Real(8) Function Psi1(gvec,k,c,z) ! returns q as a function of k, c, z, given the parameter vector in gvec

	use Def_Par
	use Def_Proj
	use Errors

	Real(8) gvec(1:ng1), k, c, z

	Integer(4) i
	Real(8) x(1:3), ChebEval4

	x(1)=dlog(k)
	x(2)=dlog(c)
	x(3)=dlog(z)

	Do i=1,3,1
		if ((x(i).lt.psi_bounds(i,1)) .or. (x(i).gt.psi_bounds(i,2))) then
			FError=i
			write(lfh,"('Variable ',I1,' out of bounds.',3(F10.5,2X))") i, x(i), psi_bounds(i,1), psi_bounds(i,2)
			Return
		Endif
	End Do

	Psi1=ChebEval4(ng1,gvec,degree(1),x,psi_bounds)

	If ((Psi1 .gt. 700.) .or. (Psi1.lt.-700.0)) then      
		FError=4
		return
	Endif

	Psi1=dexp(Psi1)
	if (Psi1 .le. 0.0d0) FError=5

	Return

	End Function

C**********************************************************************************************

	Real(8) Function Psi2(gvec,k,c,z) ! returns E(C1-bC0)**(-eta) as a function of k, c, z, given the parameter vector in gvec

	use Def_Par
	use Def_Proj
	use Errors

	Real(8) gvec(1:ng2), k, c, z

	Integer(4) i
	Real(8) x(1:3), ChebEval4

	x(1)=dlog(k)
	x(2)=dlog(c)
	x(3)=dlog(z)

	Do i=1,3,1
		if ((x(i).lt.psi_bounds(i,1)) .or. (x(i).gt.psi_bounds(i,2))) then
			FError=i
			write(lfh,"('Variable ',I1,' out bounds.',3(F10.5,2X))") i, x(i), psi_bounds(i,1), psi_bounds(i,22)
			Return
		Endif
	End Do

	Psi2=ChebEval4(ng2,gvec,degree(2),x,psi_bounds)

	If ((Psi2 .gt. 700.) .or. (Psi2.lt.-700.0)) then      
		FError=4
		return
	Endif

	Psi2=dexp(Psi2)
	if (Psi2 .le. 0.0d0) FError=5

	Return

	End Function

C*********************************************************************************************************
C
C GetNPar: determines the number of coefficients of a complete polynomial in three variables of degree p,
C          where we count from 1 onwards so that p=1 is the constant

      Integer(4) Function GetNpar(p)

	Integer(4) p

      Integer(4) i1, i2, i3, k
     	
      k=1

	Do i1=1,p
	   do i2=1,(p+1-i1)
	      do i3=1,(p+2-i1-i2)
              k=k+1
            end do
	   end do
	end do

      GetNpar=k-1

	Return

	End Function

C*************************************************************************************************************
	Subroutine Resid(k,c,z,r) ! computes the residuals, the parameter vectors are given via the module Def_Proj

	use Def_Par
	use Def_Proj
	use Def_GH6
	use Errors

	use IMSLF90 

	Real(8) k, c, z, r(1:2)

	Integer(4) i
	Real(8) q0, i0, l0
	Real(8) Psi1, Psi2, inv, Phi, rhs(1:2)	
	Real(8) sum, s, temp, dconst, pi

	FError=0
	q0=Psi1(gvec1,k,c,z)
	if (FError.ne.0) return
	i0=inv(q0,k)
	c_ex=z*(k**alpha)-i0
	if ((c_ex.lt.dexp(psi_bounds(2,1))) .or. (c_ex.gt.dexp(psi_bounds(2,2)))) then
		FError=2
		return
	endif
	l0=Psi2(gvec2,k,c,z)
	if (FError.ne.0) return
	l_ex=(c_ex-b*c)**(-eta)-b*beta*l0
	if (l_ex.lt.0.0d0) then
		FError=6
		return
	endif
	k_ex=phi(i0/k)*k+(1.0d0-delta)*k
	if ( (k_ex.lt.dexp(psi_bounds(1,1))) .or. (k_ex.gt.dexp(psi_bounds(1,2)))) then
		FError=1
		return
	endif
	z_ex=rho*dlog(z)	
	 
	pi=dconst('pi') ! the next lines implement Gauss-Hermite integration
	r=0.0d0
	s=2.0d0
	s=dsqrt(s)*sigma
	Do i=1,6
			Call GetRhs(s*ghx(i),rhs(1:2))
			if (FError.ne.0) return
			r(1)=r(1)+rhs(1)*ghw(i)
			r(2)=r(2)+rhs(2)*ghw(i)
	End Do
	r(1)=r(1)*((pi)**(-0.50d0))
	r(2)=r(2)*((pi)**(-0.50d0))

	r(1)=q0-r(1)
	r(2)=l0-r(2)

	Return
	End Subroutine

C*********************************************************************************************************
C
	Subroutine GetRhs(x,rhs) ! returns the rhs of the Euler equation for q for integration with GH_INT1

	use Def_Par
	use Def_Proj
	use Errors

	Real(8) x, rhs(1:2) 

	Real(8) z1, q1, c1, i1, l1
	Real(8) Psi1, Psi2, inv, Phi

	z1=dexp(z_ex+x) ! note that z_ex=rho*dlog(z) and x=sigma*epsilion
	FError=0
	q1=Psi1(gvec1,k_ex,c_ex,z1)
	if (FError.ne.0) return
	i1=inv(q1,k_ex)
	c1=z1*(k_ex**alpha)-i1
	if ((c1.lt.dexp(psi_bounds(2,1))) .or. (c1.gt.dexp(psi_bounds(2,2))) ) then
		FError=2
		return
	endif
		
	l1=Psi2(gvec2,k_ex,c_ex,z1)
	if (FError.ne.0) return
	l1=((c1-b*c_ex)**(-eta))-beta*b*l1
	if (l1.lt.0.0d0) then
		FError=6
		return
	endif
	rhs(1)=beta*(l1/l_ex)*(alpha*z1*(k_ex**(alpha-1.0d0))-(i1/k_ex)+q1*(phi(i1/k_ex)+1.0d0-delta))
	rhs(2)=(c1-b*c_ex)**(-eta)

	Return

	End Subroutine


C******************************************************************************************************
C
C Sys_Proj1a(m,n,x,fx): returns the rhs of the system of equations whose zero is the Galerkin solutuion

	Subroutine Sys_Proj1a(m,n,x,fx)

	use Def_Par
      use Def_Proj	
	use Errors
	use IMSLF90	

	Integer(4) m, n
	Real(8) x(1:n), fx(1:m)

      Integer(4) i, j, i1, i2, i3, p1, k, j1, j2, j3	
	Real(8) kbar(1:nodes(1),2), cbar(1:nodes(2),2), zbar(1:nodes(3),2) 
	Real(8) pi, Dconst, r(1:2), temp0, temp1, temp2, Cheb	

	pi=Dconst('pi')    
  
	
C compute the zeros of the Chebyshev polynomials and map them into the intervals for k, c, and z	
      Do i=1,nodes(1)
	   kbar(i,1)=dcos(((dble(2.0d0*i)-1.0d0)/(dble(2.0d0*nodes(1)))) *pi) ! zeros of 
	   kbar(i,2)=0.5d0*(kbar(i,1)+1.0d0)*(x_bounds(1,2)-x_bounds(1,1)) + x_bounds(1,1)
	End Do
	
	Do i=1,nodes(2)
	   cbar(i,1)=dcos(((dble(2.0d0*i)-1.0d0)/(dble(2.0d0*nodes(2))))*pi)   
	   cbar(i,2)=0.5d0*(kbar(i,1)+1.0d0)*(x_bounds(2,2)-x_bounds(2,1)) + x_bounds(2,1)
	End Do

      Do i=1,nodes(3)
	   zbar(i,1)=dcos(((dble(2.0d0*i)-1.0d0)/(dble(2.0d0*nodes(3))))*pi)
	   zbar(i,2)=0.5*(zbar(i,1)+1.0d0)*(x_bounds(3,2)-x_bounds(3,1)) + x_bounds(3,1)
	End Do      

C Write parameters in x into the vectors gvec1 and gvec2
	gvec1(1:ng1)=x(1:ng1)
	gvec2(1:ng2)=x(ng1+1:ng1+ng2)      
	
	temp0=(pi**3)

	Do i=1,3,1
		temp0=temp0*((x_bounds(i,2)-x_bounds(i,1))/(2*nodes(i)))
	End Do

	fx=0.0

      Do i1=1,nodes(1)
		Do i2=1,nodes(2)
			Do i3=1,nodes(3)
				FError=0
				Call Resid(kbar(i1,2),cbar(i2,2),zbar(i3,2),r)
				If (FError.ne.0) Return
				temp1=dsqrt(1.0d0-(kbar(i1,1)**2))*dsqrt(1.0d0-(cbar(i2,1)**2))*dsqrt(1.0d0-(zbar(i3,1)**2))
				k=1
				Do j=1,2,1					
					Do j1=1,degree(j)
						Do j2=1,(degree(j)+1-j1)
							Do j3=1,(degree(j)+2-j1-j2)
								temp2=Cheb(j1-1,kbar(i1,1))*Cheb(j2-1,cbar(i2,1))*Cheb(j3-1,zbar(i3,1))												
								fx(k)=fx(k)+r(j)*temp1*temp2							
								k=k+1
							End Do
						End Do
					End Do
				End Do
			End Do
	    End Do
      End Do
      fx=temp0*fx
	

	Return

	End Subroutine

C********************************************************************************************************
C
C Sys_Proj1b: the same as Sys_Proj1a but with different calling, used for Hybrid1
C
	Subroutine Sys_Proj1b(n,x,fx,retcode)
	
	use Errors
	
	Integer(4) n, retcode
	Real(8) x(1:n), fx(1:n)
	
	Call Sys_Proj1a(n,n,x,fx)
	
	If (FError.ne.0) retcode=Ferror
	
	return

	End Subroutine

C**********************************************************************************************************
C
C	Func1(n,x): returns the maximum absolute value of Sys_Proj1a,
C                 used to find starting values for the collocation solution
C
	Real(8) Function Func1(n,x)

	use Errors

	Integer(4) n
	Real(8)    x(1:n)
	
	Real(8)    fx(1:n)

	FError=0
	Call Sys_Proj1a(n,n,x,fx)
	If (FError.ne.0) then
		Func1=-1.0
	else
		Func1=MaxVal(dabs(fx))
	endif

	Return

	End Function
C*************************************************************************************************
C Sys_Proj2a: The zero of the rhs returned by this subroutine defines the
C             collocation solution of the model

      Subroutine Sys_Proj2a(m,n,x,fx)

	use Def_Par
	use Def_Proj
	use IMSLF90	
      use Errors

      Integer(4) m, n
	Real(8) x(n), fx(m), fx2(1:ng1,1:2)

      Integer(4) i, j, i1, i2, i3, p, k
	Real(8) zbar(MaxVal(degree)),kbar(MaxVal(degree)), cbar(MaxVal(degree)), pi, Dconst
      Real(8) r(1:2)	
	
	pi=Dconst('pi')    

	gvec1(1:ng1)=x(1:ng1)
	gvec2(1:ng2)=x(1+ng1:ng1+ng2)      
	
  
	k=1
c	Do j=1,2,1

c		p=degree(j)	
	p=degree(1)
		Do i=1,p
			kbar(i)=dcos(((dble(2.0d0*i)-1.0d0)/(dble(2.0d0*p))) *pi)
			kbar(i)=0.5d0*(kbar(i)+1.0d0)*(x_bounds(1,2)-x_bounds(1,1)) + x_bounds(1,1)
		End Do

		Do i=1,p
			cbar(i)=dcos(((dble(2.0d0*i)-1.0d0)/(dble(2.0d0*p)))*pi)
			cbar(i)=0.5d0*(cbar(i)+1.0d0)*(x_bounds(2,2)-x_bounds(2,1)) + x_bounds(2,1)
		End Do      
	
		Do i=1,p
			zbar(i)=dcos(((dble(2.0d0*i)-1.0d0)/(dble(2.0d0*p)))*pi)   
			zbar(i)=0.5d0*(zbar(i)+1.0d0)*(x_bounds(3,2)-x_bounds(3,1)) + x_bounds(3,1)
		End Do

	      Do i1=1,p
			Do i2=1,(p+1-i1)
				Do i3=1,(p+2-i1-i2)
					Call Resid(kbar(i1),cbar(i2),zbar(i3),r)
					if (FError.ne.0) Return
c					fx(k)=R(j)
					fx2(k,1:2)=r
					k=k+1      
				End Do
			End Do
		End Do
      
c	End Do
	fx(1:ng1)=fx2(1:ng1,1)
	fx(ng1+1:ng1+ng2)=fx2(1:ng2,2)

	Return

	End Subroutine

C********************************************************************************************************
C
C Sys_Proj2b: the same as Sys_Proj2a but with different calling, used for Hybrid1
C
	Subroutine Sys_Proj2b(n,x,fx,retcode)
	
	use Errors
	
	Integer(4) n, retcode
	Real(8) x(1:n), fx(1:n)
	
	Call Sys_Proj2a(n,n,x,fx)
	
	If (FError.ne.0) retcode=Ferror
	
	return

	End Subroutine

C**********************************************************************************************************
C
C	Func2(n,x): returns the maximum absolute value of Sys_Proj2a,
C                 used to find starting values for the collocation solution
C
	Real(8) Function Func2(n,x)

	use Errors

	Integer(4) n
	Real(8)    x(1:n)
	
	Real(8)    fx(1:n)

	FError=0
	Call Sys_Proj2a(n,n,x,fx)
	If (FError.ne.0) then
		Func2=-1.0
	else
		Func2=MaxVal(dabs(fx))
	endif

	Return

	End Function

C**********************************************************************************************************
C
C GetInitialGamma: Initializes the parameter vector for the non-linear equations solver
C
C	
	Subroutine GetInitialGamma(gamma)

	use Def_Proj
	use Def_Par
	use Errors
	use GSPars1

	Real(8) gamma(1:ng1+ng2)

	Integer(4) n, i
	Integer(4) GetNpar
	Real(8) Fit, Func1, Func2, qla, psila, qqa, psiqa
	Real(8), allocatable :: gammai(:), gin(:), gout(:)

	Character(40) infile

	Logical ok

	External Func1, Func2, qla, psila, qqa, psiqa

	Select Case (initialize)

		Case(1) ! Read from file
			Call GetI('increase','Parameters.txt',increase)
			Call GetS('par_file','Parameters.txt',infile)
			inquire(file=infile,exist=ok)			
			if (.not. ok) then
				Call MyMessage("File does not exist. Program terminates","Proj Erorr")
				stop
			endif
			open(25,form='unformatted',file=infile)
			Select Case(increase)
				Case(0)
					read(25) gamma
				Case(1)
					n=GetNPar(degree(1)-1)
					allocate(gammai(1:n+ng2),gin(1:n),gout(1:ng1))
					read(25) gammai
					gin(1:n)=gammai(1:n)
					i=degree(1)-1
					Call Gincrease(i,n,ng1,gin,gout)
					gamma(1:ng1)=gout(1:ng1)
					gamma(ng1+1:ng1+ng2)=gammai(n+1:n+ng2)					
				Case(2)
					n=GetNPar(degree(2)-1)
					allocate(gammai(1:ng1+n),gin(1:n),gout(1:ng2))
					read(25) gammai
					gin(1:n)=gammai(ng1+1:ng1+n)
					i=degree(2)-1
					Call Gincrease(i,n,ng2,gin,gout)
					gamma(1:ng1)=gammai(1:ng1)
					gamma(ng1+1:ng1+ng2)=gout					
			End Select			
			close(25)				

		Case(2) ! Use genetic search to find initial parameter vector			  
			Call GetI('npop','Parameters.txt',npop)
			Call GetI('ngen','Parameters.txt',ngen)
			Call GetD('s_sigma','Parameters.txt',s_sigma)
			n=ng1+ng2
			Select Case(method)
				Case(3)
					Call GSearch1(Func1,n,gamma,Fit) 			
				Case(4)
					Call GSearch1(Func2,n,gamma,Fit)
			End Select
			Write(lfh,"('Initial parameters form genetic search:')")
			Write(lfh,"('Psi1 Parameters:')")
			do i=1,ng1,1
				Write(lfh,"(F15.10)") gamma(i)
			end do
			Write(lfh,"('Psi2 Parameters:')")
			do i=1,ng2,1
				Write(lfh,"(F15.10)") gamma(ng1+i)
			end do
			Write(lfh,"('Function value of solution ',F15.10)") Fit
		
		Case(3) ! Use the linear policy functions to initialize the parameters
			Call LA()				
			i=degree(1)-1		
			Call ChebCoef3(qla,i,nodes(1),psi_bounds,ng1,gvec1)
			i=degree(2)-1
			Call ChebCoef3(psila,i,nodes(1),psi_bounds,ng2,gvec2)
			gamma(1:ng1)=gvec1(1:ng1)
			gamma(ng1+1:ng1+ng2)=gvec2(1:ng2)

		Case(4) ! Use the quadratic policy functions to initialize the parameters
			Call QA()				
			i=degree(1)-1		
			Call ChebCoef3(qqa,i,nodes(1),psi_bounds,ng1,gvec1)
			i=degree(2)-1
			Call ChebCoef3(psiqa,i,nodes(1),psi_bounds,ng2,gvec2)
			gamma(1:ng1)=gvec1(1:ng1)
			gamma(ng1+1:ng1+ng2)=gvec2(1:ng2)

	End Select 

	Return

	End Subroutine
C***************************************************************************************************
C Gincrease: Uses the vector of coefficients of a complete polynomial of p
C           to initialize the vector of coefficients of a polynomial
C           of degree p+1

      Subroutine Gincrease(p,n1,n2,gin,gout)      

	Integer(4) p, n1, n2
	Real(8)  gin(1:n1), gout(1:n2)

      Integer(4) i1,i2,i3, p2, k1,k2
	
	gout=0.0
	
      p2=p+1
      k1=1
	k2=0
      Do i1=1,p2,1
         do i2=1,(p2+1-i1),1
            do i3=1,(p2+2-i1-i2),1         
             if ((i1+i2+i3-2).le.p) then
		      k2=k2+1
			  gout(k1)=gin(k2)
		   endif            
             k1=k1+1            
            End Do
         End Do
      End Do

      Return

	End Subroutine



C*******************************************************************************************
C
C WriteResults: write results and parameters to a file

	Subroutine WriteResults()

	use Def_Par
	use Def_Proj

	Integer(4) i, j
	Real(8) q, Psi1, PolicyQA
	Character(50) outfile, temp, MyDate

	Call GetS('outfile','Parameters.txt',outfile)

C Write solution to file
	open(11,file=trim(outfile))
	WRITE(11,"(A50)") MyDate()
	WRITE(11,"('Run time:',A40)") Laufzeit
	WRITE(11,"('')")
	Do i=1,2
		Call ElapsedTime(Lsec(i),temp)
		WRITE(11,"(A18,A40)") Laufzeiten(i),temp
	End Do
	Write(11,"('Statistics:')")
	Write(11,"('Riskless rate: ',F10.5)") rss(1)
	Write(11,"('Equity rate  : ',F10.5)") rss(2)
	Write(11,"('Premium      : ',F10.5)") rss(3)
	Write(11,"(A)")
	Write(11,"('Std. of Ouput:       ',F10.5)") sy(1)
	Write(11,"('Std. of Consumption: ',F10.5)") sy(2)
	Write(11,"('Std. of Investment:  ',F10.5)") sy(3)
	Write(11,"('Std. of Capital:     ',F10.5)") sy(4)
	Write(11,"('Std. of Lambda:      ',F10.5)") sy(5)
	Write(11,"('Std. of q:           ',F10.5)") sy(6)
	Write(11,"(A)")
	Write(11,"('kmin= ',F10.5,' kmax= ',F10.5)") (xminmax(1,1)/kstar), (xminmax(1,2)/kstar)
	Write(11,"('cmin= ',F10.5,' cmax= ',F10.5)") (xminmax(2,1)/cstar), (xminmax(2,2)/cstar)
	Write(11,"('zmin= ',F10.5,' zmax= ',F10.5)")  xminmax(3,1), xminmax(3,2)
	Write(11,"('qmin= ',F10.5,' qmax= ',F10.5)") xminmax(4,1), xminmax(4,2)
	Write(11,"('invalid simulations: ',I7)") invalid
	WRITE(11,"('')")
	WRITE(11,"(A)") 'Parameters of the model:'
	WRITE(11,"('alpha=   ',F10.4)")  alpha
	WRITE(11,"('b    =   ',F10.4)")  b
	WRITE(11,"('beta =   ',F10.4)")  beta 
	WRITE(11,"('eta  =    ',F10.4)")  eta
	WRITE(11,"('delta=   ',F10.4)")  delta
	WRITE(11,"('zeta =   ',F10.4)") zeta
	WRITE(11,"('rho  =   ',F10.4)")  rho
	WRITE(11,"('sigma=   ',F10.5)")  sigma
	Select Case(method)
		Case(2)
			Write(11,"(A)")
			Write(11,"('Implied q= ',F15.7)") PolicyQA('q',kstar,cstar,1.0d0)
		Case(3,4)	
			WRITE(11,"(A)") ' '
			Write(11,"('Parameters of the Algorithm:')")
			Call RetrievSettings
			Write(11,"(A)")
			Write(11,"('Coefficients of Polynomial for q: ')")
			Call WriteCoef(1,ng1,gvec1)
			Write(11,"(A)")
			Write(11,"('Coefficients of Polynomial for l: ')")
			Call WriteCoef(2,ng2,gvec2)
			Write(11,"(A)")
			q=Psi1(gvec1,kstar,cstar,1.0d0)
			Write(11,"('Implied q= ',F15.7)") q
	End Select
	
	Close(11)

	Return

	End Subroutine

C**********************************************************************************************
C
	Subroutine WriteCoef(what,ng,x)

	use Def_Par
	use Def_Proj

	Integer(4) what, ng
	Real(8) x(1:ng)

	Integer(4) i, j, l, k, p

	write(11,"('gamma(i,j,l): Index i for K, index j for C, and index l for Z')")	

	p=degree(what)
	k=1
	Do i=1,p,1
		Do j=1,(p+1-i),1					
			Do l=1,(p+2-i-j)
				write(11,"('gamma(',I1,',',I1,',',I1')= ',F15.10)") (i-1),(j-1),(l-1), x(k)
					k=k+1
			End Do
		End Do
	End Do

	Return

	End Subroutine

C************************************************************************************************
C  Retrieve Settings

      Subroutine RetrievSettings()

	use Def_Par
	use Def_Proj

      Integer(4) fhi, fho
      Character(256) Text1
	
	fhi=14
	fho=11

	open(14,file='Parameters.txt')  
	Write(11,"('[Algo]')")    
	Do while (.not. eof(14))
	    Read(14,'(A)') Text1	
		If (Text1(1:6).eq.'[Algo]') Call WriteFileSequence(fhi,fho)
	End Do
	Write(11,"(A)")
	Write(11,"('[Proj]')")
	Rewind(14)
	Do while (.not. eof(14))
	    Read(14,'(A)') Text1	
		If (Text1(1:6).eq.'[Proj]') Call WriteFileSequence(fhi,fho)
	End Do
	Write(11,"(A)")
	Write(11,"('[Search]')")
	Rewind(14)
	Do while (.not. eof(14))
	    Read(14,'(A)') Text1	
		If (Text1(1:8).eq.'[Search]') Call WriteFileSequence(fhi,fho)
	End Do
	Write(11,"(A)")
	Write(11,"('[Simulation]')")
	Rewind(14)
	Do while (.not. eof(14))
	    Read(14,'(A)') Text1	
		If (Text1(1:12).eq.'[Simulation]') Call WriteFileSequence(fhi,fho)
	End Do

	Write(11,"(A)")
	Write(11,"('[Output]')")
	Rewind(14)
	Do while (.not. eof(14))
	    Read(14,'(A)') Text1	
		If (Text1(1:8).eq.'[Output]') Call WriteFileSequence(fhi,fho)
	End Do

	if (initialize.eq.1) then
		rewind(14)
		write(11,"(A)")
		write(11,"('[Input]')")
		Do while (.not. eof(14))
		    Read(14,'(A)') Text1	
			If (Text1(1:7).eq.'[Input]') Call WriteFileSequence(fhi,fho)
		End Do
	Endif


	close(14)		
	Return

	End Subroutine


	Subroutine WriteFileSequence(fhi,fho)

	Integer(4) fhi,fho

	Character(256) Text2

	Read(fhi,'(A)') Text2
	Do while(Text2(1:1).ne.' ')
		Write(fho,'(A)') Text2
		Read(fhi,'(A)') Text2
	End Do

	Return

	End Subroutine
