C Module for QA solution
	Module Def_QA

	Integer(4) nx, ny, nz

	End Module Def_QA

C QA
C
C Purpose: Compute the quadratic approximate policy functions
C          of the benchmark real business cycle.


      Subroutine QA

	use Def_Par
	use Def_LA
	use Errors

	use DFPORT
	use DFLIB

      Integer(4) nx, ny, nz, eqno, fh
	
      Real(8) hcube(1:6,1:14,1:14), gmat(1:6,1:14), xstar(1:14), xstar1(1:14), Lyx(1:4,1:2), Lyz(1:4,1)	
	Real(8) omat, Sys_QA

	External Sys_QA, Sys_LA

	Common /EquationNumber/ eqno

      TYPE (rccoord) curpos                        

	Call LA()
	If (ErrorCode.ne.0) return

	fh=GetActiveQQ()
      Call ClearScreen($GCLEARSCREEN)
	CALL SETTEXTPOSITION(1,1,curpos)
	WRITE(fh,*) 'Algorithm: Quadratic approximation'
   

	Lyx(1:2,1:2)=Llx
	Lyx(3:4,1:2)=Lux(1:2,1:2)
	Lyz(1:2,1)=Llz(1:2,1)	
	Lyz(3:4,1)=Luz(1:2,1)
	

	omat=1.0d0

C Set up the matrices
	xstar(1) =kstar
	xstar(8) =kstar
	xstar(2) =cstar
	xstar(9) =cstar
	xstar(3) =lstar
	xstar(10)=lstar
	xstar(4) =qstar
	xstar(11)=qstar
	xstar(5) =cstar
	xstar(12)=cstar
	xstar(6) =istar
	xstar(13)=istar
	xstar(7) =zstar
	xstar(14)=zstar

	nx=14
	nz=1
	ny=4

	Call CDJac(nx,6,xstar,Sys_LA,gmat)
	Do eqno=1,6
			Call CDHesse(nx,xstar,Sys_QA,hcube(eqno,1:nx,1:nx))
	End Do
	
	
	nx=2
			
	Call SolveQA(nx,nz,ny,Lxx,Lxz,Lyx,Lyz,gmat,hcube,rho,omat,xcube,ycube)	
 
      Return
	 
      END Subroutine


C ************************ Subroutines *****************************************************
C

C Sys_QA: uses Sys_LA but returns just the lhs of equation eqno
C         see, Sys_LA in LA.for

 
	Real(8) Function Sys_QA(n,x)
	
	Integer(4) n
	Real(8) x(1:n)

	Integer(4) eqno
	Real(8) fx1(1:n)

	Common /EquationNumber/eqno 

	Call Sys_LA(n,n,x,fx1)

	Sys_QA=fx1(eqno)

	return

	End Function

C*************************************************************************************************
	Real(8) Function PolicyQA(var,k,c,z)

	use Def_Par
	use Def_LA
	
	Real(8) k, c, z
	Character(1) var

	Real(8) xvec(1:4), PolicyLA

	xvec(1)=k-kstar
	xvec(2)=c-cstar
	xvec(3)=z-1.0d0
	xvec(4)=sigma

	Select Case(var)

		Case('c')
			PolicyQA=PolicyLA('c',k,c,z)+0.5d0*Dot_Product(xvec,MatMul(ycube(3,1:4,1:4),xvec))
		Case('i')
			PolicyQA=PolicyLA('i',k,c,z)+0.5d0*Dot_Product(xvec,MatMul(ycube(4,1:4,1:4),xvec))
		Case('l')
			PolicyQA=PolicyLA('l',k,c,z)+0.5d0*Dot_Product(xvec,MatMul(ycube(1,1:4,1:4),xvec))
		Case('q')
			PolicyQA=PolicyLA('q',k,c,z)+0.5d0*Dot_Product(xvec,MatMul(ycube(2,1:4,1:4),xvec))
		Case('k')
			PolicyQA=PolicyLA('k',k,c,z)+0.5d0*Dot_Product(xvec,MatMul(xcube(1,1:4,1:4),xvec))

	End Select

	Return

	End Function


C*********************************************************************************************
	Real(8) Function qqa(k1,c1,z1) ! the quadratic policy function for q. Note that k1, c1, and z1 are the logs, since they are use in Psi1

	use Def_Par
	use Def_LA
	use Errors

	Real(8) k1, c1, z1

	Real(8) k, c, z, PolicyQA

	k=dexp(k1)
	c=dexp(c1)
	z=dexp(z1)

	qqa=PolicyQA('q',k,c,z)
	if (qqa.lt.0.0d0) then
		Call MyMessage("Not able to use quadratic solution within given bounds","QA Erorr")
		stop
		Return
	Endif	
	qqa=dlog(qqa)

	Return

	End Function

C***********************************************************************************************
	Real(8) Function psiqa(k1,c1,z1) ! the quadratic policy function for psi2. Note, that k1, c1, and z1 are the logs since they are used in Psi2

	use Def_Par
	use Def_LA
	use Errors

	Real(8) k1, c1, z1

	Real(8) k, c, z, cqa, temp, lqa, PolicyQA

	k=dexp(k1)
	c=dexp(c1)
	z=dexp(z1)

	
	cqa=PolicyQA('c',k,c,z)
	lqa=PolicyQA('l',k,c,z)
	temp=((cqa-b*c)**(-eta)) - lqa
	psiqa=(temp/(beta*b))
	if (psiqa.lt.0.0d0) then
		Call MyMessage("Not able to use quadratic solution within given bounds","QA Erorr")
		stop
		Return
	Endif	
	psiqa=dlog(psiqa)

	Return

	End Function 
