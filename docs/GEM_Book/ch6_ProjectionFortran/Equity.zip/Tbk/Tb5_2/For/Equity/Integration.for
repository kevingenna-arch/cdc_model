C Integration.for: Fortran subroutines and functions for numerical integration
C
C Alfred Mau�ner
C 8 March 2008
C
C GC_Int1
C GC_Int2
C GH_Def
C GH_Int1
C 
C *****************************************************************************************************
C GC_Int1
C
C Integrate a real valued function over [a,b], using Gauss-Chebyshev quadrature
C
C Usage:  y=GC_Int(f, d, n)
C
C Input: f := Real(8) pointer to the procedure that evaluates the function, usage must be y=f(x)
C        d := Real(8) 2 times 1 vector, d(1) lower, d(2) upper limit of integration
C        n := Integer(4), the number of nodes where f is to be evaluated in order to compute y
C
C Ouput: y := Real(8), the value of the integral of f(x) over [a,b]


      Real(8) Function GC_Int1(f,d,n)

	use IMSLF90      

      Integer(4) n
      Real(8) f, d(2)

      Integer(4) i
      Real(8) x(n), z(n), sum, pi, dconst, y
		
      External f, dconst

      pi=Dconst('pi')

      Do i=1,n

         x(i)=dcos(((2.*i-1)/(2.*n))*pi)         ! zero of n-the degree Chebyshev polynomial
	   z(i)=(x(i)+1.)*(d(2)-d(1))*0.5 + d(1)   ! adjusted to [a,b]
      
	End Do
     
      sum=0
     
      do i=1,n
	   y=f(z(i))
	   if (IsNan(y)) then
	      GC_Int1=y
		  Return
	   endif     
         sum=sum+y*dsqrt(1.-(x(i)**2))          
      End do
   
      sum=pi*(d(2)-d(1))*sum
      sum=sum/(2.*n)
    
      GC_Int1=sum
      
	Return

	End Function


C *************************************************************************************************************
C GC_Int2
C
C Integrate a real valued function f(x,y) over [a,b]x[c,d], using Gauss-Chebyshev quadrature
C
C Usage:  y=GC_Int(f, d, n)
C
C Input: f := Real(8) pointer to the procedure that evaluates the function, usage must be z=f(x,y)
C        d := Real(8) 2 times 2 matrix, d(1,1) lower, d(1,2) upper limit of integration for x,
C                                       d(2,1) lower, d(2,2) upper limit of integration for y
C        n := Integer(4) 2 times 1 vector, n[1] the number of nodes for x, n[2] the number of node for y
C
C   Output:  Real(8) v := scalar: the (approximate) value of the integral
C
C   Remarks: if f(x,y) returns a scalar missing value (since f is not computable at this point)
C            the procedure stops and returns 


      Real(8) Function GC_Int2(f,d,n)

	use IMSLF90      
      

	Integer(4) n(2)
	Real(8) f, d(2,2)

      Integer(4) i, j
	Real(8) x1(n(1)), x2(n(2)), z1(n(1)), z2(n(2)), y, sum, dconst, pi

      External f, dconst

      pi=dconst('pi')
      Do i=1,n(1),1

         x1(i)=dcos(((2.*i - 1.)/(2.*dble(n(1))))*pi)        ! zero of the n-th degree Chebyshev polynomila for x
         z1(i)=(x1(i)+1.)*(d(1,2)-d(1,1))*0.5 + d(1,1) ! adjusted to [a,b]                             
   
      End Do

      Do i=1,n(2)
         x2(i)=dcos(((2.*i-1.)/(2.*dble(n(2))))*pi)             ! zeros of the n-th degree Chebyshev polynomial for y 
         z2(i)=(x2(i)+1.)*(d(2,2)-d(2,1))*0.5 + d(2,1) ! adjusted to [c,d]                             

      End Do
      
      sum=0
      Do i=1,n(1),1
        Do j=1,n(2),1        
            y=f(z1(i),z2(j))	      
            if (isnan(y)) then
		     GC_INT2=y
			 Return
		  Endif	      
	       y=y*dsqrt(1.-(x1(i)**2))*dsqrt(1.-(x2(j)**2))              
            sum=sum+y
        End Do        
      End Do
      
      sum=pi*(d(1,2)-d(1,1))*pi*(d(2,2)-d(2,1))*sum
      sum=sum/(2.*dble(n(1))*2.*dble(n(2)))
   
      GC_INT2=sum

	Return

	End Function

C ************************************************************************************
C
C Module GH_Def: nodes and weights for Gauss-Hermite 4 point integration
C
	Module GH_Def

	Real(8) ghx(1:4), ghw(1:4)

	DATA ghx/-1.6506801230,-0.5246476232,0.5246476232,1.6506801230/
	DATA ghw/ 0.08131283544,0.8049140900,0.8049140900,0.08131283544/

	End Module GH_Def



C ************************************************************************************
C GH_INT1: Gauss-Hermite integration over a one-dimensional space using four points
C
C usage: x=GH_INT1(f)
C
C Input: f, Real(8) pointer to the function y=f(z1)
C           which is to be integrated
C Output: x, Real(8) value of the integral of y over [-inf,+inf]
C
C Remark: The integration nodes and weights (taken from Judd (1998), p. 262)
C         are stored in gcx and gcx, respectively and initialized with a data statement.
C         this takes place in the module GH_Def


	Real(8) Function GH_INT1(f,sigma)

	use GH_Def
	use Errors
	use IMSLF90 

	Real(8) f, sigma

	Integer(4) i1
	Real(8) sum, s, temp, dconst, pi
	 
	pi=dconst('pi')
	sum=0.0
	s=2.0
	s=dsqrt(s)*sigma
	Do i1=1,4
			temp=f(s*ghx(i1))
			if (FError.ne.0) return
			sum=sum+temp*ghw(i1)
	End Do
	GH_INT1=sum*((pi)**(-1./2.))

	Return
	End Function

