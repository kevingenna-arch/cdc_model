C The file holds a number of simple tools
C that we use in our main programs
C
C     - MyMessage
C     - ElapsedTime
C     - GetD
C     - GetI
C     - GetI2
C     - GetC
C     - GetL
C     - MyDate
C     - StDev
C     - MyStat
C     - SeqaD
C     - HPFilter
C     - FixpMN
C     - Corrx
C     - Vec
C     - Pi
C****************************************************************
C
C MyMessage
C
C Purpose: opens a system modal Messagebox and prints Message to it
C
C Usage: Call MyMessage(MText,WText)
C
C Input: MText Character*(*): Text printed in the Box
C        WText Character*(*): Text printed in the title bar of the window
C
	Subroutine MyMessage(MText,Wtext)

	use DFLIB

	Character*(*) MText, WText
	
	Integer(4) i

	i=MessageBoxQQ(MText,WText,MB$SYSTEMMODAL)

	Return

	End Subroutine




C****************************************************************
C
C ElapsedTime
C
C Purpose: returns an elapsed time string
C
C Usage: Call ElapsedTime(Seconds,Time)
C
C Input:   Seconds: Real(4), gives the
C          elapsed time in seconds
C
C
C Output:  Time: Character(100), holds the
C          formated time string
C          
      Subroutine ElapsedTime(Seconds,Time)

      Real(8) Seconds, totdays, tothrs, totmins, secs
	Integer days, hrs, mins
	Character(256) Time

      if (Seconds .lt. 0.0) then
	   Write(Time,"('Negative Time')")
	   Return
	endif	
	totdays = Seconds/(3600*24)
      days = floor(totdays)
	
      tothrs = (totdays-Real(days))*24
      hrs = floor(tothrs)
	
      totmins = (tothrs-real(hrs))*60
      mins = floor(totmins)
	
      secs = (totmins-real(mins))*60;
      
      if (days .gt. 1) then
        Write(Time,"(I1,' Days')") days
      endif

	if (days .eq. 1) then    
        Write(Time,"(I1,' Day')") days
      endif

      if (days .eq. 0) then
        Time=""
      endif    
      
	if (hrs .eq. 1) then
	  write(Time,"(A,I2,A)") trim(Time), hrs, ' hour '
      endif

	if (hrs .gt. 1) then
	  write(Time,"(A,I3,A)") trim(Time), hrs, ' hours '
      endif
	
	if (mins .eq. 1) then
	  write(Time,"(A,I2,A)") trim(Time), mins, ' minute '
      endif

      if (mins .gt. 1) then
	  write(Time,"(A,I3,A)") trim(Time), mins, ' minutes '
      endif
      
	write(Time,"(A,F6.2,A)") trim(Time), secs, ' seconds'            

      RETURN
	END Subroutine

C******************************************************************
C
C GetD
C
C Purpose: read a double precion variable from a text file
C
C Usage: Call GetD(VarName,FileName,Var)
C
C GetD(VarName,FileName,Var)
C
C Input: VarName:  Character*(*), the name of the variable
C                  in the file
C        FileName: Character*(*), the name of the file
C                  (must be in the current working directory
C
C Output: Var: the name of the variable that is asigned the
C              number read from the file
C
C Example: Suppose in the ASCII-File Parameters.txt
C          contains the following lines\
C          alpha=0.35
C          beta=0.99
C          delta=0.01
C          The command CALL GetD("delta","Parameters.txt",delta)
C          returns 0.01 and stores that value in the variable
C          delta.
C

      Subroutine GetD(String1,String2,Pvalue)
 
      use DFLIB
      Character*(*), INTENT(IN) :: String1, String2
	
      Real(8) Pvalue
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,file=String2,err=104)
      
      
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) Pvalue
      End If
      end do
      if (I1 .eq. 0) then
	continue
	Pvalue=-1
      Text="Variable " // String1 // " not found in file " 
     +        //  String2 // "!"
	I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL )      
      endif
      close(99)
104   If (I1 .eq. 0) then
       Text="File not found"
	 I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL )
	End If
      Return      
	End Subroutine
	
C**********************************************************************
C
C GetI
C
C Purpose: Same as GetD, but returns an Integer value in
C Var
C
C Usage: Call GetI(VarName,FileName,Var)

      Subroutine GetI(String1,String2,Pvalue)

      use DFLIB 
      Character*(*), INTENT(IN) :: String1, String2
	
      Integer Pvalue
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,action="Read",file=String2,err=105)
          
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) Pvalue
      End If
      end do
      if (I1 .eq. 0) then
	continue
	Pvalue=-1
      Text="Variable " // String1 // " not found in File " 
     +        //  String2 // " !"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)       
      endif
      close(99)
105   If (I1 .eq. 0) then
      Text="File not found"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return
	End Subroutine

C**********************************************************************
C
C GetI2
C
C Purpose: Same as GetD, but returns an Integer(2) value in
C Var
C
C Usage: Call GetI(VarName,FileName,Var)

      Subroutine GetI2(String1,String2,Pvalue)

      use DFLIB 
      Character*(*), INTENT(IN) :: String1, String2
	
      Integer(2) Pvalue
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,action="Read",file=String2,err=108)
          
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) Pvalue
      End If
      end do
      if (I1 .eq. 0) then
	continue
	Pvalue=-1
      Text="Variable " // String1 // " not found in File " 
     +        //  String2 // " !"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)       
      endif
      close(99)
108   If (I1 .eq. 0) then
      Text="File not found"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return
	End Subroutine


C********************************************************************
C GetC
C
C Purpose: read a Character variable from a text file
C
C Usage: Call GetS(VarName,FileName,Var)
C
C
C Input: VarName:  Character*(*), the name of the variable
C                  in the file
C        FileName: Character*(*), the name of the file
C                  (must be in the current working directory
C
C Output: Var: the name of the variable that is asigned the
C              string read from the file
C
C Example: Suppose in the ASCII-File Parameters.txt
C          contains the following lines\
C          alpha=0.35
C          beta=0.99
C          file=outfile
C          The command CALL GetS("file","Parameters.txt",file)
C          returns the string 'outfile' in the variable file
C
C Remarks: The old name GetC conflicts with a routine GetC in DFPORT!
C

      Subroutine GetS(String1,String2,String3)
 
      use DFLIB
      Character*(*), INTENT(IN) :: String1, String2
	Character*(*), INTENT(OUT) :: String3
      
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,file=String2,err=106)
      
      
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) String3
      End If
      end do
      if (I1 .eq. 0) then
	continue
	String3=""
      Text="Variable " // String1 // " not found in file " 
     +        //  String2 // "!"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)	
      
      endif
      close(99)
106   If (I1 .eq. 0) then
        Text="File not found"
	  I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return      
	End Subroutine
	

C**********************************************************************
C
C GetL
C
C Purpose: Same as GetD, but returns a logical value in
C Var
C
C Usage: Call GetL(VarName,FileName,Var)

      Subroutine GetL(String1,String2,Pvalue)
 
      use DFLIB
      Character*(*), INTENT(IN) :: String1, String2
	
      Logical Pvalue
      Character(256) Text, Rest, Suche
      Integer I1, I2
      	
      Suche=trim(String1)//"="
      I1=0
	I2=len_trim(Suche)

      open(unit=99,action="Read",file=String2,err=107)
          
      Do while ((.not. eof(99)) .and. (I1 .eq. 0))
	    Read(99,'(A)') Text	    
	Rest=Text(I2+1:len(Text))
	Text=Text(1:I2)	
	If (trim(Suche) .eq. Text) then
	   I1=1
	   read(Rest,*) Pvalue
      End If
      end do
      if (I1 .eq. 0) then
	continue
	Pvalue=-1
      Text="Variable " // String1 // " not found in File " 
     +        //  String2 // " !"
      I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
      endif
      close(99)
107   If (I1 .eq. 0) then
       Text="File not found"
	 I2=MessageBoxQQ(Text,'Error',MB$SYSTEMMODAL)
	End If
      Return
	End Subroutine


C***********************************************************************
C MyDate
C
C Purpose: Retrieve the current date and time and
C          returns it in a Character(50) string
C
C Usage: X=MyDate()

      CHARACTER(50) Function  MyDate()

	INTEGER(2) year,month,day, hour, min, sec, hsec
	CALL GETDAT(year,month,day)
	CALL GETTIM (hour, min, sec, hsec) 
	WRITE(MyDate,"(I2,'.',I2,'.',I4,'  ',I2,':',I2,':',
     +      I2)") day,month,year,hour,min,sec

      Return
	END FUNCTION


C*********************************************************************************
C StDev
C
C Computes the standard deviation of the elemtens in the row vector x(n)
C
C Usage: Result=StDev(n,x)
C
C        Input: n, Integer(4), the number of elements in x
C               x, Real(8), n times 1 vector
C
C        Output: Result, Real(8)


      Real(8) Function StDev(n,x)

	INTEGER(4) n
	REAL(8)  x(1:n)

      Integer(4) i
      Real(8) xmean, xsum  
      
	xsum=SUM(x)
	xmean=dble(Sum(x)/n)
	StDev=0.0
	Do i=1,n,1
        StDev=StDev+((x(i)-xmean)**2)
      End Do
	StDev=DSQRT(StDev/(n-1))
      Return
	END Function

C ***************************************************************************************
C MyStat
C
C Computes Minimum, Maximum and Standard Deviation of the
C Elements of a Vector
C
C Useage: Call MyStat(n,x,stat)
C
C Input: N: Integer(4), number of elements in x
C        X: Real(8), N times 1 vector
C
C Output: stat, Real(8), 4 times 1 vector, where
C              stat(1)=minimum of x
C              stat(2)=maximum of x
C              stat(3)=mean of x 
C              stat(4)=standard deviation of x


      Subroutine MyStat(n,x,stat)

	INTEGER(4) n, i
	REAL(8)  x(1:n), stat(4)
       
      stat(1)=MinVal(x)
	stat(2)=MaxVal(x)      
	stat(3)=dble(Sum(x)/n)
	stat(4)=0.0
	Do I=1,n
        stat(4)=stat(4)+(x(i)-stat(3))**2
      End Do
	stat(4)=DSQRT(dble(stat(4)/(n-1)))
      Return
	END SUBROUTINE



C*********************************************************************
C SeqaD
C
C Puropse: creates an additive series of double precion
C
C Usage Call SeqaD(xmin, step, nobs,x)
C
C Inputs:
C 
C xmin: Real(8), the first element in the series
C step: Real(8), increment
C nobs: Integer(4), number of elements in the series
C
C Output:
C
C x: Real(8) vector with nobs elements, where
C   x(i)=xmin+(i-1)*step


      Subroutine SeqaD(xmin,step,nobs,x)

	Integer(4) nobs
      Real(8)    xmin, step, x(nobs)
	      
      Integer(4) i

	x(1)=xmin
	
	do i=2,nobs
	 x(i)=x(i-1)+step	
      end do     
      
	Return
	End Subroutine

C***********************************************************************
C
C HPFilter
C
C Purpose: Compute the Hodrick-Prescott cyclical filter
C
C Usage:   CALL HPFilter(N,Y,Lambda,C)
C
C Input: N: Integer(4), the number of observations in Y
C        Y: Real(8), column vector of length N, the series whose
C                    cyclical component is to be computed
C   Lambda: Smoothing Parameter
C
C Ouput: C: Real(8), the cyclical component if Y

      Subroutine HPFilter(N,Y,Lambda,C)

      use IMSLF90 
      
	Integer(4) N
	Real(8) Y(N), Lambda, C(N)

	Integer I, NCODA, LDA
	Real(8) M(3,N)

      Parameter (LDA=3, NCODA=2)

C     Set up band matrix
      Do I=1,N
	   M(1,I)=Lambda
	   M(2,I)=-4*Lambda
	   M(3,I)=1+6*Lambda
	End Do

	M(1,1)=0.0
	M(1,2)=0.0
	M(2,1)=0.0
	M(2,2)=-2*Lambda
	M(2,N)=-2*Lambda
	M(3,1)=1+Lambda
	M(3,2)=1+5*Lambda
	M(3,N)=1+Lambda
	M(3,N-1)=1+5*Lambda
	
	CALL DLSAQS(N,M,LDA,NCODA,Y,C)
	C=Y-C

	End Subroutine


C********************************************************************
C
C Corrx
C
C Purpose: Compute correlation matrix vom data maxtrix
C
C Usage:   Call Corrx(n,m,x,crx)
C
C Input:   n, Integer(4), number of observations in x
C          m, Integer(4), number of variables (columns) in x
C          x, Real(8), n x m data matrix
C
C Output:  crx: m x m correlation matrix with standard
C               deviations on the diagonal
C
      Subroutine Corrx(n,m,x,crx)

      use IMSLF90 
	Integer(4) n, m
	Real(8) x(n,m), crx(m,m)
	
	Real(8) xbar(n,m), means(m), moment(m,m), stdv(m)
	Integer(4) I, J

C  Compute moment matrix
      means=Sum(x,dim=1)/n
	Do I=1,N
	   Do J=1,M
	    xbar(i,j)=x(i,j)-means(j)
	   End Do
	End Do
      moment=MatMul(Transpose(xbar),xbar)/(n-1)
      stdv=dsqrt(Diagonals(moment))
	Do I=1,M	   
	   crx(I,I)=stdv(i)
	End Do

	Do I=1,M
	   Do J=I+1,M
	      crx(i,j)=moment(i,j)/(stdv(i)*stdv(j))
	   End Do
	End Do

	End Subroutine


C************************************************************************************
C
C Vec: the vec-operator
C
C Usage Call(n,m,amat,bvec)
C
C Input: n: Integer(4) the number of rows of Amat
C        m: Integer(4) the number of columns of Amat
C     Amat: Real(8) n times m matrix
C
C Output: bvec: Real(8) n*m vector
C
	Subroutine Vec(n,m,amat,bvec)

	Integer(4) n, m
	Real(8) amat(n,m), bvec(n*m)

	Integer(4) i,j

	j=1

	Do i=1,m
		bvec(j:i*n)=amat(1:n,i)
		j=j+n
	Enddo

	Return

	End Subroutine



C*********************************************************************************************
C 
	Real(8) Function pi()

	use IMSLF90 
	Real(8) dconst
	 
	pi=dconst('pi')

	Return

	End Function 