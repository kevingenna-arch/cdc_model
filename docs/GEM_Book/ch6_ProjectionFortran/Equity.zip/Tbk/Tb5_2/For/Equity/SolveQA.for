C SolveQA: procedures to implement the quadratic approximation
C          of the policy functions of a SDGE model



C SolveQA: computates Hxi and Hyj 
C
C
C usage: Call SolveQA(nx,nz,ny,Lxx,Lxz,Lyx,Lyz,gmat,hcube,rmat,qmat,xcube,ycube)
C
C
C input: nx, Integer(4), the number of state variables (the number of rows in Lxx)
C        nz, Integer(4), the number of shocks (the number of columns in Lxz)
C        ny, Integer(4), the number of control and costate variables (the number of row in Lyx)
C        Lxx, Real(8), nx by nx matrix, the linear part of the policy function for x' with respect to x
C        Lxz, Real(8), nx by nz matrix, the linear part of the policy function for x' with respect to z
C        Lyx, Real(8), ny by nx matrix, the linear part of the policy function for y with respect to x,
C        Lyz, Real(8), ny by nz matrix, the linear part of the policy function for y with respect to z.
C       gmat, Real(8), (nx+ny) by (2*(nx+ny+nz)) matrix, the Jacobian of g
C      hcube, Real(8), a three dimensional array, of size nx+ny (first dimension),
C                      2*(nx+ny+nz) (second dimsion) and 2*(nx+ny+nz) (third dimension).
C                      Each hcube(i,.,.,) stores the Hesse matrix of equation gi, i=1, 2, ..., nx+ny
C       Rmat, Real(8), nz by nz matrix of AR(1)-coefficients from z'=rmat*z+sigma*omat*eps
C       Omat, Real(8), nz by nz matrix  (see line above)
C
C output: xcube, Real(8), nx by (nx+nz+1) by (nx+nz+1) three-dimensional array. Each page holds the
C                                       quadratic coefficients of  the policy function for x'(i) with respect
C                                       to the vector (xbar,zbar,sigma).
C         ycube, Real(8), ny by (nx+nz+1) by (nx+nz+1) array. Each page holds the quadratic coefficients of
C                                       the policy function for y(j) with respect to the vector (xbar,zbar,sigma).


	Subroutine SolveQA(n_x,n_z,n_y,Lxx,Lxz,Lyx,Lyz,gmat,hcube,Rmat,Omat,xcube,ycube)

	use Def_QA
	use Errors

	use IMSLF90      

	Integer(4) n_x, n_z, n_y
	Real(8) Lxx(1:n_x,1:n_x), Lxz(1:n_x,1:n_z), Lyx(1:n_y,1:n_x), Lyz(1:n_y,1:n_z), gmat(1:n_x+n_y,1:2*(n_x+n_y+n_z))
	Real(8) hcube(1:n_x+n_y,1:2*(n_x+n_y+n_z),1:2*(n_x+n_y+n_z)), rmat(1:n_z,1:n_z), omat(1:n_z,1:n_z)
	Real(8) xcube(1:n_x,1:1+n_x+n_z,1:1+n_x+n_z), ycube(1:n_y,1:1+n_x+n_z,1:1+n_x+n_z)


	Integer(4) nall, zi, j, k, i, l1, l2, l3, ord(1:2)
	Integer(4) iy1, iy2, iy3, ix1, ix2, ix3
	Integer(4), allocatable :: indz(:), inds(:)
	Real(8), allocatable :: amat(:,:), bvec(:), hvecxj(:), hvecxk(:), hveczj(:), hveczk(:), temp1(:,:), temp2(:,:)
	Real(8), allocatable :: xvec1(:), xvec2(:), xvec3(:), xvec4(:)
	Real(8) Geta, Getab
           
	Integer iercd, n1rty
c	Call Erset(0,0,0)
	   
	nx=n_x
	ny=n_y
	nz=n_z

C Compute Hxx 
	nall=(nx+ny)*(nx**2.d0)
	allocate(amat(1:nall,1:nall),bvec(1:nall),xvec1(1:nall))
	allocate(hvecxj(1:1+ny+nx+ny), hvecxk(1:1+ny+nx+ny))
	allocate(indz(1:1+ny+nx+ny), inds(1:1+ny+nx+ny),temp1(1:1+ny+nx+ny,1:1+ny+nx+ny))
	
	amat=0.0d0
	bvec=0.0d0
	xvec1=0.0d0
	zi=0
	Do j=1,nx,1
		Do k=1,nx,1
			Do  i=1,nx+ny,1
				zi=zi+1
				Do l1=1,ny,1
					amat(zi,iy1(l1,j,k))=gmat(i,nx+l1)
				End Do
				Do l1=1,nx,1
					amat(zi,ix1(l1,j,k))=gmat(i,nx+ny+nz+l1)
				End Do
				Do l1=1,ny,1
					Do l2=1,nx,1
						amat(zi,ix1(l2,j,k))=amat(zi,ix1(l2,j,k))+gmat(i,2*nx+nz+ny+l1)*Lyx(l1,l2)
					End Do
				End Do
				Do l1=1,ny,1
					Do l2=1,nx,1
						Do l3=1,nx,1
							amat(zi,iy1(l1,l2,l3))=amat(zi,iy1(l1,l2,l3))+gmat(i,2*nx+nz+ny+l1)*Lxx(l2,j)*Lxx(l3,k)
						End Do
					End Do
				End Do
				hvecxj(1)=1.d0
				hvecxj(2:1+ny)=Lyx(1:ny,j)
				hvecxj(2+ny:1+ny+nx)=Lxx(1:nx,j)
				hvecxj(2+ny+nx:1+ny+nx+ny)=MatMul(Lyx,Lxx(1:nx,j))
				hvecxk(1)=1.d0
				hvecxk(2:1+ny)=Lyx(1:ny,k)
				hvecxk(2+ny:1+ny+nx)=Lxx(1:nx,k)
				hvecxk(2+ny+nx:1+ny+nx+ny)=MatMul(Lyx,Lxx(1:nx,k))

				indz(1)=j
				inds(1)=k
				Do l1=1,ny,1
					indz(1+l1)=nx+l1
					inds(1+l1)=nx+l1
				End Do
				Do l1=1,nx+ny,1
					indz(1+ny+l1)=nx+ny+nz+l1
					inds(1+ny+l1)=nx+ny+nz+l1
				End Do
            
				temp1=hcube(i,indz,inds)
				bvec(zi)=Dot_Product(hvecxj, MatMul(temp1,hvecxk))
			End Do
		End Do
	End Do

	i=1
	bvec=-bvec
	Call DLSARG(nall,amat,nall,bvec,i,xvec1)	
	FError=iercd()

C hx_xz und hy_xz 

	nall=(nx+ny)*(nx*nz)
	deallocate(amat,bvec,temp1,inds)
	allocate(amat(1:nall,1:nall),bvec(1:nall),hveczk(1:1+2*ny+nx+nz),inds(1:1+ny+ny+nx+nz))
	allocate(temp1(1:1+ny+nx+ny,1:1+ny+nx+ny+nz),xvec2(1:nall))

	amat=0.0d0
	bvec=0.0d0
	temp1=0.0d0

	zi=0
	
	Do j=1,nx,1
		Do k=1,nz,1
			Do i=1,nx+ny,1
				zi=zi+1
				Do  l1=1,ny,1
					amat(zi,iy2(l1,j,k))=gmat(i,nx+l1)
				End Do
				Do l1=1,nx,1
					amat(zi,ix2(l1,j,k))=gmat(i,nx+ny+nz+l1)
				End Do;
				Do l1=1,ny,1
					Do l2=1,nx,1
						amat(zi,ix2(l2,j,k))=amat(zi,ix2(l2,j,k))+gmat(i,2*nx+ny+nz+l1)*Lyx(l1,l2)
					End Do
				End Do
				Do l1=1,ny,1
					Do l2=1,nx,1
						Do l3=1,nz,1
							amat(zi,iy2(l1,l2,l3))=amat(zi,iy2(l1,l2,l3))+gmat(i,2*nx+ny+nz+l1)*Lxx(l2,j)*Rmat(l3,k)
						End Do
						Do l3=1,nx,1
							bvec(zi)=bvec(zi)+gmat(i,2*nx+ny+nz+l1)*xvec1(iy1(l1,l2,l3))*Lxx(l2,j)*Lxz(l3,k)
						End Do
					End Do
				End Do
				hvecxj(1)=1
				hvecxj(2:1+ny)=Lyx(1:ny,j)
				hvecxj(2+ny:1+ny+nx)=Lxx(1:nx,j)
				hvecxj(2+ny+nx:1+ny+nx+ny)=MatMul(Lyx,Lxx(1:nx,j))
				hveczk(1:ny)=Lyz(1:ny,k)
				hveczk(1+ny:ny+nx)=Lxz(1:nx,k)
				hveczk(1+ny+nx:ny+nx+ny)=MatMul(Lyx,Lxz(1:nx,k))+MatMul(Lyz,Rmat(1:nz,k))
				hveczk(1+ny+nx+ny)=1.d0
				hveczk(2+ny+nx+ny:1+ny+nx+ny+nz)=Rmat(1:nz,k)
				
				indz(1)=j				
				Do l1=1,ny,1
					indz(1+l1)=nx+l1
				End Do
				Do l1=1,nx+ny,1
					indz(1+ny+l1)=nx+ny+nz+l1
				End Do
				Do l1=1,ny,1
					inds(l1)=nx+l1
				End Do
				Do l1=1,nx+ny,1
					inds(ny+l1)=nx+ny+nz+l1
				End Do
				inds(ny+nx+ny+1)=nx+ny+k
				Do l1=1,nz
					inds(ny+nx+ny+1+l1)=2*nx+2*ny+nz+l1
				End Do
            
	            temp1=hcube(i,indz,inds)
				bvec(zi)=bvec(zi)+Dot_Product(hvecxj,MatMul(temp1,hveczk))
			End Do
		End Do
	End Do

	bvec=-bvec
	i=1
	Call DLSARG(nall,amat,nall,bvec,i,xvec2)
	FError=iercd()

C hx_zz und hy_zz 
	nall=(nx+ny)*(nz**2)
	deallocate(amat,bvec,temp1,inds,indz,hveczk)
	allocate(amat(1:nall,1:nall),bvec(1:nall),hveczk(1:1+2*ny+nx+nz),hveczj(1:1+2*ny+nx+nz))
	allocate(indz(1:1+2*ny+nx+nz),inds(1:1+2*ny+nx+nz))
	allocate(temp1(1:1+2*ny+nx+nz,1:1+2*ny+nx+nz),xvec3(1:nall))

	amat=0.0d0
	bvec=0.0d0
	temp1=0.0d0


	zi=0
	Do j=1,nz,1
		Do k=1,nz,1
			Do i=1,nx+ny,1
				zi=zi+1
				Do l1=1,ny,1
					amat(zi,iy3(l1,j,k))=gmat(i,nx+l1)
				End Do
				Do l1=1,nx,1
					amat(zi,ix3(l1,j,k))=gmat(i,nx+ny+nz+l1)
				End Do
				Do l1=1,ny,1
					Do l2=1,nx,1
						amat(zi,ix3(l2,j,k))=amat(zi,ix3(l2,j,k))+gmat(i,2*nx+ny+nz+l1)*Lyx(l1,l2)
					End Do
				End Do
				Do l1=1,ny,1
					Do l2=1,nz,1
						Do l3=1,nz,1
							amat(zi,iy3(l1,l2,l3))=amat(zi,iy3(l1,l2,l3))+gmat(i,2*nx+ny+nz+l1)*Rmat(l2,j)*Rmat(l3,k)
						End Do
						Do l3=1,nx,1
							bvec(zi)=bvec(zi)+gmat(i,2*nx+ny+nz+l1)*Rmat(l2,j)*xvec2(iy2(l1,l2,l3))*Lxz(l3,k)
						End Do
					End Do
					Do l2=1,nx,1
						Do l3=1,nx,1
							bvec(zi)=bvec(zi)+gmat(i,2*nx+ny+nz+l1)*Lxz(l2,j)*xvec1(iy1(l1,l2,l3))*Lxz(l3,k)
						End Do
						Do l3=1,nz,1
							bvec(zi)=bvec(zi)+gmat(i,2*nx+ny+nz+l1)*Lxz(l2,j)*xvec2(iy2(l1,l2,l3))*Rmat(l3,k)
						End Do
					End Do
				End Do
				hveczj(1:ny)=Lyz(1:ny,j)
				hveczj(1+ny:ny+nx)=Lxz(1:nx,j)
				hveczj(1+ny+nx:ny+nx+ny)=MatMul(Lyx,Lxz(1:nz,j))+MatMul(Lyz,Rmat(1:nz,j))
				hveczj(1+ny+nx+ny)=1.d0
				hveczj(2+ny+nx+ny:1+ny+nx+ny+nz)=Rmat(1:nz,j)
				hveczk(1:ny)=Lyz(1:ny,k)
				hveczk(1+ny:ny+nx)=Lxz(1:nx,k)
				hveczk(1+ny+nx:ny+nx+ny)=MatMul(Lyx,Lxz(1:nx,k))+MatMul(Lyz,Rmat(1:nz,k))
				hveczk(1+ny+nx+ny)=1.d0
				hveczk(2+ny+nx+ny:1+ny+nx+ny+nz)=Rmat(1:nz,k)
				Do l1=1,ny,1
					indz(l1)=nx+l1
					inds(l1)=nx+l1
				End Do
				Do l1=1,nx+ny,1
					indz(ny+l1)=nx+ny+nz+l1
					inds(ny+l1)=nx+ny+nz+l1
				End Do
				indz(ny+nx+ny+1)=nx+ny+j
				inds(ny+nx+ny+1)=nx+ny+k
				Do l1=1,nz
					indz(ny+nx+ny+1+l1)=2*(nx+ny)+nz+l1
					inds(ny+nx+ny+1+l1)=2*(nx+ny)+nz+l1
				End Do
				temp1=hcube(i,indz,inds)
				bvec(zi)=bvec(zi)+Dot_Product(hveczj,MatMul(temp1,hveczk))
			End Do
		End Do
	End Do
	bvec=-bvec
	i=1
	Call DLSARG(nall,amat,nall,bvec,i,xvec3)
	FError=iercd()

C Hss 
	nall=nx+ny
	deallocate(amat,bvec,temp1,indz)
	allocate(amat(1:nall,1:nall),bvec(1:nall),temp1(1:ny+nz,1:ny+nz),temp2(1:ny+nz,1:ny+nz),indz(1:ny+nz))
	allocate(xvec4(1:nall))

	amat=0.0d0
	bvec=0.0d0
	temp1=0.0d0
	temp2=0.0d0

	Do i=1,nx+ny,1
		Do j=1,ny,1
			amat(i,nx+j)=gmat(i,nx+j)+gmat(i, 2*nx+ny+nz+j)
		End Do
		Do  j=1,nx,1
			amat(i,j)=gmat(i,nx+ny+nz+j)
			Do l1=1,ny,1
				amat(i,j)=amat(i,j)+gmat(i,2*nx+ny+nz+l1)*Lyx(l1,j)
			End Do
		End Do
		Do j=1,ny,1
			Do l1=1,nz,1
				Do l2=1,nz,1
					bvec(i)=bvec(i)+gmat(i,2*nx+ny+nz+j)*xvec3(iy3(j,l1,l2))*Dot_Product(Omat(l1,1:nz),Omat(l2,1:nz))
				End Do
			End Do
		End Do
		Do l1=1,ny+nz
			indz(l1)=2*nx+ny+nz+l1
		End Do
	    temp1=hcube(i,indz,indz)
	    temp2=0.0d0
	    Do l1=1,ny,1
			Do l2=1,ny,1
				temp2(l1,l2)=Geta(l1,l2,Lyz,Omat)
			End Do
			Do l2=1,nz,1
				temp2(l1,ny+l2)=Getab(l1,l2,Lyz,Omat)
				temp2(ny+l2,l1)=temp2(l1,ny+l2)
			End Do
		End Do
		Do l1=1,nz,1
			Do l2=1,nz,1
				temp2(ny+l1,ny+l2)=Dot_Product(Omat(l1,1:nz),Omat(l2,1:nz))
			End Do
		End Do
		bvec(i)=bvec(i)+sum(diagonals(MatMul(temp1,temp2)))
	End Do

	bvec=-bvec
	i=1
	Call DLSARG(nall,amat,nall,bvec,i,xvec4)
	FError=iercd()

C Create xcube and ycube
	xcube=0.0d0
	ycube=0.0d0
	deallocate(temp1)
	allocate(temp1(1:nx,1:nz))
	temp1=0.0d0

	Do i=1,nx,1
		ord(1)=nx
		ord(2)=nx
		xcube(i,1:nx,1:nx)=reshape(xvec1(ix1(i,1,1):ix1(i,nx,nx)),ord)
		ord(2)=nz
		xcube(i,1:nx,nx+1:nx+nz)=reshape(xvec2(ix2(i,1,1):ix2(i,nx,nz)),ord)
		temp1=xcube(i,1:nx,nx+1:nx+nz)
		xcube(i,nx+1:nx+nz,1:nx)=Transpose(temp1)
		ord(1)=nz
		xcube(i,nx+1:nx+nz,nx+1:nx+nz)=reshape(xvec3(ix3(i,1,1):ix3(i,nz,nz)),ord)
		xcube(i,nx+nz+1,nx+nz+1)=xvec4(i)
	End Do
	Do i=1,ny,1
		ord(1)=nx
		ord(2)=nx
		ycube(i,1:nx,1:nx)=reshape(xvec1(iy1(i,1,1):iy1(i,nx,nx)),ord)
		ord(2)=nz
		ycube(i,1:nx,nx+1:nx+nz)=reshape(xvec2(iy2(i,1,1):iy2(i,nx,nz)),ord)
		temp1=ycube(i,1:nx,nx+1:nx+nz)
		ycube(i,nx+1:nx+nz,1:nx)=Transpose(temp1)
		ord(1)=nz
		ycube(i,nx+1:nx+nz,nx+1:nx+nz)=reshape(xvec3(iy3(i,1,1):iy3(i,nz,nz)),ord)
		ycube(i,nx+nz+1,nx+nz+1)=xvec4(nx+i)
	End Do

	Return

	End Subroutine

C ix1(i,j,k) returns the index of Hxi_xj_xk in xvec1
	Integer(4) Function ix1(i,j,k)

	use Def_QA

	Integer(4) i, j, k

	ix1=(i-1)*(nx**2) + (j-1)*nx + k

	Return

	End Function

C iy1(i,j,k) returns the index of Hyi_xj_xk in xvec1
	Integer(4) Function iy1(i,j,k)

	use Def_QA

	Integer(4) i, j, k
	Integer(4) ix1	

	iy1=(nx**3) + ix1(i,j,k)

	Return

	End Function

C ix2(i,j,k) returns the index of Hxi_xj_xk in xvec2
	Integer(4) Function ix2(i,j,k)
	
	use Def_QA

	Integer(4) i, j, k	
	
	ix2=(i-1)*(nz*nx) + (j-1)*nz + k

	Return

	End Function

C iy2(i,j,k) returns the index of Hyi_xj_xk in xvec2
	Integer(4) Function iy2(i,j,k)

	use Def_QA

	Integer(4) i, j, k
	Integer(4) ix2

	iy2=(nx**2)*nz + ix2(i,j,k)

	Return

	End Function

C ix3(i,j,k) returns the index of Hxi_xj_xk in xvec3
	Integer(4) Function ix3(i,j,k)

	use Def_QA

	Integer(4) i, j, k

	ix3=(i-1)*(nz**2)+(j-1)*nz + k

	Return

	End Function

C iy3(i,j,k) returns the index of Hyi_xj_kx in xvec3
	Integer(4) Function iy3(i,j,k)

	use Def_QA

	Integer(4) i, j, k
	Integer(4) ix3

	iy3=nx*(nz**2) + ix3(i,j,k)

	Return

	End Function

	Real(8) Function Geta(i,j,Lyz,Omat)
	
	use Def_QA

	Integer(4) i, j
	Real(8) Lyz(1:ny,1:nz), Omat(1:nz,1:nz)
		
	Integer(4) s, q
    
	Geta=0.0d0

	Do  s=1,nz,1
		Do q=1,nz, 1
			Geta=Geta+Lyz(i,q)*Lyz(j,s)*Dot_Product(Omat(q,1:nz),Omat(s,1:nz))
		End Do
	End Do
    
	Return

	End Function


	Real(8) Function Getab(i,j,Lyz,Omat)

	use Def_QA

	Integer(4) i,j
	Real(8) Lyz(1:ny,1:nz), Omat(1:nz,1:nz)

	Integer(4) s
	
	Getab=0.0d0

	Do s=1,nz,1
		Getab=Getab+Lyz(i,s)*Dot_Product(Omat(s,1:nz),Omat(j,1:nz))
	End Do

	Return
	End Function


